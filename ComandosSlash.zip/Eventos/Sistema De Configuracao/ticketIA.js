const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const Groq = require("groq-sdk");
const { atendimentosAI, configsticket, configuracao } = require("../../DataBaseJson");
const emojis = require("../../DataBaseJson/emojis.json");
const { res } = require("../../res");

const Emojis = {
    get: (name) => emojis[name] || ""
};

const groq = new Groq({ apiKey: "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" });

module.exports = {
    name: "messageCreate",
    run: async (message, client) => {
        if (!message || !client) return;
        if (message.author.bot) return;
        if (!message.channel.isThread()) return;

        try {
            const ticketInfo = atendimentosAI.get(`${message.channel.id}`);
            if (!ticketInfo) return;

            const statusIA = configsticket.get("ilusionAI.ativo");
            if (!statusIA) return;

            const ticketAssumido = atendimentosAI.get(`${message.channel.id}.assumido`);

            const papeisUsuario = message.member.roles.cache;
            const cargoSup = configuracao.get("ConfigRoles.cargosup");
            const cargoAdm = configuracao.get("ConfigRoles.cargoadm");
            let ehStaff = false;

            if (cargoSup && papeisUsuario.has(cargoSup)) {
                ehStaff = true;
            }
            if (cargoAdm && papeisUsuario.has(cargoAdm)) {
                ehStaff = true;
            }
            if (message.member.permissions.has("Administrator")) {
                ehStaff = true;
            }

            if (!ticketAssumido && ehStaff) {
                atendimentosAI.set(`${message.channel.id}.assumido`, true);
                atendimentosAI.set(`${message.channel.id}.assumidoPor`, {
                    id: message.author.id,
                    tag: message.author.tag,
                    username: message.author.username,
                    assumidoEm: Date.now()
                });

                const containerAssumido = res.main(
                    { type: 10, content: `**Atendimento Assumido**` },
                    { type: 14 },
                    { type: 10, content: `Olá! A partir de agora, ${message.author} assumiu o atendimento deste ticket.\n\nA assistente virtual foi desativada e todas as suas dúvidas serão respondidas diretamente por um membro da nossa equipe. Fique à vontade para conversar! 😊` },
                    { type: 14 },
                    {
                        type: 1,
                        components: [
                            { type: 2, style: 2, label: 'Mensagem do Sistema', custom_id: 'msgSystem', disabled: true }
                        ]
                    }
                );

                await message.channel.send(containerAssumido);
                return;
            }

            if (ticketAssumido) return;

            if (message.author.id === ticketInfo.dono) {
                const historicoChat = atendimentosAI.get(`${message.channel.id}.chat`) || [];
                const mensagemUsuario = message.content;
                const mensagemPrompt = configsticket.get("ilusionAI.prompt") ||
                    `Você é uma assistente de suporte. Responda em português de forma clara e direta ao problema descrito pelo usuário. Se você não souber a resposta, peça para aguardar o suporte humano.`;

                historicoChat.push({ 
                    role: "user", 
                    content: mensagemUsuario,
                    timestamp: Date.now(),
                    authorId: message.author.id,
                    authorTag: message.author.tag
                });
                atendimentosAI.set(`${message.channel.id}.chat`, historicoChat);

                await message.channel.sendTyping();

                const pedindoSuporteHumano = /\b(suporte humano|atendente|falar com alguém|chamar suporte|preciso de ajuda humana|quero falar com uma pessoa|atendimento humano|staff|administrador|moderador)\b/i.test(mensagemUsuario);

                if (pedindoSuporteHumano) {
                    
                    try {
                        const guild = message.guild;
                        const cargoSup = configuracao.get("ConfigRoles.cargosup");
                        const cargoAdm = configuracao.get("ConfigRoles.cargoadm");
                        
                        const membrosNotificados = new Set();
                        
                        const membros = await guild.members.fetch();
                        
                        for (const [memberId, member] of membros) {
                            if (member.user.bot) continue;
                            
                            let deveNotificar = false;
                            
                            if (cargoSup && member.roles.cache.has(cargoSup)) {
                                deveNotificar = true;
                            }
                            
                            if (cargoAdm && member.roles.cache.has(cargoAdm)) {
                                deveNotificar = true;
                            }
                            
                            if (member.permissions.has("Administrator")) {
                                deveNotificar = true;
                            }
                            
                            if (deveNotificar && !membrosNotificados.has(memberId)) {
                                try {
                                    const rowIrTicket = new ActionRowBuilder().addComponents(
                                        new ButtonBuilder()
                                            .setLabel('Ir para o Ticket')
                                            .setStyle(5)
                                            .setURL(`https://discord.com/channels/${guild.id}/${message.channel.id}`)
                                    );

                                    await member.send({
                                        content: `# ${guild.name} - Suporte Humano Solicitado

**Usuário:** ${message.author} (${message.author.tag})
**Ticket:** ${message.channel}
**Mensagem:** \`${mensagemUsuario.substring(0, 200)}${mensagemUsuario.length > 200 ? '...' : ''}\`

\`📌\` **Ação Necessária:** Clique no botão abaixo para ir direto ao ticket e assumir o atendimento.`,
                                        components: [rowIrTicket]
                                    });
                                    membrosNotificados.add(memberId);
                                } catch (dmError) {
                                }
                            }
                        }
                        
                        if (membrosNotificados.size > 0) {
                            const containerSuporteNotificado = res.main(
                                { type: 10, content: `**Ilusion AI - Suporte Humano Notificado**` },
                                { type: 14 },
                                { type: 10, content: `Perfeito! Nossa equipe de suporte foi alertada sobre sua solicitação.*${membrosNotificados.size}** membro(s) da equipe foram notificados e um atendente irá assumir este ticket em breve. Aguarde um momento, por favor!` },
                                { type: 14 }
                            );

                            await message.channel.send(containerSuporteNotificado);
                            
                            atendimentosAI.set(`${message.channel.id}.suporteHumanoSolicitado`, {
                                timestamp: Date.now(),
                                userId: message.author.id,
                                userTag: message.author.tag,
                                mensagem: mensagemUsuario,
                                membrosNotificados: membrosNotificados.size
                            });
                        }
                        
                    } catch (notifyError) {
                        console.error("[TICKET IA] Erro ao notificar staff:", notifyError);
                    }
                }

                try {
                    const respostaIA = await groq.chat.completions.create({
                        messages: [
                            { role: "system", content: mensagemPrompt },
                            ...historicoChat.map(msg => ({
                                role: msg.role,
                                content: msg.content
                            }))
                        ],
                        model: "llama-3.3-70b-versatile",
                        temperature: 0.7,
                        max_tokens: 1024,
                    });

                    const mensagemIA = respostaIA.choices[0]?.message?.content ||
                        "Desculpe, não consegui gerar uma resposta agora. Por favor, aguarde um atendente humano.";

                    await message.reply({ content: mensagemIA });

                    const iaSugeriuSuporte = /\b(suporte humano|atendente|aguarde.*atendente|entre em contato|falar com.*equipe|staff|administrador)\b/i.test(mensagemIA);
                    
                    if (iaSugeriuSuporte && !pedindoSuporteHumano) {
                        
                        const containerChamarSuporte = res.main(
                            { type: 10, content: `**Ilusion AI - Precisa de Ajuda Adicional?**` },
                            { type: 14 },
                            { type: 10, content: `Se você deseja falar com um atendente humano, clique no botão abaixo e nossa equipe será notificada imediatamente!` },
                            { type: 14 },
                            {
                                type: 1,
                                components: [
                                    { type: 2, style: 1, label: 'Chamar Suporte Humano', custom_id: `chamar_suporte_humano_${message.channel.id}` }
                                ]
                            }
                        );
                        
                        await message.channel.send(containerChamarSuporte);
                    }

                    historicoChat.push({ 
                        role: "assistant", 
                        content: mensagemIA,
                        timestamp: Date.now(),
                        model: "llama-3.3-70b-versatile"
                    });
                    atendimentosAI.set(`${message.channel.id}.chat`, historicoChat);
                    
                    atendimentosAI.set(`${message.channel.id}.ultimaInteracao`, Date.now());
                    const totalMensagens = atendimentosAI.get(`${message.channel.id}.totalMensagensIA`) || 0;
                    atendimentosAI.set(`${message.channel.id}.totalMensagensIA`, totalMensagens + 1);
                    
                } catch (erro) {
                    console.error("[ERRO IA TICKET]", erro);
                    await message.reply({
                        content: `${Emojis.get('negative')} Erro ao processar a resposta da IA. Um atendente será notificado em breve.`
                    });
                    
                    atendimentosAI.set(`${message.channel.id}.erros`, [
                        ...(atendimentosAI.get(`${message.channel.id}.erros`) || []),
                        {
                            timestamp: Date.now(),
                            erro: erro.message,
                            mensagemUsuario: mensagemUsuario
                        }
                    ]);
                }
            }
        } catch (error) {
            console.error("[ERRO TICKET IA]", error);
        }
    }
};
