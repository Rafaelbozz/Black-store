const { 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, 
    ModalBuilder, TextInputBuilder, TextInputStyle, 
    InteractionType 
} = require("discord.js");
const axios = require("axios");
const fs = require('fs');
const path = require('path');
const { Emojis } = require("../../DataBaseJson/index");
const { res } = require("../../res");

const API_URL = "https://ryzenecloud.squareweb.app/";
const AUTH_TOKEN = "galaodamassa581";
const dbPathAuth = path.join(__dirname, "..", "..", "DataBaseJson", "configauth02api.json");
const giftsPath = path.join(__dirname, "..", "..", "DataBaseJson", "gifts.json");

module.exports = {
    name: 'interactionCreate',

    async run(interaction, client) {

        if (interaction.isButton() && interaction.customId === 'gerenciar_gifts_membros') {
            const { PainelGifts } = require('../../Functions/GerenciarGifts.js');
            return PainelGifts(interaction);
        }

        if (interaction.isButton() && interaction.customId === 'voltar_painel_auth02') {
            const { auth02api } = require('../../Functions/configurarauth02.js');
            return auth02api(interaction);
        }

        if (interaction.isButton() && interaction.customId === 'criar_gift_membro') {
            if (!fs.existsSync(dbPathAuth)) {
                return interaction.reply({
                    content: `${Emojis.get('negative')} Configure o Bot Auth02 primeiro!`,
                    ephemeral: true
                });
            }

            const modal = new ModalBuilder()
                .setCustomId('modal_criar_gift')
                .setTitle('🎁 Criar Gift de Membros');

            const inputQuantidade = new TextInputBuilder()
                .setCustomId('quantidade_gift')
                .setLabel('QUANTIDADE DE MEMBROS POR GIFT')
                .setPlaceholder('Ex: 50')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const inputQuantosGifts = new TextInputBuilder()
                .setCustomId('quantos_gifts')
                .setLabel('QUANTOS GIFTS CRIAR')
                .setPlaceholder('Ex: 3 (criará 3 gifts com a quantidade especificada)')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(inputQuantidade),
                new ActionRowBuilder().addComponents(inputQuantosGifts)
            );

            return interaction.showModal(modal);
        }

        if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'modal_criar_gift') {
            await interaction.deferReply({ ephemeral: true });

            const quantidade = parseInt(interaction.fields.getTextInputValue('quantidade_gift').trim());
            const quantosGifts = parseInt(interaction.fields.getTextInputValue('quantos_gifts').trim());
            const criadoPor = interaction.user.tag;

            if (isNaN(quantidade) || quantidade <= 0) {
                return interaction.editReply(`${Emojis.get('negative')} Informe uma quantidade válida de membros!`);
            }

            if (isNaN(quantosGifts) || quantosGifts <= 0) {
                return interaction.editReply(`${Emojis.get('negative')} Informe uma quantidade válida de gifts!`);
            }

            if (quantosGifts > 10) {
                return interaction.editReply(`${Emojis.get('negative')} Você pode criar no máximo 10 gifts por vez!`);
            }

            try {
                const authData = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));
                
                const botId = authData.bot_id;

                if (!botId) {
                    return interaction.editReply(`${Emojis.get('negative')} Configuração do Bot Auth02 inválida! Bot ID não encontrado.`);
                }

                const infoRes = await axios.get(`${API_URL}/api/auth02/info/${botId}`, {
                    headers: { 'Authorization': AUTH_TOKEN }
                });

                const membrosDisponiveis = infoRes.data.membros || 0;
                const totalMembrosNecessarios = quantidade * quantosGifts;

                if (totalMembrosNecessarios > membrosDisponiveis) {
                    return interaction.editReply(
                        `${Emojis.get('negative')} Você tentou criar ${quantosGifts} gifts de \`${quantidade}\` membros cada (total: \`${totalMembrosNecessarios}\` membros), ` +
                        `mas seu bot possui apenas \`${membrosDisponiveis}\` verificados na database.`
                    );
                }

                const giftsCriados = [];
                const erros = [];
                
                for (let i = 0; i < quantosGifts; i++) {
                    try {
                        console.log(`[Gift ${i + 1}] Enviando requisição para API...`);
                        console.log(`[Gift ${i + 1}] URL: ${API_URL}/api/gifts/criar`);
                        console.log(`[Gift ${i + 1}] Body:`, { bot_id: botId, quantidade: quantidade, criado_por: criadoPor });
                        
                        const giftRes = await axios.post(`${API_URL}/api/gifts/criar`, {
                            bot_id: botId,
                            quantidade: quantidade,
                            criado_por: criadoPor
                        }, {
                            headers: { 
                                'Authorization': AUTH_TOKEN,
                                'Content-Type': 'application/json'
                            }
                        });

                        console.log(`[Gift ${i + 1}] Resposta da API:`, giftRes.data);

                        if (giftRes.data.sucesso) {
                            giftsCriados.push(giftRes.data.gift);
                        } else {
                            const erro = giftRes.data.erro || giftRes.data.mensagem || JSON.stringify(giftRes.data);
                            erros.push(`Gift ${i + 1}: ${erro}`);
                            console.error(`[Gift ${i + 1}] Erro na resposta:`, giftRes.data);
                        }
                    } catch (err) {
                        console.error(`[Gift ${i + 1}] Erro na requisição:`, {
                            message: err.message,
                            response: err.response?.data,
                            status: err.response?.status,
                            statusText: err.response?.statusText
                        });
                        
                        const errorDetail = err.response?.data?.erro || 
                                          err.response?.data?.message || 
                                          err.response?.data?.mensagem ||
                                          err.response?.statusText ||
                                          err.message;
                        erros.push(`Gift ${i + 1}: ${errorDetail}`);
                    }
                }

                if (giftsCriados.length === 0) {
                    let errorMsg = `${Emojis.get('negative')} Erro ao criar gifts:\n\n`;
                    
                    if (erros.length > 0) {
                        errorMsg += erros.join('\n');
                    } else {
                        errorMsg += 'Nenhum gift foi criado. Tente novamente.';
                    }
                    
                    console.error('[Criar Gifts] Nenhum gift criado. Erros:', erros);
                    return interaction.editReply(errorMsg);
                }

                let mensagemDM = `# Seus Gifts Membros Foram Criados Com Sucesso\n\n`;
                
                giftsCriados.forEach((gift, index) => {
                    mensagemDM += `${gift.link_resgate} - ${gift.quantidade} membros\n`;
                });

                if (giftsCriados.length < quantosGifts) {
                    mensagemDM += `\n-# ⚠️ Foram criados ${giftsCriados.length} de ${quantosGifts} gifts solicitados.`;
                }

                let dmMessage;
                try {
                    dmMessage = await interaction.user.send({ content: mensagemDM });
                } catch (dmError) {
                    console.error('[Criar Gifts] Erro ao enviar DM:', dmError.message);
                    return interaction.editReply(
                        `${Emojis.get('negative')} Não foi possível enviar os gifts na sua DM!\n\n` +
                        `Verifique se suas DMs estão abertas e tente novamente.`
                    );
                }

                const dmLink = `https://discord.com/channels/@me/${dmMessage.channel.id}/${dmMessage.id}`;
                
                const rowLink = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel('Clique aqui para ser Redirecionado')
                        .setStyle(ButtonStyle.Link)
                        .setURL(dmLink)
                );

                return interaction.editReply({ 
                    content: `${Emojis.get('checker')} Seus **${giftsCriados.length}** Gifts Foram Gerados Com Sucesso e Enviados na Sua DM`,
                    components: [rowLink]
                });

            } catch (err) {
                console.error("Erro ao criar gifts:", err.response?.data || err.message);
                
                let errorMsg = `${Emojis.get('negative')} Erro ao criar gifts:\n`;
                
                if (err.response?.data) {
                    errorMsg += `\`\`\`json\n${JSON.stringify(err.response.data, null, 2)}\n\`\`\``;
                } else {
                    errorMsg += `\`${err.message}\``;
                }
                
                return interaction.editReply(errorMsg);
            }
        }
    }
};
