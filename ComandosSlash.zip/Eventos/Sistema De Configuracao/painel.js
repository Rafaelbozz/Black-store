const Discord = require("discord.js")
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ChannelSelectMenuBuilder, ChannelType, StringSelectMenuBuilder } = require("discord.js")
const { Painel, Gerenciar2, PainelExtensoes } = require("../../Functions/Painel");
const { PainelPermissions, ModalAdicionarPerm, ModalRemoverPerm, HandleAdicionarPerm, HandleRemoverPerm, HandleResetarPerms } = require("../../Functions/gerenciarpermsadm.js");
const { Gerenciar } = require("../../Functions/Gerenciar");
const { configqrcode } = require("../../Functions/QRCode.js");
const { infosauth } = require("../../Functions/infosauth");
const { gerenciarPerms } = require("../../Functions/modUsersPerms");
const { configauth } = require("../../Functions/eCloudConfigs");
const { automatico } = require("../../Functions/automaticos");
const { infoauth } = require("../../Functions/infoauth");
const { ecloud } = require("../../Functions/eCloudConfig");      
const { ConfigRoles } = require("../../Functions/ConfigRoles");
const { EstatisticasStorm } = require("../../index.js");
const { profileuser } = require("../../Functions/profile");
const { misticConfigs } = require("../../Functions/misticpayconfig.js");
const { produtos, configuracao, tickets } = require("../../DataBaseJson");
const { Posicao1 } = require("../../Functions/PosicoesFunction.js");
const { PainelTickets, ConfigurarAparencia, ConfigurarIlusionAI, ModalEditarPrompt, HandleEditarPrompt, ToggleIlusionAI, AlterarModoExibicao, HandleSelectModoExibicao, ModalEditarAparencia, HandleEditarAparencia, ConfigurarFuncoes, ModalAdicionarFuncao, HandleAdicionarFuncao, PaginaRemoverFuncao, HandleDeletarFuncao, HandleExcluirTodasFuncoes, PaginaEditarFuncao, ModalEditarFuncaoEspecifica, HandleEditarFuncaoEspecifica, PaginaPostarMensagem, HandlePostarMensagem, ConfigurarHorarioAtendimento, ToggleHorarioAtendimento, ModalConfigurarHorarios, HandleConfigurarHorarios, PaginaConfigurarDiasFolga, HandleConfigurarDiasFolga, ToggleSistemaFolgas } = require("../../Functions/PainelTickets.js");
const { SistemaSugestao } = require("../../Functions/sugestao.js");
const { msgbemvindo } = require("../../Functions/MensagemBemVindo");
const { AcoesRepostAutomatics } = require("../../Functions/ConfigRepostAuto.js");
const { GerenciarCampos2 } = require("../../Functions/GerenciarCampos.js");
const { moedaConfig } = require("../../Functions/moedaConfig.js");
const { MessageStock } = require("../../Functions/ConfigEstoque.js");
const { auth02api } = require("../../Functions/configurarauth02.js");
const { PainelGifts } = require("../../Functions/GerenciarGifts.js");
const { imapConfigs } = require("../../Functions/configinter.js")
const { IlusionBux } = require("../../Functions/IlusionBux.js")

const { PainelSorteios, ModalCriarSorteio, PaginaSetarTempo, PaginaEscolherCanal, PaginaGerenciarCargos, EnviarMensagemSorteio, ModalTempoPersonalizado, parseTime, gerarIdSorteio, rerollSorteio, gerarListaParticipantes, atualizarEmbedSorteio, PaginaGerenciarSorteios, PaginaGerenciarSorteioEspecifico, PaginaConfirmarForcarFinalizacao, PaginaConfirmarDescontinuar, ModalAdicionarTempo, descontinuarSorteio, forcarFinalizacao } = require("../../Functions/PainelSorteios.js")
const { sorteios } = require("../../DataBaseJson")
const { res } = require("../../res")
const EventEmitter = require("events");
const emojis = require("../../DataBaseJson/emojis.json");


const Emojis = {
    get: (name) => emojis[name] || ""
};

async function mostrarPaginaProdutos(interaction, page = 0) {
    const { res } = require("../../res");
    const ggg = produtos.fetchAll();
    const ITEMS_PER_PAGE = 25;
    const totalPages = Math.ceil(ggg.length / ITEMS_PER_PAGE);
    
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;
    if (totalPages === 0) page = 0;
    
    const startIndex = page * ITEMS_PER_PAGE;
    const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, ggg.length);
    const currentProducts = ggg.slice(startIndex, endIndex);
    
    const options = currentProducts.map(gggg => {
        let desc = gggg?.data?.Config?.desc;
        let aaaaaa;

        if (desc == undefined) {
            desc = "Não definido";
        }
        if (desc && desc.length > 0) {
            aaaaaa = desc.slice(0, 70);
        } else {
            aaaaaa = "Não definido";
        }

        let name = gggg?.data?.Config?.name;
        if (name == undefined) {
            name = "Não definido";
        }

        return {
            label: `${name}`,
            description: `${aaaaaa}`,
            value: gggg.ID,
            emoji: { id: "1178163524443316285" },
        };
    });

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar3")
            .setLabel("Voltar")
            .setEmoji(`1178068047202893869`)
            .setStyle(2)
    );

    if (ggg.length === 0) {
        const containerContent = res.main(
            { type: 10, content: `-# Painel > Sistema de Vendas > Gerenciar Produtos` },
            { type: 14 },
            { type: 10, content: `**Gerenciar Produtos**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('negative')} Nenhum produto cadastrado ainda.` }
        ).with({
            components: [rowVoltar],
            flags: [64]
        });
        await interaction.update(containerContent);
        return;
    }

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Sistema de Vendas > Gerenciar Produtos` },
        { type: 14 },
        { type: 10, content: `${interaction.user} Qual produto deseja gerenciar?` },
        { type: 14 },
        {
            type: 1,
            components: [{
                type: 3,
                custom_id: "configproduto_page",
                placeholder: `Selecione um produto (Página ${page + 1}/${totalPages})`,
                options: options
            }]
        },
        {
            type: 1,
            components: [
                { type: 2, style: 2, custom_id: `produtos_page_${page - 1}`, emoji: { id: '1460477624206889093' }, disabled: page === 0 },
                { type: 2, style: 2, custom_id: 'disabled_middle', emoji: { id: '1178163524443316285' }, disabled: true },
                { type: 2, style: 2, custom_id: `produtos_page_${page + 1}`, emoji: { id: '1460477653030146089' }, disabled: page >= totalPages - 1 }
            ]
        }
    ).with({
        components: [rowVoltar],
        flags: [64]
    });
    
    await interaction.update(containerContent);
}


module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {

        if (interaction.type == Discord.InteractionType.ModalSubmit) {

            if (interaction.customId === 'modal_renomear_ticket') {
                const novoNome = interaction.fields.getTextInputValue('novo_nome_ticket');
                
                try {
                    await interaction.channel.setName(novoNome);
                    await interaction.reply({ content: `${Emojis.get('checker')} | Ticket renomeado para **${novoNome}**!`, ephemeral: true });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Erro ao renomear ticket.`, ephemeral: true });
                }
                return;
            }

            if (interaction.customId === 'modal_adicionar_usuario_ticket') {
                const userId = interaction.fields.getTextInputValue('usuario_id_adicionar');
                
                try {
                    const user = await interaction.guild.members.fetch(userId);
                    await interaction.channel.members.add(user.id);
                    await interaction.reply({ content: `${Emojis.get('checker')} | ${user} foi adicionado ao ticket!`, ephemeral: true });
                    await interaction.channel.send({ content: `${Emojis.get('checker')} | ${user} foi adicionado ao ticket por ${interaction.user}.` });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Usuário não encontrado ou erro ao adicionar.`, ephemeral: true });
                }
                return;
            }

            if (interaction.customId === 'modal_remover_usuario_ticket') {
                const userId = interaction.fields.getTextInputValue('usuario_id_remover');
                
                try {
                    const user = await interaction.guild.members.fetch(userId);
                    await interaction.channel.members.remove(user.id);
                    await interaction.reply({ content: `${Emojis.get('checker')} | ${user} foi removido do ticket!`, ephemeral: true });
                    await interaction.channel.send({ content: `${Emojis.get('negative')} | ${user} foi removido do ticket por ${interaction.user}.` });
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Usuário não encontrado ou erro ao remover.`, ephemeral: true });
                }
                return;
            }

            if (interaction.customId === 'modal_robux_precos') {
                const { Systemrobux } = require("../../DataBaseJson");
                const { IlusionBux } = require("../../Functions/IlusionBux");
                
                let precoComTaxa = interaction.fields.getTextInputValue('preco_com_taxa');
                let precoSemTaxa = interaction.fields.getTextInputValue('preco_sem_taxa');
                
                precoComTaxa = parseFloat(precoComTaxa.replace(',', '.'));
                precoSemTaxa = parseFloat(precoSemTaxa.replace(',', '.'));
                
                if (isNaN(precoComTaxa) || precoComTaxa <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Preço com taxa inválido! Use apenas números.`,
                        ephemeral: true
                    });
                }
                
                if (isNaN(precoSemTaxa) || precoSemTaxa <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Preço sem taxa inválido! Use apenas números.`,
                        ephemeral: true
                    });
                }
                
                Systemrobux.set('preco_com_taxa', precoComTaxa.toFixed(2));
                Systemrobux.set('preco_sem_taxa', precoSemTaxa.toFixed(2));
                
                await interaction.deferUpdate();
                
                const { ButtonInteraction } = require('discord.js');
                const fakeInteraction = Object.assign(Object.create(Object.getPrototypeOf(interaction)), interaction);
                fakeInteraction.update = interaction.editReply.bind(interaction);
                
                await IlusionBux(fakeInteraction);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Preços configurados com sucesso!`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_robux_quantidade') {
                const { MostrarSelecaoTaxa } = require("../../Functions/CreateCarrinhoRobux");
                const quantidadeStr = interaction.fields.getTextInputValue('robux_quantidade');
                
                const quantidade = parseInt(quantidadeStr);
                if (isNaN(quantidade) || quantidade <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Quantidade inválida! Digite apenas números.`,
                        ephemeral: true
                    });
                }

                await MostrarSelecaoTaxa(interaction, quantidade);
                return;
            }

            if (interaction.customId.startsWith('modal_robux_username_')) {
                const { ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
                const { Systemrobux, configuracao, carrinhosrobux } = require("../../DataBaseJson");
                const { DentroCarrinhoRobux } = require("../../Functions/DentroCarrinhoRobux");
                const axios = require("axios");
                
                const parts = interaction.customId.replace('modal_robux_username_', '').split('_');
                const quantidade = parseInt(parts[0]);
                const tipoTaxa = parts[1];
                const username = interaction.fields.getTextInputValue('robux_username');

                const precoComTaxa = parseFloat(Systemrobux.get('preco_com_taxa'));
                const precoSemTaxa = parseFloat(Systemrobux.get('preco_sem_taxa'));
                const precoUnitario = tipoTaxa === 'com_taxa' ? precoComTaxa : precoSemTaxa;
                const valorTotal = ((quantidade / 1000) * precoUnitario).toFixed(2);

                const isThread = interaction.channel.isThread();

                try {
                    let robloxData = null;
                    try {
                        const userSearchResponse = await axios.post('https://users.roblox.com/v1/usernames/users', {
                            usernames: [username],
                            excludeBannedUsers: false
                        });

                        if (userSearchResponse.data.data && userSearchResponse.data.data.length > 0) {
                            robloxData = { exists: true };
                        }
                    } catch (error) {
                        console.error('[Validar Roblox] Erro:', error.message);
                    }

                    if (!robloxData || !robloxData.exists) {
                        const rowTentarNovamente = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId(`robux_tentar_novamente_${quantidade}_${tipoTaxa}`)
                                .setLabel('Tentar Novamente')
                                .setEmoji(Emojis.get('_reload_emoji') || '🔄')
                                .setStyle(2)
                        );

                        if (isThread) {
                            await interaction.reply({
                                content: `${Emojis.get('negative')} **Conta Inválida!**\n\nO nome de usuário \`${username}\` não foi encontrado no Roblox.\n\n**Possíveis motivos:**\n○ Nome digitado incorretamente\n○ Conta não existe\n○ Erro temporário na API do Roblox\n\nClique em **Tentar Novamente** para corrigir o nome de usuário.`,
                                components: [rowTentarNovamente],
                                ephemeral: true
                            });
                        } else {
                            await interaction.deferUpdate();
                            await interaction.editReply({
                                content: `${Emojis.get('negative')} **Conta Inválida!**\n\nO nome de usuário \`${username}\` não foi encontrado no Roblox.\n\n**Possíveis motivos:**\n○ Nome digitado incorretamente\n○ Conta não existe\n○ Erro temporário na API do Roblox\n\nClique em **Tentar Novamente** para corrigir o nome de usuário.`,
                                embeds: [],
                                components: [rowTentarNovamente],
                                flags: [64]
                            });
                        }
                        return;
                    }

                    if (isThread) {
                        await interaction.deferReply({ ephemeral: true });

                        const messages = await interaction.channel.messages.fetch({ limit: 10 });
                        const containerMessages = messages.filter(msg => 
                            msg.author.id === client.user.id && 
                            (msg.content.includes('Pedido -') || msg.content.includes('Confirmar user roblox'))
                        );

                        for (const msg of containerMessages.values()) {
                            try {
                                await msg.delete();
                            } catch (err) {
                                console.error('[Delete Container] Erro:', err);
                            }
                        }

                        const sucesso = await DentroCarrinhoRobux(interaction.channel, interaction.guild, quantidade, tipoTaxa, username, precoUnitario, valorTotal);

                        if (!sucesso) {
                            return interaction.editReply({
                                content: `${Emojis.get('negative')} Erro ao validar conta do Roblox. Tente novamente.`
                            });
                        }

                        await interaction.editReply({
                            content: `${Emojis.get('checker')} Username corrigido com sucesso! Verifique as informações acima.`
                        });

                    } else {
                        const thread = await interaction.channel.threads.create({
                            name: `💎・${interaction.user.username}・${interaction.user.id}`,
                            autoArchiveDuration: 60,
                            type: ChannelType.PrivateThread,
                        });

                        const cargoAdmin = configuracao.get('ConfigRoles.admrole');
                        const mentionContent = cargoAdmin ? `<@&${cargoAdmin}> ${interaction.user}` : `${interaction.user}`;
                        
                        await thread.send({ content: mentionContent });

                        const sucesso = await DentroCarrinhoRobux(thread, interaction.guild, quantidade, tipoTaxa, username, precoUnitario, valorTotal);

                        if (!sucesso) {
                            await thread.delete();
                            return interaction.reply({
                                content: `${Emojis.get('negative')} Erro ao validar conta do Roblox. Tente novamente.`,
                                ephemeral: true
                            });
                        }

                        const { res } = require("../../res");
                        
                        const containerSucesso = res.main(
                            { type: 10, content: `# ${Emojis.get('checker')} Carrinho Criado com Sucesso!` },
                            { type: 14 },
                            { type: 10, content: `Seu carrinho foi aberto com sucesso! Clique no botão abaixo para acessá-lo.` },
                            { type: 14 },
                            {
                                type: 1,
                                components: [
                                    { 
                                        type: 2, 
                                        style: 5, 
                                        label: 'Ir para o carrinho', 
                                        url: `https://discord.com/channels/${interaction.guild.id}/${thread.id}`,
                                        emoji: { name: '🛒' }
                                    }
                                ]
                            }
                        ).with({});

                        await interaction.update(containerSucesso);
                    }

                } catch (error) {
                    console.error('[Modal Robux Username] Erro:', error);
                    if (interaction.deferred || interaction.replied) {
                        await interaction.editReply({
                            content: `${Emojis.get('negative')} Erro ao processar. Tente novamente.`
                        });
                    } else {
                        await interaction.reply({
                            content: `${Emojis.get('negative')} Erro ao processar. Tente novamente.`,
                            ephemeral: true
                        });
                    }
                }
                return;
            }

            if (interaction.customId.startsWith('modal_robux_dados_')) {
                const tipoRobux = interaction.customId.replace('modal_robux_dados_', '');
                const username = interaction.fields.getTextInputValue('robux_username');
                const quantidadeStr = interaction.fields.getTextInputValue('robux_quantidade');
                
                const quantidade = parseInt(quantidadeStr);
                if (isNaN(quantidade) || quantidade <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Quantidade inválida! Digite apenas números.`,
                        ephemeral: true
                    });
                }

                const { res } = require("../../res");
                
                const containerAguarde = res.main(
                    { type: 10, content: `## ${Emojis.get('loading')} | Aguarde Criando Carrinho` },
                    { type: 10, content: `Estamos criando seu carrinho, aguarde um momento...` }
                ).with({});

                await interaction.update(containerAguarde);

                try {
                    const { ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
                    const { carrinhosrobux, configuracao, Systemrobux } = require("../../DataBaseJson");

                    const thread = await interaction.channel.threads.create({
                        name: `💎・${interaction.user.username}・${interaction.user.id}`,
                        autoArchiveDuration: 60,
                        type: ChannelType.PrivateThread,
                    });

                    const precoComTaxa = parseFloat(Systemrobux.get('preco_com_taxa'));
                    const precoSemTaxa = parseFloat(Systemrobux.get('preco_sem_taxa'));
                    const precoUnitario = tipoRobux === 'com_taxa' ? precoComTaxa : precoSemTaxa;
                    const valorTotal = (quantidade / 1000) * precoUnitario;

                    await carrinhosrobux.set(thread.id, { 
                        user: interaction.user, 
                        guild: interaction.guild, 
                        threadid: thread.id, 
                        tipo: 'robux',
                        tipoRobux: tipoRobux,
                        username: username,
                        quantidade: quantidade,
                        precoUnitario: precoUnitario,
                        valorTotal: valorTotal.toFixed(2),
                        precoComTaxa: precoComTaxa,
                        precoSemTaxa: precoSemTaxa
                    });

                    const cargoAdmin = configuracao.get('ConfigRoles.admrole');
                    const mentionContent = cargoAdmin ? `<@&${cargoAdmin}> ${interaction.user}` : `${interaction.user}`;
                    
                    await thread.send({ content: mentionContent });

                    const { DentroCarrinhoRobux } = require("../../Functions/DentroCarrinhoRobux");
                    await DentroCarrinhoRobux(thread, interaction.guild);

                    const containerSucesso = res.main(
                        { type: 10, content: `## ${Emojis.get('checker')} Carrinho Criado Com Sucesso` },
                        { type: 10, content: `Seu carrinho foi aberto com sucesso!` },
                        { type: 14 },
                        { type: 10, content: `Nosso atendimento é **100% automático**, portanto responda apenas o que o bot perguntar.` }
                    ).with({
                        components: [
                            new ActionRowBuilder().addComponents(
                                new ButtonBuilder()
                                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${thread.id}`)
                                    .setLabel('Ir para o carrinho')
                                    .setStyle(ButtonStyle.Link)
                            )
                        ]
                    });

                    await interaction.editReply(containerSucesso);

                } catch (error) {
                    console.error('[Modal Robux Dados] Erro:', error);
                    const containerErro = res.main(
                        { type: 10, content: `## ${Emojis.get('negative')} Erro ao Criar Carrinho` },
                        { type: 10, content: `Ocorreu um erro ao criar seu carrinho. Tente novamente.` }
                    ).with({});
                    
                    await interaction.editReply(containerErro);
                }
                return;
            }

            if (interaction.customId === 'modal_robux_msg_titulo') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const titulo = interaction.fields.getTextInputValue('titulo');
                
                if (titulo.length > 256) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} O título não pode ter mais de 256 caracteres!`,
                        ephemeral: true
                    });
                }
                
                Systemrobux.set('mensagem_titulo', titulo);
                
                const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_titulo")
                        .setLabel("Editar Título")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_descricao")
                        .setLabel("Editar Descrição")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_cor")
                        .setLabel("Editar Cor")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2)
                );
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Configuração Atual:**\n- Título: \`${titulo}\`\n- Descrição: \`${descricao}\`\n- Cor: \`${cor}\`` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Título configurado com sucesso!`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_robux_msg_descricao') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const descricao = interaction.fields.getTextInputValue('descricao');
                
                if (descricao.length > 4000) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} A descrição não pode ter mais de 4000 caracteres!`,
                        ephemeral: true
                    });
                }
                
                Systemrobux.set('mensagem_descricao', descricao);
                
                const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_titulo")
                        .setLabel("Editar Título")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_descricao")
                        .setLabel("Editar Descrição")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_cor")
                        .setLabel("Editar Cor")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2)
                );
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Configuração Atual:**\n- Título: \`${titulo}\`\n- Descrição: \`${descricao}\`\n- Cor: \`${cor}\`` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Descrição configurada com sucesso!`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_robux_msg_cor') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                let cor = interaction.fields.getTextInputValue('cor').trim();
                
                if (!cor.startsWith('#')) {
                    cor = '#' + cor;
                }
                
                const hexColorRegex = /^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/;
                if (!hexColorRegex.test(cor)) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Código Hex Color \`${cor}\` inválido! Use formato como #2b2d31 ou 2b2d31`,
                        ephemeral: true
                    });
                }
                
                Systemrobux.set('mensagem_cor', cor);
                
                const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_titulo")
                        .setLabel("Editar Título")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_descricao")
                        .setLabel("Editar Descrição")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_editar_cor")
                        .setLabel("Editar Cor")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2)
                );
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Configuração Atual:**\n- Título: \`${titulo}\`\n- Descrição: \`${descricao}\`\n- Cor: \`${cor}\`` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Cor configurada com sucesso!`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_robux_config_mensagem') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const titulo = interaction.fields.getTextInputValue('titulo');
                const descricao = interaction.fields.getTextInputValue('descricao');
                let banner = interaction.fields.getTextInputValue('banner').trim();
                
                if (titulo.length > 256) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} O título não pode ter mais de 256 caracteres!`,
                        ephemeral: true
                    });
                }
                
                if (descricao.length > 4000) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} A descrição não pode ter mais de 4000 caracteres!`,
                        ephemeral: true
                    });
                }
                
                if (banner !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(banner)) {
                        return interaction.reply({
                            content: `${Emojis.get('negative')} URL do banner inválida!`,
                            ephemeral: true
                        });
                    }
                    Systemrobux.set('mensagem_banner', banner);
                } else {
                    Systemrobux.set('mensagem_banner', null);
                }
                
                Systemrobux.set('mensagem_titulo', titulo);
                Systemrobux.set('mensagem_descricao', descricao);
                
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const modo = Systemrobux.get('mensagem_modo') || 'container';
                
                const modoTexto = modo === 'container' ? '``Component v2 (Container)``' : '``Embed``';
                
                const tituloConfigurado = titulo !== '💎 Comprar Robux';
                const descricaoConfigurada = descricao !== 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const corConfigurada = cor !== '#2b2d31';
                
                const tituloStatus = tituloConfigurado ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const descricaoStatus = descricaoConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const bannerStatus = banner ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const corStatus = corConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                
                const rowBotoes1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_alterar_modo")
                        .setLabel("Alterar Modo")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_configurar")
                        .setLabel("Configurar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_resetar")
                        .setLabel("Resetar Config Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(4)
                );
                
                const rowBotoes2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_preview")
                        .setLabel("Ver Preview")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_postar")
                        .setLabel("Postar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(3),
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Informações Detalhadas**\n- Modo: ${modoTexto}\n- Título: ${tituloStatus}\n- Descrição: ${descricaoStatus}\n- Banner: ${bannerStatus}\n- Cor: ${corStatus}` },
                    { type: 14 },
                    { type: 10, content: `**Funcionalidades:**\n- Altere entre modo Container ou Embed\n- Configure título, descrição, banner e cor da mensagem\n- Visualize um preview antes de postar\n- Poste a mensagem no canal de vendas configurado` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes1, rowBotoes2],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Mensagem configurada com sucesso!`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_calc_reais_robux') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                let valorReais = interaction.fields.getTextInputValue('valor_reais');
                
                valorReais = parseFloat(valorReais.replace(',', '.'));
                
                if (isNaN(valorReais) || valorReais <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Valor inválido! Use apenas números.`,
                        ephemeral: true
                    });
                }
                
                const precoComTaxa = parseFloat(Systemrobux.get('preco_com_taxa'));
                const precoSemTaxa = parseFloat(Systemrobux.get('preco_sem_taxa'));
                
                if (isNaN(precoComTaxa) || isNaN(precoSemTaxa)) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Preços não configurados! Configure os preços primeiro.`,
                        ephemeral: true
                    });
                }
                
                const robuxComTaxa = Math.floor((valorReais / precoComTaxa) * 1000);
                const robuxSemTaxa = Math.floor((valorReais / precoSemTaxa) * 1000);
                
                await interaction.reply({
                    content: `## Resultado da Conversão\n\n` +
                             `**Valor em Reais:** R$ ${valorReais.toFixed(2)}\n\n` +
                             `**Com Taxa:**\n` +
                             `> ${robuxComTaxa.toLocaleString('pt-BR')} Robux\n` +
                             `> (R$ ${precoComTaxa}/1k)\n\n` +
                             `**Sem Taxa:**\n` +
                             `> ${robuxSemTaxa.toLocaleString('pt-BR')} Robux\n` +
                             `> (R$ ${precoSemTaxa}/1k)`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId === 'modal_calc_robux_reais') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                let valorRobux = interaction.fields.getTextInputValue('valor_robux');
                
                valorRobux = parseInt(valorRobux.replace(/\D/g, ''));
                
                if (isNaN(valorRobux) || valorRobux <= 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Valor inválido! Use apenas números.`,
                        ephemeral: true
                    });
                }
                
                const precoComTaxa = parseFloat(Systemrobux.get('preco_com_taxa'));
                const precoSemTaxa = parseFloat(Systemrobux.get('preco_sem_taxa'));
                
                if (isNaN(precoComTaxa) || isNaN(precoSemTaxa)) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Preços não configurados! Configure os preços primeiro.`,
                        ephemeral: true
                    });
                }
                
                const reaisComTaxa = (valorRobux / 1000) * precoComTaxa;
                const reaisSemTaxa = (valorRobux / 1000) * precoSemTaxa;
                
                await interaction.reply({
                    content: `## Resultado da Conversão\n\n` +
                             `**Quantidade de Robux:** ${valorRobux.toLocaleString('pt-BR')}\n\n` +
                             `**Com Taxa:**\n` +
                             `> R$ ${reaisComTaxa.toFixed(2)}\n` +
                             `> (R$ ${precoComTaxa}/1k)\n\n` +
                             `**Sem Taxa:**\n` +
                             `> R$ ${reaisSemTaxa.toFixed(2)}\n` +
                             `> (R$ ${precoSemTaxa}/1k)`,
                    ephemeral: true
                });
                return;
            }

            if (interaction.customId == 'sdaju11111231idsj1233js123dua123') {
                let NOME = interaction.fields.getTextInputValue('tokenMP');
                let PREDESC = interaction.fields.getTextInputValue('tokenMP2');
                let DESC = interaction.fields.getTextInputValue('tokenMP3');
                let BANNER = interaction.fields.getTextInputValue('tokenMP5');
                let EMOJI = interaction.fields.getTextInputValue('tokenMP6');

                NOME = NOME.replace('.', '');
                PREDESC = PREDESC.replace('.', '');

                if (tickets.get(`tickets.funcoes.${NOME}`) !== null) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Já existe uma função com esse nome!`, ephemeral: true });
                }

                if (NOME.length > 32) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O nome não pode ter mais de 32 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.nome`, NOME)
                }

                if (PREDESC.length > 64) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | A pré descrição não pode ter mais de 64 caracteres!`, ephemeral: true });
                } else {
                    tickets.set(`tickets.funcoes.${NOME}.predescricao`, PREDESC)
                }

                if (DESC !== '') {
                    if (DESC.length > 1024) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.descricao`, DESC)
                    }
                }

                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                        return interaction.reply({ message: dd, content: `${Emojis.get('negative')} | Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    } else {
                        tickets.set(`tickets.funcoes.${NOME}.banner`, BANNER)
                    }
                }

                if (EMOJI !== '') {
                    const emojiRegex = /^<:.+:\d+>$|^<a:.+:\d+>$|^\p{Emoji}$/u;
                    if (!emojiRegex.test(EMOJI)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o emoji!`, ephemeral: true });
                    } else {
                        const emojiIdMatch = EMOJI.match(/:(\d+)>/);
                        if (emojiIdMatch) {
                            const emojiId = emojiIdMatch[1];
                            console.log(`[Ticket] Salvando emoji ID: ${emojiId}`);
                            tickets.set(`tickets.funcoes.${NOME}.emoji`, emojiId);
                        } else {
                            console.log(`[Ticket] Salvando emoji unicode: ${EMOJI}`);
                            tickets.set(`tickets.funcoes.${NOME}.emoji`, EMOJI);
                        }
                    }
                }

                await painelTicket(interaction)

                interaction.followUp({ content: `${Emojis.get('checker')} | Função adicionada com sucesso!`, ephemeral: true });




            }

            if (interaction.customId == '0-89du0awd8awdaw8daw') {

                let TITULO = interaction.fields.getTextInputValue('tokenMP');
                let DESC = interaction.fields.getTextInputValue('tokenMP2');
                let BANNER = interaction.fields.getTextInputValue('tokenMP3');
                let COREMBED = interaction.fields.getTextInputValue('tokenMP5');

                if (TITULO.length > 256) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O título não pode ter mais de 256 caracteres!`, ephemeral: true });
                }
                if (DESC.length > 1024) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | A descrição não pode ter mais de 1024 caracteres!`, ephemeral: true });
                }

                if (COREMBED !== '') {
                    const hexColorRegex = /^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/;
                    if (!hexColorRegex.test(COREMBED)) {
                        
                        return interaction.reply({ content: `${Emojis.get('negative')} Código Hex Color \`${COREMBED}\` inváldo, tente pegar [nesse site.](https://www.google.com/search?q=color+picker&oq=color+picker) `, ephemeral: true });
                    }else{
                        tickets.set(`tickets.aparencia.color`, COREMBED)
                    }
                }



                if (BANNER !== '') {
                    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
                    if (!urlRegex.test(BANNER)) {
                     
                        return interaction.reply({ message: dd, content: `${Emojis.get('negative')} | Você escolheu incorretamente a URL do banner!`, ephemeral: true });
                    }else{
                        tickets.set(`tickets.aparencia.banner`, BANNER)
                    }
                }

                if (TITULO !== '') {
                    tickets.set(`tickets.aparencia.title`, TITULO)
                } else {
                    tickets.delete(`tickets.aparencia.title`)
                }

                if (DESC !== '') {
                    tickets.set(`tickets.aparencia.description`, DESC)
                } else {
                    tickets.delete(`tickets.aparencia.description`)
                }

                await painelTicket(interaction)


            }

      


            if (interaction.customId === 'aslfdjauydvaw769dg7waajnwndjo') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos1.role`, CARGO);
                    configuracao.set(`posicoes.pos1.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos1`);
                }

                await Posicao1(interaction, client)

            }

            if (interaction.customId === 'awiohdbawudwdwhduawdnuaw') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');


                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos2.role`, CARGO);
                    configuracao.set(`posicoes.pos2.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos2`);
                }

                await Posicao1(interaction, client)
            }

            if (interaction.customId === 'uy82819171h172') {

                let VALOR = interaction.fields.getTextInputValue('tokenMP');
                let CARGO = interaction.fields.getTextInputValue('tokenMP2');

                if (CARGO !== '' && VALOR !== '') {
                    const role = await interaction.guild.roles.fetch(CARGO);

                    if (role === null) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o ID do cargo!`, ephemeral: true });
                    }

                    if (isNaN(VALOR)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Você escolheu incorretamente o valor!`, ephemeral: true });
                    }

                    configuracao.set(`posicoes.pos3.role`, CARGO);
                    configuracao.set(`posicoes.pos3.valor`, VALOR);
                } else {
                    configuracao.delete(`posicoes.pos3`);
                }

                await Posicao1(interaction, client)
            }

            if (interaction.customId === 'modal_adicionar_perm') {
                await HandleAdicionarPerm(interaction, client);
            }

            if (interaction.customId === 'modal_remover_perm') {
                await HandleRemoverPerm(interaction, client);
            }

            if (interaction.customId === 'modal_editar_prompt_ia') {
                await HandleEditarPrompt(interaction, client);
            }

            if (interaction.customId === 'modal_editar_aparencia_ticket') {
                await HandleEditarAparencia(interaction, client);
            }

            if (interaction.customId === 'modal_adicionar_funcao_ticket') {
                await HandleAdicionarFuncao(interaction, client);
            }

            if (interaction.customId.startsWith('modal_editar_funcao_')) {
                const funcaoId = interaction.customId.replace('modal_editar_funcao_', '');
                await HandleEditarFuncaoEspecifica(interaction, client, funcaoId);
            }

            if (interaction.customId === 'modal_config_horarios_ticket') {
                await HandleConfigurarHorarios(interaction, client);
            }

            if (interaction.customId === 'modal_criar_painel_ticket') {
                await HandleCriarPainelTicket(interaction);
            }

            if (interaction.customId.startsWith('modal_addfuncao_')) {
                const painelId = interaction.customId.replace('modal_addfuncao_', '');
                await HandleAddFuncaoTicket(interaction, painelId);
            }

            if (interaction.customId.startsWith('modal_editar_')) {
                const painelId = interaction.customId.replace('modal_editar_', '');
                await HandleEditarPainel(interaction, painelId);
                return;
            }

            if (interaction.customId === 'modal_criar_sorteio') {
                const titulo = interaction.fields.getTextInputValue('sorteio_titulo');
                const descricao = interaction.fields.getTextInputValue('sorteio_descricao');
                const vencedores = interaction.fields.getTextInputValue('sorteio_vencedores');

                if (isNaN(vencedores) || parseInt(vencedores) < 1) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O número de vencedores deve ser um número válido maior que 0!`, ephemeral: true });
                }

                const sorteioId = gerarIdSorteio();
                
                sorteios.set(sorteioId, {
                    id: sorteioId,
                    titulo: titulo,
                    descricao: descricao,
                    vencedores: parseInt(vencedores),
                    criador: interaction.user.id,
                    criadoEm: Date.now(),
                    status: "configurando",
                    participantes: []
                });

                await PaginaSetarTempo(interaction, sorteioId);
            }

            if (interaction.customId.startsWith('modal_tempo_personalizado_')) {
                const sorteioId = interaction.customId.replace('modal_tempo_personalizado_', '');
                const tempoStr = interaction.fields.getTextInputValue('tempo_personalizado');
                
                const tempoMs = parseTime(tempoStr);
                
                if (tempoMs <= 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Formato de tempo inválido! Use: m = minutos, h = horas, d = dias\nExemplos: 30m, 2h, 1d, 1d 2h 30m`, ephemeral: true });
                }

                const maxTempo = 30 * 24 * 60 * 60 * 1000;
                if (tempoMs > maxTempo) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | O tempo máximo é de 30 dias!`, ephemeral: true });
                }

                sorteios.set(`${sorteioId}.duracao`, tempoMs);

                await PaginaEscolherCanal(interaction, sorteioId);
            }

            if (interaction.customId.startsWith('modal_addtempo_')) {
                const sorteioId = interaction.customId.replace('modal_addtempo_', '');
                const tempoStr = interaction.fields.getTextInputValue('tempo_adicionar');
                
                const tempoMs = parseTime(tempoStr);
                
                if (tempoMs <= 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Formato de tempo inválido! Use: m = minutos, h = horas, d = dias\nExemplos: 30m, 2h, 1d`, ephemeral: true });
                }

                const sorteioData = sorteios.get(sorteioId);
                if (!sorteioData) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Sorteio não encontrado!`, ephemeral: true });
                }

                const novoFinalizaEm = sorteioData.finalizaEm + tempoMs;
                sorteios.set(`${sorteioId}.finalizaEm`, novoFinalizaEm);
                sorteios.set(`${sorteioId}.duracao`, sorteioData.duracao + tempoMs);

                await interaction.reply({ content: `${Emojis.get('checker')} | Tempo adicionado! Nova finalização: <t:${Math.floor(novoFinalizaEm / 1000)}:R>`, ephemeral: true });
            }

            if (interaction.customId === 'modal_stock_titulo') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.titulo = valor;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_descricao') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.descricao = valor;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_cor') {
                const valor = interaction.fields.getTextInputValue('valor');
                if (!/^#?([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/.test(valor)) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Cor inválida! Use formato hex (ex: #5865F2)`, ephemeral: true });
                }
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.cor = valor.startsWith('#') ? valor : `#${valor}`;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_imagem') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.imagem = valor || null;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_thumbnail') {
                const valor = interaction.fields.getTextInputValue('valor');
                const embedConfig = configuracao.get('solicitarStock.embed') || {};
                embedConfig.thumbnail = valor || null;
                configuracao.set('solicitarStock.embed', embedConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_botao_msg') {
                const valor = interaction.fields.getTextInputValue('valor');
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.mensagem = valor;
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_botao_emoji') {
                const valor = interaction.fields.getTextInputValue('valor');
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.emoji = valor || null;
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_stock_botao_cor') {
                const valor = interaction.fields.getTextInputValue('valor');
                if (!['1', '2', '3', '4'].includes(valor)) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Cor inválida! Use 1=Azul, 2=Cinza, 3=Verde, 4=Vermelho`, ephemeral: true });
                }
                const botaoConfig = configuracao.get('solicitarStock.botao') || {};
                botaoConfig.cor = parseInt(valor);
                configuracao.set('solicitarStock.botao', botaoConfig);
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                await PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'modal_solicitar_estoque') {
                const { EnviarLogSolicitacao } = require("../../Functions/PainelSolicitarStock.js");
                await EnviarLogSolicitacao(interaction, client);
            }

            if (interaction.customId === 'modal_definir_horario_nuke') {
                const { loadNukeData, saveNukeData, painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                const horario = interaction.fields.getTextInputValue('horario_nuke');

                const horarioRegex = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
                if (!horarioRegex.test(horario)) {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative')} | Formato de horário inválido! Use HH:MM (ex: 03:00)`, 
                        ephemeral: true 
                    });
                    return;
                }

                const data = loadNukeData();
                data.horario = horario;
                saveNukeData(data);

                await interaction.deferUpdate();
                await painelNukeAutomatico(interaction, client);
            }

            if (interaction.customId === 'modal_definir_horarios_autolock') {
                const { loadAutolockData, saveAutolockData, painelAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                const { iniciarAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockexecutor.js");
                
                const guildId = interaction.guild.id;
                const horarioBloquear = interaction.fields.getTextInputValue('horario_bloquear');
                const horarioDesbloquear = interaction.fields.getTextInputValue('horario_desbloquear');

                const horarioRegex = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
                if (!horarioRegex.test(horarioBloquear) || !horarioRegex.test(horarioDesbloquear)) {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative')} | Formato de horário inválido! Use HH:MM (ex: 00:00)`, 
                        ephemeral: true 
                    });
                    return;
                }

                const data = loadAutolockData(guildId);
                data.horarioBloquear = horarioBloquear;
                data.horarioDesbloquear = horarioDesbloquear;
                saveAutolockData(guildId, data);

                if (data.ativo) {
                    iniciarAutoLock(client, guildId);
                }

                await interaction.deferUpdate();
                await painelAutoLock(interaction, client);
            }

            if (interaction.customId === 'modal_definir_horario_limpeza') {
                const { loadLimpezaData, saveLimpezaData, painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                const horario = interaction.fields.getTextInputValue('horario_limpeza');

                const horarioRegex = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
                if (!horarioRegex.test(horario)) {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative')} | Formato de horário inválido! Use HH:MM (ex: 03:00)`, 
                        ephemeral: true 
                    });
                    return;
                }

                const data = loadLimpezaData();
                data.horario = horario;
                saveLimpezaData(data);

                await interaction.deferUpdate();
                await painelLimpezaAutomatica(interaction, client);
            }

        }

        if (interaction.isAutocomplete()) {
            if (interaction.commandName === 'manage_item') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(produto => produto.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);
        
                const config = produtosSelecionados.flatMap(produto => {
                    if (produto.data && produto.data.Campos) {
                        const matchingFields = produto.data.Campos.filter(campo =>
                            campo.Nome.toLowerCase().includes(nomeDigitado)
                        );
        
                        return matchingFields.map(campo => ({
                            name: `🧵 ${campo.Nome}`,
                            value: `${produto.ID}_${campo.Nome}`,
                        }));
                    } else {
                        return [];
                    }
                });
        
                const response = config.length > 25 ? config.slice(0, 25) : config;
        
                interaction.respond(response);
            }        

            if (interaction.commandName === 'manage_stock') {
                const nomeDigitado = interaction.options.getFocused().toLowerCase();
                const produtosFiltrados = produtos.filter(produto => produto.ID.toLowerCase().includes(nomeDigitado));
                const produtosSelecionados = produtosFiltrados.slice(0, 25);
            
                const response = produtosSelecionados.map(produto => {
                const name = produto.data.Config ? produto.data.Config.name : "Nome Não Disponível";
            
                    const option = {
                        name: `🧵 ${name}`,
                        value: produto.ID
                    };
            
                    if (JSON.stringify(option).length > 100) {
                        option.name = option.name.substring(0, 90) + '...';
                        option.value = option.value.substring(0, 90) + '...';
                    }
            
                    return option;
                });
                
                interaction.respond(response.length > 0 ? response : [{ name: 'Nenhum produto registrado foi encontrado', value: 'nada' }]);
            }
            


            if (interaction.commandName == 'manage_product') {
                var nomeDigitado = interaction.options.getFocused().toLowerCase();
                var produtosFiltrados = produtos.filter(x => x.ID.toLowerCase().includes(nomeDigitado));
                var produtosSelecionados = produtosFiltrados.slice(0, 25);

                const config = produtosSelecionados.map(x => {
                    const name = x.data.Config ? x.data.Config.name : "Nome Não Disponível";
                    return {
                        name: `🧵 ${name}`,
                        value: `${x.ID}`
                    };
                });
                
                interaction.respond(!config.length ? [{ name: `${Emojis.get('negative')} Nenhum produto registrado foi encontrado`, value: `nada` }] : config);

            }
        }

        if (interaction.isButton() && interaction.customId.startsWith('gerar_transcript_')) {
            try {
                await interaction.deferUpdate();
                
                const transcriptId = interaction.customId.replace('gerar_transcript_', '');
                const { transcript } = require("../../DataBaseJson");
                const transcriptData = transcript.get(transcriptId);

                if (!transcriptData) {
                    return interaction.followUp({ content: `${Emojis.get('negative')} | Transcript não encontrado.` });
                }

                let transcriptText = `═══════════════════════════════════════\n`;
                transcriptText += `       TRANSCRIPT - ${transcriptData.guildName}\n`;
                transcriptText += `═══════════════════════════════════════\n\n`;
                transcriptText += `Categoria: ${transcriptData.categoria}\n`;
                transcriptText += `Fechado por: ${transcriptData.fechadoPor}\n`;
                transcriptText += `Data: ${transcriptData.fechadoEm}\n`;
                transcriptText += `Total de mensagens: ${transcriptData.mensagens.length}\n\n`;
                transcriptText += `───────────────────────────────────────\n`;
                transcriptText += `                MENSAGENS\n`;
                transcriptText += `───────────────────────────────────────\n\n`;

                for (const msg of transcriptData.mensagens) {
                    transcriptText += `[${msg.timestamp}] ${msg.author}:\n${msg.content}\n\n`;
                }

                transcriptText += `═══════════════════════════════════════\n`;
                transcriptText += `           FIM DO TRANSCRIPT\n`;
                transcriptText += `═══════════════════════════════════════`;

                const buffer = Buffer.from(transcriptText, 'utf-8');

                await interaction.followUp({ 
                    content: `${Emojis.get('checker')} | Aqui está o transcript do seu atendimento:`,
                    files: [{ attachment: buffer, name: `transcript_${transcriptData.categoria}.txt` }]
                });

                transcript.delete(transcriptId);

                const disabledContainer = res.main(
                    { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                    { type: 14 },
                    { type: 10, content: `> Seu ticket de **${transcriptData.categoria}** foi encerrado.` },
                    { type: 14 },
                    { type: 10, content: `**Fechado por**\n${transcriptData.fechadoPor}` },
                    { type: 10, content: `**Data**\n${transcriptData.fechadoEm}` },
                    { type: 14 },
                    { type: 10, content: `-# Transcript já foi gerado.` },
                    { type: 1, components: [{ type: 2, style: 2, label: 'Transcript Gerado', custom_id: 'transcript_usado', emoji: { id: '1384035207598051431' }, disabled: true }] }
                );

                await interaction.message.edit(disabledContainer);
            } catch (error) {
                console.error('Erro ao gerar transcript:', error);
                try {
                    await interaction.followUp({ content: `${Emojis.get('negative')} | Erro ao gerar transcript.` });
                } catch {}
            }
            return;
        }

        let valorticket
        if (interaction.isButton() && interaction.customId.startsWith('AbrirTicket_')) {
            const fullId = interaction.customId.replace('AbrirTicket_', '');
            const lastUnderscoreIndex = fullId.lastIndexOf('_');
            const funcaoIdEncoded = fullId.substring(lastUnderscoreIndex + 1);
            const painelId = fullId.substring(0, lastUnderscoreIndex);
            
            const funcaoId = Buffer.from(funcaoIdEncoded, 'base64').toString('utf-8');
            
            console.log(`[Ticket] Abrindo ticket - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
            CreateTicket(interaction, painelId, funcaoId)
        } else if (interaction.isSelectMenu() && interaction.customId === 'abrirticket') {
            valorticket = interaction.values[0]
            CreateTicket(interaction, null, valorticket)
        } else if (interaction.isSelectMenu() && interaction.customId.startsWith('ticket_abrir_select_')) {
            const selectedValue = interaction.values[0];
            const fullId = selectedValue.replace('abrirticket_', '');
            const lastUnderscoreIndex = fullId.lastIndexOf('_');
            const funcaoIdEncoded = fullId.substring(lastUnderscoreIndex + 1);
            const painelId = fullId.substring(0, lastUnderscoreIndex);
            
            const funcaoId = Buffer.from(funcaoIdEncoded, 'base64').toString('utf-8');
            
            console.log(`[Ticket] Abrindo ticket via select - PainelId: ${painelId}, FuncaoId: ${funcaoId}`);
            CreateTicket(interaction, painelId, funcaoId)
        }

        if (interaction.isSelectMenu()) {

            if (interaction.customId === 'staff_acoes_ticket') {
                const acao = interaction.values[0];

                if (acao === 'assumir_ticket') {
                    let ticketId = interaction.channel.id;
                    const { Temporario } = require("../../DataBaseJson");
                    
                    if (Temporario.get(`ticket_assumido_${ticketId}`)) {
                        const staffId = Temporario.get(`ticket_assumido_${ticketId}`);
                        return interaction.update({ content: `${Emojis.get('negative')} | Este ticket já foi assumido por <@${staffId}>.`, components: [] });
                    }

                    const staffMember = interaction.member;
                    
                    let ownerId = Temporario.get(`ticket_owner_${ticketId}`);
                    if (!ownerId) {
                        const ultimoIndice = interaction.channel.name.lastIndexOf('・');
                        ownerId = interaction.channel.name.slice(ultimoIndice + 1);
                    }

                    if (!ownerId || !/^\d+$/.test(ownerId)) {
                        return interaction.update({ content: `${Emojis.get('negative')} | Não foi possível identificar o dono do ticket.`, components: [] });
                    }

                    try {
                        const owner = await interaction.guild.members.fetch(ownerId);

                        Temporario.set(`ticket_assumido_${ticketId}`, staffMember.id);

                        const confirmationEmbed = new EmbedBuilder()
                            .setColor('#2b2d31')
                            .setDescription(`${Emojis.get('checker')} | Olá <@!${ownerId}>, Seu Ticket foi Assumido por ${staffMember}.`);

                        const buttonRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Ir para o Ticket')
                                .setStyle(5)
                                .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
                        );

                        try {
                            await owner.send({ embeds: [confirmationEmbed], components: [buttonRow] });
                        } catch {}

                        await interaction.update({ content: `${Emojis.get('checker')} | Ticket assumido com sucesso!`, components: [] });
                        await interaction.channel.send({ content: `${Emojis.get('checker')} | Ticket assumido por ${staffMember}!` });
                    } catch (error) {
                        console.error("Erro ao assumir ticket:", error);
                        await interaction.update({ content: `${Emojis.get('negative')} | Erro ao assumir ticket.`, components: [] });
                    }
                    return;
                }

                if (acao === 'renomear_ticket') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_renomear_ticket')
                        .setTitle('Renomear Ticket')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('novo_nome_ticket')
                                    .setLabel('Novo nome do ticket')
                                    .setPlaceholder('Digite o novo nome...')
                                    .setStyle(TextInputStyle.Short)
                                    .setMaxLength(100)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }

                if (acao === 'adicionar_usuario') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_adicionar_usuario_ticket')
                        .setTitle('Adicionar Usuário')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('usuario_id_adicionar')
                                    .setLabel('ID do usuário')
                                    .setPlaceholder('Digite o ID do usuário para adicionar...')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }

                if (acao === 'remover_usuario') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_remover_usuario_ticket')
                        .setTitle('Remover Usuário')
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId('usuario_id_remover')
                                    .setLabel('ID do usuário')
                                    .setPlaceholder('Digite o ID do usuário para remover...')
                                    .setStyle(TextInputStyle.Short)
                                    .setRequired(true)
                            )
                        );
                    await interaction.showModal(modal);
                    return;
                }
            }

            if (interaction.customId === 'ticket_selecionar_painel') {
                const painelId = interaction.values[0];
                if (painelId !== 'none') {
                    await PaginaGerenciarPainel(interaction, painelId);
                }
                return;
            }

            if (interaction.customId === 'ticket_acoes_select') {
                const selectedValue = interaction.values[0];
                const [acao, ...painelIdParts] = selectedValue.split('_');
                const painelId = painelIdParts.join('_');

                if (acao === 'editar') {
                    await ModalEditarPainel(interaction, painelId);
                } else if (acao === 'categorias') {
                    await PaginaCategorias(interaction, painelId);
                } else if (acao === 'exibicao') {
                    await AlternarExibicao(interaction, painelId);
                } else if (acao === 'apagar') {
                    await HandleDeletarPainel(interaction, painelId);
                } else if (acao === 'enviar') {
                    const selectChannel = new Discord.ChannelSelectMenuBuilder()
                        .setCustomId(`ticket_channel_postar_${painelId}`)
                        .setPlaceholder('Selecione o canal para postar')
                        .setChannelTypes(Discord.ChannelType.GuildText);
                    const row = new ActionRowBuilder().addComponents(selectChannel);
                    await interaction.reply({ content: `${Emojis.get('info')} | Selecione o canal:`, components: [row], ephemeral: true });
                } else if (acao === 'sincronizar') {
                    await SincronizarTicket(interaction, painelId, client);
                }
                return;
            }

            if (interaction.customId === 'ticket_select_remfuncao') {
                const [painelId, funcaoId] = interaction.values[0].split('_').slice(-2);
                const fullPainelId = interaction.values[0].replace(`_${funcaoId}`, '');
                await HandleRemoverFuncao(interaction, fullPainelId, funcaoId);
                return;
            }

            if (interaction.customId === 'ticket_select_modo_exibicao') {
                await HandleSelectModoExibicao(interaction, client);
            }

            if (interaction.customId === 'ticket_select_editar_funcao') {
                const funcaoId = interaction.values[0];
                return await ModalEditarFuncaoEspecifica(interaction, funcaoId);
            }

            if (interaction.customId === 'ticket_select_dias_folga') {
                await HandleConfigurarDiasFolga(interaction, client);
            }

            if (interaction.customId === 'ticket_select_funcao') {
                const { CreateTicket } = require("../../Functions/CreateTicket");
                const funcaoId = interaction.values[0];
                await CreateTicket(interaction, client, funcaoId);
                return;
            }

            if (interaction.customId === 'configproduto_page') {
                const { GerenciarProduto } = require("../../Functions/CreateProduto");
                GerenciarProduto(interaction, 2, interaction.values[0]);
                return;
            }

            if (interaction.customId == 'gerenciar_produtos_menu') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'criarrrr') {
                    const modalaAA = new ModalBuilder()
                        .setCustomId('sdaju11111idsjjsdua')
                        .setTitle(`Criação`);

                    const newnameboteN = new TextInputBuilder()
                        .setCustomId('tokenMP')
                        .setLabel(`NOME`)
                        .setPlaceholder(`Insira o nome do seu produto`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)

                    const newnameboteN2 = new TextInputBuilder()
                        .setCustomId('tokenMP2')
                        .setLabel(`DESCRIÇÃO`)
                        .setPlaceholder(`Insira uma descrição para seu produto`)
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                        .setMaxLength(1024)

                    const newnameboteN4 = new TextInputBuilder()
                        .setCustomId('tokenMP3')
                        .setLabel(`ENTREGA AUTOMÁTICA?`)
                        .setPlaceholder(`Digite "sim" ou "não"`)
                        .setStyle(TextInputStyle.Short)
                        .setMaxLength(3)
                        .setRequired(true)

                    const newnameboteN5 = new TextInputBuilder()
                        .setCustomId('tokenMP4')
                        .setLabel(`ICONE (OPCIONAL)`)
                        .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)

                    const newnameboteN6 = new TextInputBuilder()
                        .setCustomId('tokenMP5')
                        .setLabel(`BANNER (OPCIONAL)`)
                        .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)

                    const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                    const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                    const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                    const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                    const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);

                    modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                    await interaction.showModal(modalaAA);
                }
                
                if (selectedValue === 'gerenciarotemae') {
                    await mostrarPaginaProdutos(interaction, 0);
                }
                
                if (selectedValue === 'gerenciarposicao') {
                    Posicao1(interaction, client);
                }
                
                if (selectedValue === 'painel-solicitar-stock') {
                    const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                    PainelSolicitarStock(interaction, client);
                }
                
                if (selectedValue === 'altMoeda') {
                    await interaction.update({ content: `${Emojis.get('loading')} Carregando...`, embeds: [], components: [] });
                    moedaConfig(interaction, client);
                }
                
                if (selectedValue === 'instruçoes081') {
                    await interaction.reply({ content: `${Emojis.get('negative')} Esta função ainda está em desenvolvimento.`, ephemeral: true });
                }

                if (selectedValue === 'sistemasaldo') {
                    await interaction.reply({ content: `${Emojis.get('negative')} Esta função ainda está em desenvolvimento.`, ephemeral: true });
                }

                if (selectedValue === 'painel_botao_duvidas') {
                    const { PainelBotaoDuvidas } = require("../../Functions/ConfigAvancadas.js");
                    PainelBotaoDuvidas(interaction);
                }

                if (selectedValue === 'config_status_comercio') {
                    const { ConfigurarStatusComercio } = require("../../Functions/ConfigAvancadas.js");
                    ConfigurarStatusComercio(interaction);
                }

                if (selectedValue === 'painel_termos_loja') {
                    const { PainelTermosLoja } = require("../../Functions/ConfigAvancadas.js");
                    PainelTermosLoja(interaction);
                }

                if (selectedValue === 'personalizar_qrcode') {
                    const { configqrcode } = require("../../Functions/QRCode.js");
                    configqrcode(interaction, client);
                }
            }

            if (interaction.customId == 'gerenciar_configs_menu') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'configcargos') {
                    const { ConfigRoles } = require("../../Functions/ConfigRoles");
                    ConfigRoles(interaction, client);
                }
                
                if (selectedValue === 'personalizarcanais') {
                    const { ConfigChannels } = require("../../Functions/ConfigRoles");
                    ConfigChannels(interaction, client);
                }
                
                if (selectedValue === 'personalizarantifake') {
                    const modalaAA = new ModalBuilder()
                        .setCustomId('joaozinhoAntiFake')
                        .setTitle(`Configurar anti fake`);

                    const newnameboteN = new TextInputBuilder()
                        .setCustomId('tokenMP')
                        .setLabel(`QUANTIDADE DE DIAS MÍNIMA PARA ENTRAR`)
                        .setPlaceholder(`Digite "não" para desativar, serve para todos os campos.`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)

                    const newnameboteN2 = new TextInputBuilder()
                        .setCustomId('tokenMP2')
                        .setLabel(`LISTA DE STATUS QUE DESEJA BLOQUEAR`)
                        .setPlaceholder(`Digite separado por vírgual os status das contas que deseja punir se detectadas.`)
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                        .setMaxLength(4000)

                    const newnameboteN3 = new TextInputBuilder()
                        .setCustomId('tokenMP3')
                        .setLabel(`MENSAGEM DE BOAS VINDAS`)
                        .setPlaceholder(`Digite a mensagem de boas vindas que deseja enviar.`)
                        .setStyle(TextInputStyle.Paragraph)
                        .setRequired(true)
                        .setMaxLength(4000)

                    const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                    const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                    const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN3);

                    modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5);
                    await interaction.showModal(modalaAA);
                }
                
                if (selectedValue === 'formasdepagamentos') {
                    const { FormasDePagamentos } = require("../../Functions/FormasDePagamentosConfig");
                    FormasDePagamentos(interaction);
                }
                
                if (selectedValue === 'painelextensoes') {
                    const { PainelExtensoes } = require("../../Functions/Painel");
                    PainelExtensoes(interaction, client);
                }
            }

            if (interaction.customId === 'ilusioncloud_select_menu') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'oauth02') {
                    auth02api(interaction, client);
                }
                
                if (selectedValue === 'backup') {
                    const { PainelBackupSystem } = require('../../Functions/BackupSystem');
                    return PainelBackupSystem(interaction, client);
                }
            }

            if (interaction.customId === 'extensoes_select_menu') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'robux_system') {
                    return IlusionBux(interaction);
                }
                
                if (selectedValue === 'boosters_system') {
                    return interaction.reply({
                        content: `${Emojis.get('loading')} **Sistema em Desenvolvimento**\n\nO Sistema de Boosters Automáticos será adicionado em breve com recompensas automáticas para membros que impulsionam o servidor.`,
                        ephemeral: true
                    });
                }
            }

            if(interaction.customId == 'asdihadbhawhdwhdaw'){


                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]


                GerenciarCampos2(interaction, campo, produto, true)

            }

            if(interaction.customId == 'stockhasdhvsudasd'){

                const campo = interaction.values[0].split('_')[0]
                const produto = interaction.values[0].split('_')[1]

                MessageStock(interaction, 1, produto, campo, true)


            }

            if (interaction.customId == 'deletarticketsfunction') {
                const valordelete = interaction.values
                for (const iterator of valordelete) {
                    tickets.delete(`tickets.funcoes.${iterator}`)
                }
                painelTicket(interaction)
            }

            if (interaction.customId === 'robux_status_select') {
                const selectedValue = interaction.values[0];
                
                if (selectedValue === 'ativar_robux') {
                    robuxConfig.set(`config.status`, true);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Robux ativado com sucesso!`, ephemeral: true });
                }
                
                if (selectedValue === 'desativar_robux') {
                    robuxConfig.set(`config.status`, false);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Robux desativado com sucesso!`, ephemeral: true });
                }

                if (selectedValue === 'ativar_gamepass') {
                    robuxConfig.set(`config.statusGamepass`, true);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Gamepass ativado com sucesso!`, ephemeral: true });
                }
                
                if (selectedValue === 'desativar_gamepass') {
                    robuxConfig.set(`config.statusGamepass`, false);
                    await painelRobux(interaction);
                    interaction.followUp({ content: `${Emojis.get('checker')} | Sistema de Gamepass desativado com sucesso!`, ephemeral: true });
                }
            }

            if (interaction.customId === 'robux_preview_select') {
                await interaction.reply({ content: `${Emojis.get('info') || 'ℹ️'} | Você está no **modo preview**! Esta é apenas uma visualização da mensagem.`, ephemeral: true });
            }

            if (interaction.customId === 'robux_comprar_select') {
                const selectedValue = interaction.values[0];
                try {
                    const originalMessage = interaction.message;
                    const originalComponents = originalMessage.components.map(row => {
                        const newRow = ActionRowBuilder.from(row);
                        newRow.components = row.components.map(comp => {
                            if (comp.type === 3 && comp.customId === 'robux_comprar_select') {
                                return { ...comp.data, placeholder: "Escolha uma opção para solicitar o seu pedido" };
                            }
                            return comp;
                        });
                        return newRow;
                    });
                    await interaction.message.edit({ components: originalMessage.components }).catch(() => {});
                } catch (e) {}
                await criarCarrinhoRobux(interaction, selectedValue, client);
            }

            if (interaction.customId === 'robux_select_gamepass') {
                const [gamepassId, price] = interaction.values[0].split('_');
                await mostrarCheckout(interaction, gamepassId, parseInt(price));
            }

            if (interaction.customId.startsWith('sorteio_select_tempo_')) {
                const sorteioId = interaction.customId.replace('sorteio_select_tempo_', '');
                const tempoSelecionado = interaction.values[0];
                
                const tempoMs = parseTime(tempoSelecionado);
                
                sorteios.set(`${sorteioId}.duracao`, tempoMs);

                await PaginaEscolherCanal(interaction, sorteioId);
            }

            if (interaction.customId === 'gerenciar_sorteio_select') {
                const sorteioId = interaction.values[0];
                await PaginaGerenciarSorteioEspecifico(interaction, sorteioId, client);
            }

            if (interaction.customId === 'stock_select_embed') {
                const valor = interaction.values[0];
                const { ModalTituloEmbed, ModalDescricaoEmbed, ModalCorEmbed, ModalImagemEmbed, ModalThumbnailEmbed } = require("../../Functions/PainelSolicitarStock.js");
                
                if (valor === 'titulo') await ModalTituloEmbed(interaction);
                else if (valor === 'descricao') await ModalDescricaoEmbed(interaction);
                else if (valor === 'cor') await ModalCorEmbed(interaction);
                else if (valor === 'imagem') await ModalImagemEmbed(interaction);
                else if (valor === 'thumbnail') await ModalThumbnailEmbed(interaction);
            }

            if (interaction.customId === 'stock_select_botao') {
                const valor = interaction.values[0];
                const { ModalMensagemBotao, ModalEmojiBotao, ModalCorBotao } = require("../../Functions/PainelSolicitarStock.js");
                
                if (valor === 'mensagem') await ModalMensagemBotao(interaction);
                else if (valor === 'emoji') await ModalEmojiBotao(interaction);
                else if (valor === 'cor') await ModalCorBotao(interaction);
            }

            if (interaction.customId === 'robux_select_canal') {
                const selectedValue = interaction.values[0];
                
                const Discord = require("discord.js");
                let channelType = Discord.ChannelType.GuildText;
                let placeholder = 'Selecione um canal';
                let configKey = '';

                if (selectedValue === 'canal_iniciadas') {
                    configKey = 'iniciadas';
                    placeholder = 'Selecione o canal de compras iniciadas';
                } else if (selectedValue === 'canal_canceladas') {
                    configKey = 'canceladas';
                    placeholder = 'Selecione o canal de compras canceladas';
                } else if (selectedValue === 'canal_aprovadas') {
                    configKey = 'aprovadas';
                    placeholder = 'Selecione o canal de compras aprovadas';
                } else if (selectedValue === 'canal_publicas') {
                    configKey = 'publicas';
                    placeholder = 'Selecione o canal de compras públicas';
                } else if (selectedValue === 'categoria_carrinhos') {
                    configKey = 'categoriaCarrinhos';
                    placeholder = 'Selecione a categoria de carrinhos';
                    channelType = Discord.ChannelType.GuildCategory;
                }

                const selectChannel = new Discord.ChannelSelectMenuBuilder()
                    .setCustomId(`robux_channel_select_${configKey}`)
                    .setPlaceholder(placeholder)
                    .setChannelTypes(channelType);

                const row = new ActionRowBuilder().addComponents(selectChannel);

                await interaction.reply({ 
                    content: `${Emojis.get('info')} | Selecione o canal desejado:`, 
                    components: [row], 
                    ephemeral: true 
                });
            }

            if (interaction.customId === 'select_acoes_automaticas') {
                const selectedValue = interaction.values[0];
                const { res } = require("../../res");
                
                if (selectedValue === 'configMensagensAuto') {
                    const { painelPrincipal } = require("../../Eventos/Sistemas Automaticos/mensagemconfig.js");
                    await painelPrincipal(interaction);
                    return;
                }
                
                if (selectedValue === 'sistemasugestoes') {
                    const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                    PainelSistemaSugestoes(interaction, client);
                    return;
                }

                if (selectedValue === 'reacoesautomaticas') {
                    const { painelReacoesAutomaticas } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                    await painelReacoesAutomaticas(interaction, client);
                    return;
                }

                if (selectedValue === 'rastreadorinvites') {
                    const { painelInviteTracker } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                    await painelInviteTracker(interaction, client);
                    return;
                }

                if (selectedValue === 'mensagemboasvindas') {
                    const { painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                    await painelBoasVindas(interaction, client);
                    return;
                }

                if (selectedValue === 'nukeautomatico') {
                    const { painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                    await painelNukeAutomatico(interaction, client);
                    return;
                }
                
                if (selectedValue === 'configlock') {
                    const { painelAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                    await painelAutoLock(interaction, client);
                    return;
                }

                if (selectedValue === 'limpezaautomatica') {
                    const { painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                    await painelLimpezaAutomatica(interaction, client);
                    return;
                }

                if (selectedValue === 'monitorfeedbacks') {
                    const { painelMonitorFeedback } = require("../../Eventos/Sistemas Automaticos/monitorfeedback.js");
                    await painelMonitorFeedback(interaction, client);
                    return;
                }
                
                if (selectedValue === 'automaticRepostar') {
                    AcoesRepostAutomatics(interaction, client);
                    return;
                }
                
                if (selectedValue === 'configlock') {
                    const automaticosPath = require('path').resolve(__dirname, '../../DataBaseJson/autolock.json');
                    const fs = require('fs');
                    
                    let automaticos = {};
                    if (fs.existsSync(automaticosPath)) {
                        automaticos = JSON.parse(fs.readFileSync(automaticosPath));
                    }
                    
                    const guildId = interaction.guild.id;
                    const config = automaticos[guildId] || {};

                    let channelNames = config.channels
                        ? config.channels.map(id => `<#${id}>`).join(', ')
                        : '*Não configurado*';

                    const rowVoltar = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId("voltarautomaticos")
                            .setEmoji(`${Emojis.get('_back_emoji')}`)
                            .setLabel('Voltar')
                            .setStyle(2)
                    );

                    const containerContent = res.main(
                        { type: 10, content: `-# Painel > Ações Automáticas > Lock Automático` },
                        { type: 14 },
                        { type: 10, content: `**Configuração de Lock Automático**\n\n> Bloqueie e desbloqueie canais automaticamente em horários específicos.` },
                        { type: 14 },
                        { type: 10, content: `**Configurações Atuais:**\n> **Horário de Bloqueio:** \`${config.abrir || 'Não configurado'}\`\n> **Horário de Desbloqueio:** \`${config.fechar || 'Não configurado'}\`\n> **Canais:** ${channelNames}` },
                        { type: 14 },
                        {
                            type: 1,
                            components: [
                                {
                                    type: 2,
                                    style: 1,
                                    label: "Modificar",
                                    emoji: { id: "1236318155056349224" },
                                    custom_id: "modifyConfig"
                                },
                                {
                                    type: 2,
                                    style: 4,
                                    label: "Desativar",
                                    emoji: { id: "1178076767567757312" },
                                    custom_id: "disableConfig"
                                }
                            ]
                        }
                    ).with({
                        components: [rowVoltar],
                        flags: [64]
                    });

                    await interaction.update(containerContent);
                    return;
                }
            }








        }


        if (interaction.isChannelSelectMenu()) {

            if (interaction.customId === 'ticket_select_canal_postar') {
                await HandlePostarMensagem(interaction, client);
                return;
            }

            if (interaction.customId == 'canalpostarticket') {
                await interaction.reply({ content: `${Emojis.get('loading')} | Aguarde estamos criando sua mensagem!`, ephemeral: true });
                await CreateMessageTicket(interaction, interaction.values[0], client)
                interaction.editReply({ content: `${Emojis.get('checker')} | Mensagem criada com sucesso!`, ephemeral: true });
            }

            if (interaction.customId === 'select_canal_reacao') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");
                const canalId = interaction.values[0];

                const modal = new ModalBuilder()
                    .setCustomId(`modal_emojis_reacao_${canalId}`)
                    .setTitle('Configurar Emojis');

                modal.addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('emojis')
                            .setLabel('Emojis (separados por espaço)')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('Ex: 👍 👎 ❤️ ou :emoji1: :emoji2:')
                            .setRequired(true)
                    )
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'select_canal_invite') {
                const { loadInvitesData, saveInvitesData, painelInviteTracker } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                const canalId = interaction.values[0];
                
                const data = loadInvitesData();
                data.canalId = canalId;
                saveInvitesData(data);

                await painelInviteTracker(interaction, client);
            }

            if (interaction.customId === 'select_canal_boasvindas') {
                const { loadBoasvindasData, saveBoasvindasData, painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                const canalId = interaction.values[0];
                
                const data = loadBoasvindasData();
                data.canalId = canalId;
                saveBoasvindasData(data);

                await painelBoasVindas(interaction, client);
            }

            if (interaction.customId === 'select_canais_nuke') {
                const { loadNukeData, saveNukeData, painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                const canaisIds = interaction.values;
                
                const data = loadNukeData();
                data.canais = canaisIds;
                saveNukeData(data);

                await painelNukeAutomatico(interaction, client);
            }

            if (interaction.customId === 'select_canais_autolock') {
                const { loadAutolockData, saveAutolockData, painelAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                const canaisIds = interaction.values;
                const guildId = interaction.guild.id;
                
                const data = loadAutolockData(guildId);
                data.canais = canaisIds;
                saveAutolockData(guildId, data);

                await painelAutoLock(interaction, client);
            }

            if (interaction.customId === 'select_canais_limpeza') {
                const { loadLimpezaData, saveLimpezaData, painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                const canaisIds = interaction.values;
                
                const data = loadLimpezaData();
                data.canais = canaisIds;
                saveLimpezaData(data);

                await painelLimpezaAutomatica(interaction, client);
            }

            if (interaction.customId === 'select_canal_logs_feedback') {
                const { loadMonitorData, saveMonitorData, painelMonitorFeedback } = require("../../Eventos/Sistemas Automaticos/monitorfeedback.js");
                const canalId = interaction.values[0];
                
                const data = loadMonitorData();
                data.canalLogs = canalId;
                saveMonitorData(data);

                await painelMonitorFeedback(interaction, client);
            }

            if (interaction.customId === 'robux_select_canal_logs') {
                const { Systemrobux } = require("../../DataBaseJson");
                const { IlusionBux } = require("../../Functions/IlusionBux");
                
                const canalId = interaction.values[0];
                Systemrobux.set('canal_logs', canalId);
                
                await IlusionBux(interaction);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Canal de logs configurado com sucesso!`,
                    ephemeral: true
                });
            }

            if (interaction.customId === 'robux_select_canal_vendas') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const canalId = interaction.values[0];
                Systemrobux.set('canal_vendas', canalId);
                
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const canalVendas = Systemrobux.get('canal_vendas');
                const canalLogs = Systemrobux.get('canal_logs');
                
                const canalVendasTexto = canalVendas ? `<#${canalVendas}>` : '``Não configurado``';
                const canalLogsTexto = canalLogs ? `<#${canalLogs}>` : '``Não configurado``';
                
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_config_canal_vendas")
                        .setLabel("Canal de Vendas")
                        .setEmoji(Emojis.get('_money_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_config_canal_logs")
                        .setLabel("Canal de Logs")
                        .setEmoji(Emojis.get('logss'))
                        .setStyle(2)
                );
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Canais` },
                    { type: 14 },
                    { type: 10, content: `## Configurar Canais do Sistema\n\n> Configure os canais onde o sistema irá operar.` },
                    { type: 14 },
                    { type: 10, content: `**Canais Configurados:**\n- Canal de Vendas: ${canalVendasTexto}\n- Canal de Logs: ${canalLogsTexto}` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Canal de vendas configurado com sucesso!`,
                    ephemeral: true
                });
            }

            if (interaction.customId.startsWith('robux_channel_select_')) {
                const configKey = interaction.customId.replace('robux_channel_select_', '');
                const channelId = interaction.values[0];

                robuxConfig.set(`config.canais.${configKey}`, channelId);
                
                await interaction.update({ 
                    content: `${Emojis.get('checker')} | Canal configurado com sucesso!`, 
                    components: [] 
                });
            }

            if (interaction.customId === 'robux_channel_enviar_mensagem') {
                const channelId = interaction.values[0];
                await interaction.update({ content: `${Emojis.get('loading')} | Enviando mensagem...`, components: [] });
                
                const success = await enviarMensagemRobux(interaction, channelId, client);
                if (success) {
                    await interaction.editReply({ content: `${Emojis.get('checker')} | Mensagem enviada com sucesso no canal <#${channelId}>!` });
                } else {
                    await interaction.editReply({ content: `${Emojis.get('negative')} | Erro ao enviar a mensagem!` });
                }
            }

            if (interaction.customId.startsWith('ticket_channel_postar_')) {
                const painelId = interaction.customId.replace('ticket_channel_postar_', '');
                const channelId = interaction.values[0];
                await interaction.update({ content: `${Emojis.get('loading')} | Postando ticket...`, components: [] });
                const channel = await client.channels.fetch(channelId);
                await PostarTicket(interaction, painelId, channel);
            }

        }

        if (interaction.isChannelSelectMenu()) {
            if (interaction.customId.startsWith('sorteio_select_canal_')) {
                const sorteioId = interaction.customId.replace('sorteio_select_canal_', '');
                const canalId = interaction.values[0];
                
                sorteios.set(`${sorteioId}.canalId`, canalId);

                await PaginaGerenciarCargos(interaction, sorteioId);
            }

            if (interaction.customId === 'stock_select_canal_logs') {
                const canalId = interaction.values[0];
                configuracao.set('solicitarStock.canalLogs', canalId);
                
                const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                await PainelSolicitarStock(interaction, client);
            }

            if (interaction.customId === 'stock_select_canal_postar') {
                const canalId = interaction.values[0];
                const { PostarPainelStock } = require("../../Functions/PainelSolicitarStock.js");
                await PostarPainelStock(interaction, canalId, client);
            }

            if (interaction.customId === 'sugestao_select_canal') {
                const canalId = interaction.values[0];
                configuracao.set('sistemaSugestoes.canal', canalId);
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                await PainelSistemaSugestoes(interaction, client);
            }
        }

        if (interaction.isRoleSelectMenu()) {
            if (interaction.customId.startsWith('sorteio_cargos_permitidos_')) {
                const sorteioId = interaction.customId.replace('sorteio_cargos_permitidos_', '');
                const cargos = interaction.values;
                
                sorteios.set(`${sorteioId}.cargosPermitidos`, cargos);

                await interaction.reply({ content: `${Emojis.get('checker')} | Cargos permitidos atualizados!`, ephemeral: true });
            }

            if (interaction.customId.startsWith('sorteio_cargos_bloqueados_')) {
                const sorteioId = interaction.customId.replace('sorteio_cargos_bloqueados_', '');
                const cargos = interaction.values;
                
                sorteios.set(`${sorteioId}.cargosBloqueados`, cargos);

                await interaction.reply({ content: `${Emojis.get('checker')} | Cargos bloqueados atualizados!`, ephemeral: true });
            }

            if (interaction.customId === 'sugestao_select_cargo') {
                const cargoId = interaction.values[0];
                configuracao.set('sistemaSugestoes.cargoAvaliador', cargoId);
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                await PainelSistemaSugestoes(interaction, client);
            }
        }

        if (interaction.isButton()) {

            if (interaction.customId.startsWith('produtos_page_')) {
                const page = parseInt(interaction.customId.split('_')[2], 10);
                await mostrarPaginaProdutos(interaction, page);
                return;
            }

            if (interaction.customId == 'sincronizarticket') {
                await interaction.reply({ content: `${Emojis.get('loading')} | Aguarde estamos atualizando suas mensagem!`, ephemeral: true });
                await Checkarmensagensticket(client)
                interaction.editReply({ content: `${Emojis.get('checker')} | Mensagens atualizada com sucesso!`, ephemeral: true });
            }


            if (interaction.customId == 'arquivar') {

                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });

                try {
                    await interaction.channel.setArchived(true)
                } catch (error) { }
            }

            if (interaction.customId === 'painel_staff') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para acessar o painel staff!`, ephemeral: true });
                }

                const selectMenu = new Discord.StringSelectMenuBuilder()
                    .setCustomId('staff_acoes_ticket')
                    .setPlaceholder('Selecione uma ação...')
                    .addOptions([
                        { label: 'Assumir Ticket', description: 'Assumir o atendimento deste ticket', value: 'assumir_ticket', emoji: { id: '1178067873894236311' } },
                        { label: 'Renomear Ticket', description: 'Alterar o nome do tópico', value: 'renomear_ticket', emoji: { id: '1178066208835252266' } },
                        { label: 'Adicionar Usuário', description: 'Adicionar alguém ao ticket', value: 'adicionar_usuario', emoji: { id: '1178067873894236311' } },
                        { label: 'Remover Usuário', description: 'Remover alguém do ticket', value: 'remover_usuario', emoji: { id: '1178076767567757312' } }
                    ]);

                const row = new ActionRowBuilder().addComponents(selectMenu);

                await interaction.reply({ content: `${Emojis.get('ticketpanel')} **Painel da Equipe Staff**\n> Selecione uma ação abaixo:`, components: [row], ephemeral: true });
            }

              if (interaction.customId === 'deletar') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) &&
                    !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });
                }
            
                try {
                    const ticketId = interaction.channel.id;
                    const { Temporario, transcript } = require("../../DataBaseJson");
                    
                    let threadOwnerId = Temporario.get(`ticket_owner_${ticketId}`);
                    let categoria = Temporario.get(`ticket_categoria_${ticketId}`);
                    
                    if (!threadOwnerId) {
                        const threadNameParts = interaction.channel.name.split('・');
                        categoria = threadNameParts[0] || 'Ticket';
                        threadOwnerId = threadNameParts[2];
                    }
                    
                    if (!categoria) {
                        const threadNameParts = interaction.channel.name.split('・');
                        categoria = threadNameParts[0] || 'Ticket';
                    }
            
                    const fetchedMessages = await interaction.channel.messages.fetch({ limit: 100 });
                    const messagesArray = Array.from(fetchedMessages.values()).reverse().map(msg => ({
                        author: msg.author.tag,
                        authorId: msg.author.id,
                        content: msg.content || '[Sem conteúdo]',
                        timestamp: msg.createdAt.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })
                    }));
                    
                    const userMessages = messagesArray.filter(m => !m.content.startsWith('[Sem conteúdo]') && m.content.trim() !== '');
                    
                    if (userMessages.length > 0) {
                        const transcriptId = `${Date.now()}_${threadOwnerId}`;
                        const transcriptData = {
                            categoria,
                            ownerId: threadOwnerId,
                            fechadoPor: interaction.user.tag,
                            fechadoPorId: interaction.user.id,
                            fechadoEm: new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }),
                            mensagens: messagesArray,
                            guildName: interaction.guild.name,
                            guildId: interaction.guild.id
                        };
                        
                        transcript.set(transcriptId, transcriptData);

                        try {
                            const owner = await interaction.client.users.fetch(threadOwnerId);
                            
                            const containerFechado = res.main(
                                { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                                { type: 14 },
                                { type: 10, content: `> Seu ticket de **${categoria}** foi encerrado.` },
                                { type: 14 },
                                { type: 10, content: `**Fechado por**\n${interaction.user.tag}` },
                                { type: 10, content: `**Data**\n<t:${Math.floor(Date.now() / 1000)}:f>` },
                                { type: 14 },
                                { type: 10, content: `-# Clique no botão abaixo para receber o transcript do atendimento.` },
                                { type: 1, components: [{ type: 2, style: 2, label: 'Gerar Transcript', custom_id: `gerar_transcript_${transcriptId}`, emoji: { id: '1384035207598051431' } }] }
                            );

                            await owner.send(containerFechado);
                        } catch (dmError) {
                            console.error('Não foi possível enviar DM para o usuário:', dmError);
                        }
                    } else {
                        try {
                            const owner = await interaction.client.users.fetch(threadOwnerId);
                            
                            const containerFechado = res.main(
                                { type: 10, content: `# ${Emojis.get('_trash_emoji')} Ticket Fechado` },
                                { type: 14 },
                                { type: 10, content: `> Seu ticket de **${categoria}** foi encerrado.` },
                                { type: 14 },
                                { type: 10, content: `**Fechado por**\n${interaction.user.tag}` },
                                { type: 10, content: `**Data**\n<t:${Math.floor(Date.now() / 1000)}:f>` }
                            );

                            await owner.send(containerFechado);
                        } catch (dmError) {
                            console.error('Não foi possível enviar DM para o usuário:', dmError);
                        }
                    }

                    const fs = require('fs');
                    const messagesContent = messagesArray.map(m => `[${m.timestamp}] ${m.author}: ${m.content}`).join('\n');
                    fs.writeFileSync('mensagens_antigas.txt', messagesContent);
            
                    await interaction.channel.delete();
            
                    const embed = new EmbedBuilder()
                        .setColor('#ff0000')
                        .setTitle(`Ticket Fechado: ${categoria}`)
                        .setDescription(`O ticket foi fechado por ${interaction.user} \`(${interaction.user.id})\`\n**Usuário:** <@${threadOwnerId}>`)
                        .setTimestamp();
            
                    const logsChannelId = configuracao.get(`ConfigChannels.logsticket`);
                    const logsChannel = interaction.guild.channels.cache.get(logsChannelId);
                    if (logsChannel) {
                        await logsChannel.send({ embeds: [embed], files: [{ attachment: 'mensagens_antigas.txt', name: 'transcript.txt' }] });
                    }
                } catch (error) {
                    console.error('Erro ao deletar o canal:', error);
                }
            }

            if (interaction.customId === 'lembrar123') {
                if (!interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargoadm')) && !interaction.member.roles.cache.has(configuracao.get('ConfigRoles.cargosup'))) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não tem permissão para fazer isso!`, ephemeral: true });
                }
            
                try {
                    const ticketId = interaction.channel.id;
                    const { Temporario } = require("../../DataBaseJson");
                    
                    let threadOwnerId = Temporario.get(`ticket_owner_${ticketId}`);
                    if (!threadOwnerId) {
                        const threadNameParts = interaction.channel.name.split('・');
                        threadOwnerId = threadNameParts[2];
                    }
                    
                    if (!threadOwnerId || !/^\d+$/.test(threadOwnerId)) {
                        return interaction.reply({ content: `${Emojis.get('negative')} | Não foi possível identificar o dono do ticket.`, ephemeral: true });
                    }
                    
                    const user = await interaction.client.users.fetch(threadOwnerId);
            
                    const brazilTime = new Date().toLocaleString("en-US", {timeZone: "America/Sao_Paulo"});
                    const hour = new Date(brazilTime).getHours();
                    let saudacao;
            
                    if (hour >= 0 && hour < 12) {
                        saudacao = 'Bom dia';
                    } else if (hour >= 12 && hour < 18) {
                        saudacao = 'Boa tarde';
                    } else {
                        saudacao = 'Boa noite';
                    }
            
                    const mensagem = `${saudacao} <@${threadOwnerId}>, você possui um ticket pendente de resposta; se não for respondido, poderá ser fechado.`;
            
                    const row = new ActionRowBuilder() .addComponents(
                        new ButtonBuilder()
                            .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
                            .setLabel('Ir para o Ticket')
                            .setStyle('5')
                    );
        
                    await user.send({
                        content: mensagem,
                        components: [row]
                    });
            
                    await interaction.reply({ content: `${Emojis.get('checker')} | Mensagem enviada ao criador do ticket.`, ephemeral: true });
            
                } catch (error) {
                    await interaction.reply({ content: `${Emojis.get('negative')} | Não foi possível enviar a mensagem, pois o usuário provavelmente bloqueou mensagens privadas.`, ephemeral: true });
                }
            }            

            if (interaction.customId == `postarticket`) {
                const ggg = tickets.get(`tickets.funcoes`)
                const ggg2 = tickets.get(`tickets.aparencia`)


                if (ggg == null || Object.keys(ggg).length == 0 || ggg2 == null || Object.keys(ggg2).length == 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} Adicione uma função antes de postar a mensagem.`, ephemeral: true });
                } else {
                    const selectaaa = new Discord.ChannelSelectMenuBuilder()
                        .setCustomId('canalpostarticket')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setChannelTypes(Discord.ChannelType.GuildText)

                    const row1 = new ActionRowBuilder()
                        .addComponents(selectaaa);

                    interaction.reply({ components: [row1], content: `${Emojis.get('info')} Selecione o canal onde quer postar a mensagem.`, ephemeral: true, })

                }
            }



            if (interaction.customId == 'remfuncaoticket') {
                const ggg = tickets.get(`tickets.funcoes`)
                    
                if (ggg == null || Object.keys(ggg).length == 0) {
                    return interaction.reply({ content: `${Emojis.get('negative')} Não existe nenhuma função criada para remover.`, ephemeral: true });
                } else {
                    const selectMenuBuilder = new Discord.StringSelectMenuBuilder()
                        .setCustomId('deletarticketsfunction')
                        .setPlaceholder('Clique aqui para selecionar')
                        .setMinValues(0)

                    for (const chave in ggg) {
                        const item = ggg[chave];
                        const option = {
                            label: `${item.nome}`,
                            description: `${item.predescricao}`,
                            value: item.nome
                        };
                        selectMenuBuilder.addOptions(option);
                    }

                    selectMenuBuilder.setMaxValues(Object.keys(ggg).length)

                    const style2row = new ActionRowBuilder().addComponents(selectMenuBuilder);
                    try {
                        await interaction.reply({ components: [style2row], content: `${interaction.user} Qual funções deseja remover?`, ephemeral: true })
                    } catch (error) {
                    }
                }
            }


            if (interaction.customId == 'painelrendimentos') {
                const { PainelRendimentos } = require("../../Functions/PainelRendimentos");
                await PainelRendimentos(interaction, client, 'hoje');
            }

            if (interaction.customId == 'rendimento_hoje') {
                const { PainelRendimentos } = require("../../Functions/PainelRendimentos");
                await PainelRendimentos(interaction, client, 'hoje');
            }

            if (interaction.customId == 'rendimento_7dias') {
                const { PainelRendimentos } = require("../../Functions/PainelRendimentos");
                await PainelRendimentos(interaction, client, '7dias');
            }

            if (interaction.customId == 'rendimento_30dias') {
                const { PainelRendimentos } = require("../../Functions/PainelRendimentos");
                await PainelRendimentos(interaction, client, '30dias');
            }

            if (interaction.customId == 'rendimento_total') {
                const { PainelRendimentos } = require("../../Functions/PainelRendimentos");
                await PainelRendimentos(interaction, client, 'total');
            }

            if (interaction.customId == 'gerenciarposicao') {

                Posicao1(interaction, client)

            }



            if (interaction.customId == 'Editarprimeiraposição') {

                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('aslfdjauydvaw769dg7waajnwndjo')
                    .setTitle(`Definir primeira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos1?.valor == undefined ? '' : aa.pos1?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos1?.role == undefined ? '' : aa.pos1?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarsegundaposição') {
                const aa = configuracao.get(`posicoes`)

                const modalaAA = new ModalBuilder()
                    .setCustomId('awiohdbawudwdwhduawdnuaw')
                    .setTitle(`Definir segunda posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos2?.valor == undefined ? '' : aa.pos2?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos2?.role == undefined ? '' : aa.pos2?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }

            if (interaction.customId == 'Editarterceiraposição') {
                const aa = configuracao.get(`posicoes`)
                const modalaAA = new ModalBuilder()
                    .setCustomId('uy82819171h172')
                    .setTitle(`Definir terceira posição`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`VALOR`)
                    .setPlaceholder(`Insira uma quantia, ex: 100`)
                    .setValue(aa?.pos3?.valor == undefined ? '' : aa.pos3?.valor)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`CARGO`)
                    .setPlaceholder(`Insira um id de algum cargo`)
                    .setValue(aa?.pos3?.role == undefined ? '' : aa.pos3?.role)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);

                modalaAA.addComponents(firstActionRow3, firstActionRow4);

                await interaction.showModal(modalaAA);
            }


            if (interaction.customId.startsWith('criarrrr')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjsdua')
                    .setTitle(`Criação`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME`)
                    .setPlaceholder(`Insira o nome do seu produto`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira uma descrição para seu produto`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(1024)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`ENTREGA AUTOMÁTICA?`)
                    .setPlaceholder(`Digite "sim" ou "não"`)
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(3)
                    .setRequired(true)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP4')
                    .setLabel(`ICONE (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira uma URL de uma imagem ou gif`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }

            if (interaction.customId.startsWith('infoauth')) {

                infoauth(interaction, client)

            }

            if (interaction.customId.startsWith('voltarconfigauth')) {

                configauth(interaction, client)

            }
             if (interaction.customId.startsWith('sistemaauth')) {
                const { PainelIlusionCloud } = require("../../Functions/IlusionCloud");
                PainelIlusionCloud(interaction, client);
            }

            }

            if (interaction.customId.startsWith('infosauth')) {

                infosauth(interaction, client)

            } 
              if (interaction.customId.startsWith('configurarmistic')) {

                misticConfigs(interaction, client)

            }



            if (interaction.customId.startsWith('config_pagamentos_inter')) {

                imapConfigs(interaction, client)

            }

             if (interaction.customId == "altMoeda") {

                await interaction.update({ content: `${Emojis.get(`loading`)} Carregando...`, embeds: [], components: [] });

                moedaConfig(interaction, client);

            }
          
            if (interaction.customId.startsWith('voltarauth')) {

                ecloud(interaction, client)

            }

            
            if (interaction.customId === 'robux_toggle_status') {
                const { Systemrobux } = require("../../DataBaseJson");
                const { IlusionBux } = require("../../Functions/IlusionBux");
                
                const statusAtual = Systemrobux.get('status') || false;
                const precoComTaxa = Systemrobux.get('preco_com_taxa');
                const precoSemTaxa = Systemrobux.get('preco_sem_taxa');
                const canalLogs = Systemrobux.get('canal_logs');
                
                const podeAtivar = precoComTaxa !== 'Não configurado' && precoSemTaxa !== 'Não configurado' && canalLogs;
                
                if (!statusAtual && !podeAtivar) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Configure todos os campos antes de ativar o sistema!`,
                        ephemeral: true
                    });
                }
                
                Systemrobux.set('status', !statusAtual);
                
                await IlusionBux(interaction);
            }

            if (interaction.customId === 'robux_config_mensagem') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const banner = Systemrobux.get('mensagem_banner');
                const modo = Systemrobux.get('mensagem_modo') || 'container';
                
                const modoTexto = modo === 'container' ? '``Component v2 (Container)``' : '``Embed``';
                
                const tituloConfigurado = titulo !== '💎 Comprar Robux';
                const descricaoConfigurada = descricao !== 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const corConfigurada = cor !== '#2b2d31';
                
                const tituloStatus = tituloConfigurado ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const descricaoStatus = descricaoConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const bannerStatus = banner ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const corStatus = corConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                
                const rowBotoes1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_alterar_modo")
                        .setLabel("Alterar Modo")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_configurar")
                        .setLabel("Configurar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_resetar")
                        .setLabel("Resetar Config Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(4)
                );
                
                const rowBotoes2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_preview")
                        .setLabel("Ver Preview")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_postar")
                        .setLabel("Postar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(3),
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Informações Detalhadas**\n- Modo: ${modoTexto}\n- Título: ${tituloStatus}\n- Descrição: ${descricaoStatus}\n- Banner: ${bannerStatus}\n- Cor: ${corStatus}` },
                    { type: 14 },
                    { type: 10, content: `**Funcionalidades:**\n- Altere entre modo Container ou Embed\n- Configure título, descrição, banner e cor da mensagem\n- Visualize um preview antes de postar\n- Poste a mensagem no canal de vendas configurado` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes1, rowBotoes2],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'robux_alterar_precos') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const precoComTaxa = Systemrobux.get('preco_com_taxa');
                const precoSemTaxa = Systemrobux.get('preco_sem_taxa');
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_precos')
                    .setTitle('Configurar Preços - Robux');

                const inputComTaxa = new TextInputBuilder()
                    .setCustomId('preco_com_taxa')
                    .setLabel('Preço por 1000 Robux (COM TAXA)')
                    .setPlaceholder('Ex: 15.00')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);
                
                if (precoComTaxa && precoComTaxa !== 'Não configurado') {
                    inputComTaxa.setValue(precoComTaxa);
                }

                const inputSemTaxa = new TextInputBuilder()
                    .setCustomId('preco_sem_taxa')
                    .setLabel('Preço por 1000 Robux (SEM TAXA)')
                    .setPlaceholder('Ex: 12.00')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);
                
                if (precoSemTaxa && precoSemTaxa !== 'Não configurado') {
                    inputSemTaxa.setValue(precoSemTaxa);
                }

                const row1 = new ActionRowBuilder().addComponents(inputComTaxa);
                const row2 = new ActionRowBuilder().addComponents(inputSemTaxa);

                modal.addComponents(row1, row2);
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_config_canais') {
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const selectCanal = new ChannelSelectMenuBuilder()
                    .setCustomId('robux_select_canal_logs')
                    .setPlaceholder('Selecione o canal de logs')
                    .setChannelTypes(ChannelType.GuildText);

                const rowSelect = new ActionRowBuilder().addComponents(selectCanal);
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Canal de Logs` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('logss')} Configurar Canal de Logs\n\n> Selecione o canal onde serão enviados os logs das transações de Robux.` },
                    { type: 14 }
                ).with({
                    components: [rowSelect, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'voltar_robux_painel') {
                const { IlusionBux } = require("../../Functions/IlusionBux");
                await IlusionBux(interaction);
            }

            if (interaction.customId === 'robux_config_canal_vendas') {
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const selectCanal = new ChannelSelectMenuBuilder()
                    .setCustomId('robux_select_canal_vendas')
                    .setPlaceholder('Selecione o canal de vendas')
                    .setChannelTypes(ChannelType.GuildText);

                const rowSelect = new ActionRowBuilder().addComponents(selectCanal);
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_config_canais")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Canais > Canal de Vendas` },
                    { type: 14 },
                    { type: 10, content: `## Configurar Canal de Vendas\n\n> Selecione o canal onde será postada a mensagem para compra de Robux.` },
                    { type: 14 }
                ).with({
                    components: [rowSelect, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'robux_config_canal_logs') {
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const selectCanal = new ChannelSelectMenuBuilder()
                    .setCustomId('robux_select_canal_logs')
                    .setPlaceholder('Selecione o canal de logs')
                    .setChannelTypes(ChannelType.GuildText);

                const rowSelect = new ActionRowBuilder().addComponents(selectCanal);
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_config_canais")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Canais > Canal de Logs` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('logss')} Configurar Canal de Logs\n\n> Selecione o canal onde serão enviados os logs das transações de Robux.` },
                    { type: 14 }
                ).with({
                    components: [rowSelect, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'voltar_robux_config_canais') {
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const canalVendas = Systemrobux.get('canal_vendas');
                const canalLogs = Systemrobux.get('canal_logs');
                
                const canalVendasTexto = canalVendas ? `<#${canalVendas}>` : '``Não configurado``';
                const canalLogsTexto = canalLogs ? `<#${canalLogs}>` : '``Não configurado``';
                
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_config_canal_vendas")
                        .setLabel("Canal de Vendas")
                        .setEmoji(Emojis.get('_money_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_config_canal_logs")
                        .setLabel("Canal de Logs")
                        .setEmoji(Emojis.get('logss'))
                        .setStyle(2)
                );
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Canais` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('logss')} Configurar Canais do Sistema\n\n> Configure os canais onde o sistema irá operar.` },
                    { type: 14 },
                    { type: 10, content: `**Canais Configurados:**\n- Canal de Vendas: ${canalVendasTexto}\n- Canal de Logs: ${canalLogsTexto}` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'robux_msg_editar_titulo') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const tituloAtual = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_msg_titulo')
                    .setTitle('Editar Título da Mensagem');

                const inputTitulo = new TextInputBuilder()
                    .setCustomId('titulo')
                    .setLabel('Título da Mensagem')
                    .setPlaceholder('Ex: 💎 Comprar Robux')
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(256)
                    .setValue(tituloAtual)
                    .setRequired(true);

                const row = new ActionRowBuilder().addComponents(inputTitulo);
                modal.addComponents(row);
                
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_msg_editar_descricao') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const descricaoAtual = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_msg_descricao')
                    .setTitle('Editar Descrição da Mensagem');

                const inputDescricao = new TextInputBuilder()
                    .setCustomId('descricao')
                    .setLabel('Descrição da Mensagem')
                    .setPlaceholder('Ex: Clique no botão abaixo para comprar Robux...')
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(4000)
                    .setValue(descricaoAtual)
                    .setRequired(true);

                const row = new ActionRowBuilder().addComponents(inputDescricao);
                modal.addComponents(row);
                
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_msg_editar_cor') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const corAtual = Systemrobux.get('mensagem_cor') || '#2b2d31';
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_msg_cor')
                    .setTitle('Editar Cor da Mensagem');

                const inputCor = new TextInputBuilder()
                    .setCustomId('cor')
                    .setLabel('Cor da Embed (Hex)')
                    .setPlaceholder('Ex: #2b2d31 ou 2b2d31')
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(7)
                    .setValue(corAtual)
                    .setRequired(true);

                const row = new ActionRowBuilder().addComponents(inputCor);
                modal.addComponents(row);
                
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_msg_alterar_modo') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const modoAtual = Systemrobux.get('mensagem_modo') || 'container';
                const novoModo = modoAtual === 'container' ? 'embed' : 'container';
                
                Systemrobux.set('mensagem_modo', novoModo);
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const banner = Systemrobux.get('mensagem_banner');
                
                const modoTexto = novoModo === 'container' ? '``Component v2 (Container)``' : '``Embed``';
                
                const tituloConfigurado = titulo !== '💎 Comprar Robux';
                const descricaoConfigurada = descricao !== 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const corConfigurada = cor !== '#2b2d31';
                
                const tituloStatus = tituloConfigurado ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const descricaoStatus = descricaoConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const bannerStatus = banner ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const corStatus = corConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                
                const rowBotoes1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_alterar_modo")
                        .setLabel("Alterar Modo")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_configurar")
                        .setLabel("Configurar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_resetar")
                        .setLabel("Resetar Config Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(4)
                );
                
                const rowBotoes2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_preview")
                        .setLabel("Ver Preview")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_postar")
                        .setLabel("Postar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(3),
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Informações Detalhadas**\n- Modo: ${modoTexto}\n- Título: ${tituloStatus}\n- Descrição: ${descricaoStatus}\n- Banner: ${bannerStatus}\n- Cor: ${corStatus}` },
                    { type: 14 },
                    { type: 10, content: `**Funcionalidades:**\n- Altere entre modo Container ou Embed\n- Configure título, descrição, banner e cor da mensagem\n- Visualize um preview antes de postar\n- Poste a mensagem no canal de vendas configurado` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes1, rowBotoes2],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Modo alterado para: **${novoModo === 'container' ? 'Component v2 (Container)' : 'Embed'}**`,
                    ephemeral: true
                });
            }

            if (interaction.customId === 'robux_msg_configurar') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { Systemrobux } = require("../../DataBaseJson");
                
                const tituloAtual = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricaoAtual = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const bannerAtual = Systemrobux.get('mensagem_banner') || '';
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_config_mensagem')
                    .setTitle('Configurar Mensagem');

                const inputTitulo = new TextInputBuilder()
                    .setCustomId('titulo')
                    .setLabel('Título')
                    .setPlaceholder('Ex: 💎 Comprar Robux')
                    .setStyle(TextInputStyle.Short)
                    .setMaxLength(256)
                    .setValue(tituloAtual)
                    .setRequired(true);

                const inputDescricao = new TextInputBuilder()
                    .setCustomId('descricao')
                    .setLabel('Descrição')
                    .setPlaceholder('Ex: Clique no botão abaixo para comprar Robux...')
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(4000)
                    .setValue(descricaoAtual)
                    .setRequired(true);

                const inputBanner = new TextInputBuilder()
                    .setCustomId('banner')
                    .setLabel('Banner (URL da imagem - Opcional)')
                    .setPlaceholder('Ex: https://i.imgur.com/exemplo.png')
                    .setStyle(TextInputStyle.Short)
                    .setValue(bannerAtual)
                    .setRequired(false);

                const row1 = new ActionRowBuilder().addComponents(inputTitulo);
                const row2 = new ActionRowBuilder().addComponents(inputDescricao);
                const row3 = new ActionRowBuilder().addComponents(inputBanner);

                modal.addComponents(row1, row2, row3);
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_msg_resetar') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                Systemrobux.set('mensagem_titulo', '💎 Comprar Robux');
                Systemrobux.set('mensagem_descricao', 'Clique no botão abaixo para comprar Robux de forma rápida e segura!');
                Systemrobux.set('mensagem_cor', '#2b2d31');
                Systemrobux.set('mensagem_banner', null);
                Systemrobux.set('mensagem_modo', 'container');
                
                const rowBotoes1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_alterar_modo")
                        .setLabel("Alterar Modo")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_configurar")
                        .setLabel("Configurar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_resetar")
                        .setLabel("Resetar Config Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(4)
                );
                
                const rowBotoes2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_preview")
                        .setLabel("Ver Preview")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_postar")
                        .setLabel("Postar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(3),
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Informações Detalhadas**\n- Modo: \`\`Component v2 (Container)\`\`\n- Título: \`💎 Comprar Robux\`\n- Descrição: \`Clique no botão abaixo para comprar Robux de forma rápida e segura!\`\n- Banner: \`\`Não configurado\`\`\n- Cor: \`#2b2d31\`` },
                    { type: 14 },
                    { type: 10, content: `**Funcionalidades:**\n- Altere entre modo Container ou Embed\n- Configure título, descrição, banner e cor da mensagem\n- Visualize um preview antes de postar\n- Poste a mensagem no canal de vendas configurado` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes1, rowBotoes2],
                    flags: [64]
                });

                await interaction.update(containerContent);
                
                await interaction.followUp({
                    content: `${Emojis.get('checker')} Configurações resetadas para o padrão!`,
                    ephemeral: true
                });
            }

            if (interaction.customId === 'robux_msg_preview') {
                const { Systemrobux } = require("../../DataBaseJson");
                const { EmbedBuilder } = require("discord.js");
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const banner = Systemrobux.get('mensagem_banner');
                const modo = Systemrobux.get('mensagem_modo') || 'container';
                
                if (modo === 'container') {
                    const containerParts = [
                        { type: 10, content: titulo },
                        { type: 10, content: descricao }
                    ];
                    
                    if (banner) {
                        containerParts.push({
                            type: 12,
                            items: [{ media: { url: banner.trim() }, spoiler: false }]
                        });
                    }
                    
                    containerParts.push({ type: 14 });
                    
                    containerParts.push({
                        type: 1,
                        components: [
                            { type: 2, style: 2, custom_id: 'robux_comprar', label: 'Comprar Robux', emoji: { id: '1461750707190501459' } },
                            { type: 2, style: 2, custom_id: 'robux_calcular', label: 'Calcular Valores', emoji: { id: '1465182769553346695' } }
                        ]
                    });
                    
                    const containerContent = res.main(...containerParts).with({
                        flags: [64]
                    });
                    
                    await interaction.reply(containerContent);
                } else {
                    const rowBotoes = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId("robux_comprar")
                            .setLabel("Comprar Robux")
                            .setEmoji('1461750707190501459')
                            .setStyle(2),
                        new ButtonBuilder()
                            .setCustomId("robux_calcular")
                            .setLabel("Calcular Valores")
                            .setEmoji('1465182769553346695')
                            .setStyle(2)
                    );
                    
                    const embed = new EmbedBuilder()
                        .setTitle(titulo)
                        .setDescription(descricao)
                        .setColor(cor);
                    
                    if (banner) {
                        embed.setImage(banner);
                    }
                    
                    await interaction.reply({
                        embeds: [embed],
                        components: [rowBotoes],
                        flags: [64]
                    });
                }
            }

            if (interaction.customId === 'robux_msg_postar') {
                const { ChannelSelectMenuBuilder, ChannelType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
                
                const selectCanal = new ChannelSelectMenuBuilder()
                    .setCustomId('robux_select_canal_postar')
                    .setPlaceholder('Selecione o canal para postar')
                    .setChannelTypes(ChannelType.GuildText);

                const rowSelect = new ActionRowBuilder().addComponents(selectCanal);
                
                const rowVoltar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_config_msg")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem > Postar` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Selecionar Canal\n\n> Escolha o canal onde deseja postar a mensagem de vendas de Robux.` },
                    { type: 14 }
                ).with({
                    components: [rowSelect, rowVoltar],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'robux_select_canal_postar') {
                const { Systemrobux } = require("../../DataBaseJson");
                const { EmbedBuilder } = require("discord.js");
                
                const canalId = interaction.values[0];
                const canal = await interaction.guild.channels.fetch(canalId).catch(() => null);
                
                if (!canal) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Canal não encontrado!`,
                        ephemeral: true
                    });
                }
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const banner = Systemrobux.get('mensagem_banner');
                const modo = Systemrobux.get('mensagem_modo') || 'container';
                
                try {
                    if (modo === 'container') {
                        const containerParts = [
                            { type: 10, content: titulo },
                            { type: 10, content: descricao }
                        ];
                        
                        if (banner) {
                            containerParts.push({
                                type: 12,
                                items: [{ media: { url: banner.trim() }, spoiler: false }]
                            });
                        }
                        
                        containerParts.push({ type: 14 });
                        
                        containerParts.push({
                            type: 1,
                            components: [
                                { type: 2, style: 2, custom_id: 'robux_comprar', label: 'Comprar Robux', emoji: { id: '1461750707190501459' } },
                                { type: 2, style: 2, custom_id: 'robux_calcular', label: 'Calcular Valores', emoji: { id: '1465182769553346695' } }
                            ]
                        });
                        
                        const containerContent = res.main(...containerParts).with({});
                        
                        await canal.send(containerContent);
                    } else {
                        const rowBotoes = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId("robux_comprar")
                                .setLabel("Comprar Robux")
                                .setEmoji('1461750707190501459')
                                .setStyle(2),
                            new ButtonBuilder()
                                .setCustomId("robux_calcular")
                                .setLabel("Calcular Valores")
                                .setEmoji('1465182769553346695')
                                .setStyle(2)
                        );
                        
                        const embed = new EmbedBuilder()
                            .setTitle(titulo)
                            .setDescription(descricao)
                            .setColor(cor);
                        
                        if (banner) {
                            embed.setImage(banner);
                        }
                        
                        await canal.send({
                            embeds: [embed],
                            components: [rowBotoes]
                        });
                    }
                    
                    await interaction.reply({
                        content: `${Emojis.get('checker')} Mensagem postada com sucesso em ${canal}!`,
                        ephemeral: true
                    });
                } catch (error) {
                    console.error('[Robux] Erro ao postar mensagem:', error);
                    await interaction.reply({
                        content: `${Emojis.get('negative')} Erro ao postar mensagem! Verifique as permissões do bot.`,
                        ephemeral: true
                    });
                }
            }

            if (interaction.customId === 'voltar_robux_config_msg') {
                const { Systemrobux } = require("../../DataBaseJson");
                
                const titulo = Systemrobux.get('mensagem_titulo') || '💎 Comprar Robux';
                const descricao = Systemrobux.get('mensagem_descricao') || 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const cor = Systemrobux.get('mensagem_cor') || '#2b2d31';
                const banner = Systemrobux.get('mensagem_banner');
                const modo = Systemrobux.get('mensagem_modo') || 'container';
                
                const modoTexto = modo === 'container' ? '``Component v2 (Container)``' : '``Embed``';
                
                const tituloConfigurado = titulo !== '💎 Comprar Robux';
                const descricaoConfigurada = descricao !== 'Clique no botão abaixo para comprar Robux de forma rápida e segura!';
                const corConfigurada = cor !== '#2b2d31';
                
                const tituloStatus = tituloConfigurado ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const descricaoStatus = descricaoConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const bannerStatus = banner ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                const corStatus = corConfigurada ? '``🟢 Configurado``' : '``🔴 Não Configurado``';
                
                const rowBotoes1 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_alterar_modo")
                        .setLabel("Alterar Modo")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_configurar")
                        .setLabel("Configurar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_resetar")
                        .setLabel("Resetar Config Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(4)
                );
                
                const rowBotoes2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_msg_preview")
                        .setLabel("Ver Preview")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_msg_postar")
                        .setLabel("Postar Mensagem")
                        .setEmoji(Emojis.get('_lapis_emoji'))
                        .setStyle(3),
                    new ButtonBuilder()
                        .setCustomId("voltar_robux_painel")
                        .setLabel('Voltar')
                        .setEmoji(Emojis.get('_back_emoji'))
                        .setStyle(2)
                );

                const containerContent = res.main(
                    { type: 10, content: `-# Painel > Extensões > Ilusion Bux > Configurar Mensagem` },
                    { type: 14 },
                    { type: 10, content: `## ${Emojis.get('_lapis_emoji')} Configurar Mensagem de Vendas\n\n> Personalize a mensagem que será exibida no canal de vendas.` },
                    { type: 14 },
                    { type: 10, content: `**Informações Detalhadas**\n- Modo: ${modoTexto}\n- Título: ${tituloStatus}\n- Descrição: ${descricaoStatus}\n- Banner: ${bannerStatus}\n- Cor: ${corStatus}` },
                    { type: 14 },
                    { type: 10, content: `**Funcionalidades:**\n- Altere entre modo Container ou Embed\n- Configure título, descrição, banner e cor da mensagem\n- Visualize um preview antes de postar\n- Poste a mensagem no canal de vendas configurado` },
                    { type: 14 }
                ).with({
                    components: [rowBotoes1, rowBotoes2],
                    flags: [64]
                });

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'robux_calcular') {
                const rowBotoes = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId("robux_calc_reais_robux")
                        .setLabel("Converter Reais para Robux")
                        .setEmoji('1465182769553346695')
                        .setStyle(2),
                    new ButtonBuilder()
                        .setCustomId("robux_calc_robux_reais")
                        .setLabel("Converter Robux para Reais")
                        .setEmoji('1465182769553346695')
                        .setStyle(2)
                );

                await interaction.reply({
                    content: `## Calculadora de Robux\n\n> Escolha o tipo de conversão que deseja realizar:`,
                    components: [rowBotoes],
                    ephemeral: true
                });
            }

            if (interaction.customId === 'robux_comprar') {
                const { CreateCarrinhoRobux } = require("../../Functions/CreateCarrinhoRobux");
                await CreateCarrinhoRobux(interaction);
            }

            if (interaction.customId.startsWith('robux_select_taxa_')) {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const quantidade = parseInt(interaction.customId.replace('robux_select_taxa_', ''));
                const tipoTaxa = interaction.values[0];
                
                const modal = new ModalBuilder()
                    .setCustomId(`modal_robux_username_${quantidade}_${tipoTaxa}`)
                    .setTitle('Nome de Usuário do Roblox');

                const inputUsername = new TextInputBuilder()
                    .setCustomId('robux_username')
                    .setLabel('Digite seu nome de usuário do Roblox')
                    .setPlaceholder('Ex: JohnDoe123')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(3)
                    .setMaxLength(20);

                const row = new ActionRowBuilder().addComponents(inputUsername);
                modal.addComponents(row);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_select_tipo') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const tipoSelecionado = interaction.values[0];
                
                const modal = new ModalBuilder()
                    .setCustomId(`modal_robux_dados_${tipoSelecionado}`)
                    .setTitle(`Comprar Robux ${tipoSelecionado === 'com_taxa' ? 'com Taxa' : 'sem Taxa'}`);

                const inputUsername = new TextInputBuilder()
                    .setCustomId('robux_username')
                    .setLabel('Nome de Usuário do Roblox')
                    .setPlaceholder('Digite seu nome de usuário do Roblox')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(3)
                    .setMaxLength(20);

                const inputQuantidade = new TextInputBuilder()
                    .setCustomId('robux_quantidade')
                    .setLabel('Quantidade de Robux')
                    .setPlaceholder('Digite a quantidade de Robux (ex: 1000)')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(1)
                    .setMaxLength(10);

                const row1 = new ActionRowBuilder().addComponents(inputUsername);
                const row2 = new ActionRowBuilder().addComponents(inputQuantidade);

                modal.addComponents(row1, row2);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_calc_reais_robux') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_calc_reais_robux')
                    .setTitle('Converter Reais para Robux');

                const inputValor = new TextInputBuilder()
                    .setCustomId('valor_reais')
                    .setLabel('Valor em Reais (R$)')
                    .setPlaceholder('Ex: 50.00')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const row = new ActionRowBuilder().addComponents(inputValor);
                modal.addComponents(row);
                
                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_calc_robux_reais') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_calc_robux_reais')
                    .setTitle('Converter Robux para Reais');

                const inputValor = new TextInputBuilder()
                    .setCustomId('valor_robux')
                    .setLabel('Quantidade de Robux')
                    .setPlaceholder('Ex: 5000')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true);

                const row = new ActionRowBuilder().addComponents(inputValor);
                modal.addComponents(row);
                
                await interaction.showModal(modal);
            }

            if (interaction.customId.startsWith('robux_tentar_novamente_')) {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const parts = interaction.customId.replace('robux_tentar_novamente_', '').split('_');
                const quantidade = parseInt(parts[0]);
                const tipoTaxa = parts[1];
                
                const modal = new ModalBuilder()
                    .setCustomId(`modal_robux_username_${quantidade}_${tipoTaxa}`)
                    .setTitle('Nome de Usuário do Roblox');

                const inputUsername = new TextInputBuilder()
                    .setCustomId('robux_username')
                    .setLabel('Digite seu nome de usuário do Roblox')
                    .setPlaceholder('Ex: JohnDoe123')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(3)
                    .setMaxLength(20);

                const row = new ActionRowBuilder().addComponents(inputUsername);
                modal.addComponents(row);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_nao_sou_eu') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { carrinhosrobux } = require("../../DataBaseJson");
                
                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho. Tente novamente.`,
                        ephemeral: true
                    });
                }

                const modal = new ModalBuilder()
                    .setCustomId(`modal_robux_corrigir_username`)
                    .setTitle('Corrigir Nome de Usuário');

                const inputUsername = new TextInputBuilder()
                    .setCustomId('robux_username_corrigir')
                    .setLabel('Digite o nome de usuário correto')
                    .setPlaceholder('Ex: JohnDoe123')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(3)
                    .setMaxLength(20);

                const row = new ActionRowBuilder().addComponents(inputUsername);
                modal.addComponents(row);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'modal_robux_corrigir_username') {
                const { carrinhosrobux } = require("../../DataBaseJson");
                const { DentroCarrinhoRobux } = require("../../Functions/DentroCarrinhoRobux");
                const axios = require("axios");
                
                const username = interaction.fields.getTextInputValue('robux_username_corrigir');
                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);

                if (!carrinhoData) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho.`,
                        ephemeral: true
                    });
                }

                await interaction.deferReply({ ephemeral: true });

                let robloxData = null;
                try {
                    const userSearchResponse = await axios.post('https://users.roblox.com/v1/usernames/users', {
                        usernames: [username],
                        excludeBannedUsers: false
                    });

                    if (userSearchResponse.data.data && userSearchResponse.data.data.length > 0) {
                        robloxData = { exists: true };
                    }
                } catch (error) {
                    console.error('[Validar Roblox] Erro:', error.message);
                }

                if (!robloxData || !robloxData.exists) {
                    return interaction.editReply({
                        content: `${Emojis.get('negative')} O nome de usuário \`${username}\` não foi encontrado no Roblox. Tente novamente.`
                    });
                }

                const messages = await interaction.channel.messages.fetch({ limit: 10 });
                const embedMessages = messages.filter(msg => 
                    msg.author.id === client.user.id && 
                    msg.embeds.length > 0 &&
                    (msg.embeds[0].title?.includes('Pedido') || msg.embeds[0].title?.includes('Confirmar'))
                );

                for (const msg of embedMessages.values()) {
                    try {
                        await msg.delete();
                    } catch (err) {
                        console.error('[Delete Embed] Erro:', err);
                    }
                }

                const sucesso = await DentroCarrinhoRobux(
                    interaction.channel, 
                    interaction.guild, 
                    carrinhoData.quantidade, 
                    carrinhoData.tipoTaxa, 
                    username, 
                    carrinhoData.precoUnitario, 
                    carrinhoData.valorTotal
                );

                if (!sucesso) {
                    return interaction.editReply({
                        content: `${Emojis.get('negative')} Erro ao validar conta do Roblox. Tente novamente.`
                    });
                }

                await interaction.editReply({
                    content: `${Emojis.get('checker')} Username corrigido com sucesso! Verifique as informações acima.`
                });
            }

            if (interaction.customId === 'robux_cancelar_carrinho') {
                const { carrinhosrobux } = require("../../DataBaseJson");
                
                await interaction.reply({
                    content: `${Emojis.get('loading')} Cancelando carrinho...`,
                    ephemeral: true
                });

                try {
                    await carrinhosrobux.delete(interaction.channel.id);

                    await interaction.channel.delete();
                } catch (error) {
                    console.error('[Cancelar Carrinho Robux] Erro:', error);
                    await interaction.editReply({
                        content: `${Emojis.get('negative')} Erro ao cancelar carrinho.`
                    });
                }
            }

            if (interaction.customId.startsWith('robux_prosseguir_')) {
                const { VerificarPagamentoRobux } = require("../../Functions/VerificarPagamentoRobux");
                await VerificarPagamentoRobux(interaction, client);
            }

            if (interaction.customId === 'robux_pagar_pix') {
                const { carrinhosrobux, configuracao } = require("../../DataBaseJson");
                
                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho.`,
                        ephemeral: true
                    });
                }

                const misticStatus = configuracao.get("pagamentos.MisticSystem") || false;
                const imapStatus = configuracao.get("pagamentos.imap.status") || false;
                const efiStatus = configuracao.get("pagamentos.sistema_efi") || false;
                const mpStatus = configuracao.get("pagamentos.MpOnOff") || false;

                if (misticStatus) {
                    const { DentroCarrinhoRobuxMisticPay } = require("../../Functions/DentroCarrinhoRobux");
                    await DentroCarrinhoRobuxMisticPay(interaction, client);
                } 
                else if (imapStatus) {
                    const { DentroCarrinhoRobuxImap } = require("../../Functions/DentroCarrinhoRobux");
                    await DentroCarrinhoRobuxImap(interaction, client);
                } 
                else if (efiStatus) {
                    const { DentroCarrinhoRobuxEfiBank } = require("../../Functions/DentroCarrinhoRobux");
                    await DentroCarrinhoRobuxEfiBank(client, interaction);
                } 
                else if (mpStatus) {
                    const { DentroCarrinhoRobuxPix } = require("../../Functions/DentroCarrinhoRobux");
                    await DentroCarrinhoRobuxPix(interaction, client);
                }
                else {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Nenhum método de pagamento automático está ativado no momento. Entre em contato com o Suporte.`,
                        ephemeral: true
                    });
                }
            }

            if (interaction.customId === 'robux_voltar_carrinho') {
                const { carrinhosrobux } = require("../../DataBaseJson");
                const { DentroCarrinhoRobux } = require("../../Functions/DentroCarrinhoRobux");
                
                await interaction.deferUpdate();

                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.followUp({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho.`,
                        ephemeral: true
                    });
                }

                try {
                    const messages = await interaction.channel.messages.fetch({ limit: 10 });
                    const botMessages = messages.filter(msg => msg.author.id === client.user.id);
                    
                    for (const msg of botMessages.values()) {
                        try {
                            await msg.delete();
                        } catch (err) {
                            console.error('[Delete Message] Erro:', err);
                        }
                    }
                } catch (error) {
                    console.error('[Fetch Messages] Erro:', error);
                }

                await DentroCarrinhoRobux(
                    interaction.channel,
                    interaction.guild,
                    carrinhoData.quantidade,
                    carrinhoData.tipoTaxa,
                    carrinhoData.username,
                    carrinhoData.precoUnitario,
                    carrinhoData.valorTotal
                );
            }

            if (interaction.customId === 'robux_nao_sou_eu') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { carrinhosrobux } = require("../../DataBaseJson");
                
                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho. Tente novamente.`,
                        ephemeral: true
                    });
                }

                const modal = new ModalBuilder()
                    .setCustomId(`modal_robux_username_${carrinhoData.quantidade}_${carrinhoData.tipoTaxa}`)
                    .setTitle('Corrigir Nome de Usuário');

                const inputUsername = new TextInputBuilder()
                    .setCustomId('robux_username')
                    .setLabel('Digite o nome de usuário correto')
                    .setPlaceholder('Ex: JohnDoe123')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMinLength(3)
                    .setMaxLength(20);

                const row = new ActionRowBuilder().addComponents(inputUsername);
                modal.addComponents(row);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'robux_confirmar_gamepass') {
                const { carrinhosrobux } = require("../../DataBaseJson");
                const { verificarGamepass, MostrarPaginaAprovado } = require("../../Functions/VerificarPagamentoRobux");
                
                await interaction.deferUpdate();

                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.followUp({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho.`,
                        ephemeral: true
                    });
                }

                const valorGamepass = carrinhoData.tipoTaxa === 'com_taxa' ? Math.ceil(carrinhoData.quantidade * 1.3) : carrinhoData.quantidade;

                const resultadoGamepass = await verificarGamepass(carrinhoData.robloxUserId, valorGamepass);

                if (!resultadoGamepass.encontrada) {
                    return interaction.followUp({
                        content: `${Emojis.get('negative')} Gamepass ainda não encontrada! Certifique-se de criar uma gamepass no valor exato de **${valorGamepass.toLocaleString('pt-BR')} Robux** e tente novamente.`,
                        ephemeral: true
                    });
                }

                try {
                    const messages = await interaction.channel.messages.fetch({ limit: 10 });
                    const botMessages = messages.filter(msg => msg.author.id === client.user.id);
                    
                    for (const msg of botMessages.values()) {
                        try {
                            await msg.delete();
                        } catch (err) {
                            console.error('[Delete Message] Erro:', err);
                        }
                    }
                } catch (error) {
                    console.error('[Fetch Messages] Erro:', error);
                }

                await MostrarPaginaAprovado(interaction.channel, carrinhoData, resultadoGamepass);
            }

            if (interaction.customId === 'robux_confirmar_entrega') {
                const { carrinhosrobux, configuracao } = require("../../DataBaseJson");
                const { getPermissions } = require("../../Functions/PermissionsCache.js");
                
                const perm = await getPermissions(client.user.id);
                if (perm === null || !perm.includes(interaction.user.id)) {
                    return interaction.reply({ 
                        content: `${Emojis.get('negative')} | Você não possui permissão para confirmar entregas.`, 
                        ephemeral: true 
                    });
                }

                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                
                const modal = new ModalBuilder()
                    .setCustomId('modal_robux_confirmar_entrega')
                    .setTitle('Confirmar Entrega de Robux');

                const inputPrint = new TextInputBuilder()
                    .setCustomId('link_print')
                    .setLabel('Link da Print da Entrega (Opcional)')
                    .setPlaceholder('https://imgur.com/exemplo.png')
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false);

                const row = new ActionRowBuilder().addComponents(inputPrint);
                modal.addComponents(row);

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'modal_robux_confirmar_entrega') {
                const { carrinhosrobux, configuracao } = require("../../DataBaseJson");
                
                await interaction.deferReply({ ephemeral: true });

                const linkPrint = interaction.fields.getTextInputValue('link_print');
                const carrinhoData = await carrinhosrobux.get(interaction.channel.id);
                
                if (!carrinhoData) {
                    return interaction.editReply({
                        content: `${Emojis.get('negative')} Erro ao buscar dados do carrinho.`
                    });
                }

                const { res } = require("../../res");
                
                let containerEntrega = res.main(
                    { type: 10, content: `# ${Emojis.get('robux')} Nova Entrega Concluída!` },
                    { type: 14 },
                    { type: 10, content: `> O usuário <@${carrinhoData.user.id}> realizou uma compra em nossa loja de **${carrinhoData.quantidade.toLocaleString('pt-BR')} Robux**!\n\n**Agradecemos pela preferência e esperamos você novamente!** 🎉` }
                );

                if (linkPrint && linkPrint.trim() !== '') {
                    containerEntrega = res.main(
                        { type: 10, content: `# ${Emojis.get('robux')} Nova Entrega Concluída!` },
                        { type: 10, content: `> O usuário <@${carrinhoData.user.id}> realizou uma compra em nossa loja de **${carrinhoData.quantidade.toLocaleString('pt-BR')} Robux. Agradecemos pela preferência e esperamos você novamente!**` },
                        { type: 14 },
                        { type: 11, url: linkPrint }
                    );
                }

                const containerFinal = containerEntrega.with({});

                try {
                    const canalEventos = configuracao.get('ConfigChannels.eventbuy');
                    
                    if (canalEventos) {
                        const channel = await client.channels.fetch(canalEventos);
                        await channel.send(containerFinal);
                    }
                } catch (error) {
                    console.error('[Enviar Container Entrega] Erro:', error);
                }

                await carrinhosrobux.delete(interaction.channel.id);

                await interaction.editReply({
                    content: `${Emojis.get('checker')} Entrega confirmada com sucesso! O carrinho será fechado em 5 segundos.`
                });

                setTimeout(async () => {
                    try {
                        await interaction.channel.delete();
                    } catch (error) {
                        console.error('[Delete Thread] Erro:', error);
                    }
                }, 5000);
            }

            if (interaction.customId == 'codigocopiaecola') {
                const { carrinhosrobux, carrinhos } = require("../../DataBaseJson");
                
                const carrinhoRobux = await carrinhosrobux.get(interaction.channel.id);
                
                if (carrinhoRobux && carrinhoRobux.pagamentos && carrinhoRobux.pagamentos.cp) {
                    return interaction.reply({ 
                        content: `${carrinhoRobux.pagamentos.cp}`, 
                        ephemeral: true 
                    });
                }
                
                const carrinhoNormal = await carrinhos.get(interaction.channel.id);
                
                if (carrinhoNormal && carrinhoNormal.pagamentos && carrinhoNormal.pagamentos.cp) {
                    return interaction.reply({ 
                        content: `${carrinhoNormal.pagamentos.cp}`, 
                        ephemeral: true 
                    });
                }
                
                return interaction.reply({ 
                    content: `${Emojis.get('negative')} Código PIX não encontrado!`, 
                    ephemeral: true 
                });
            }

            if (interaction.customId == 'deletchannel') {
                const { carrinhosrobux, carrinhos } = require("../../DataBaseJson");
                const { EmbedBuilder } = require("discord.js");
                
                const carrinhoRobux = await carrinhosrobux.get(interaction.channel.id);
                
                if (carrinhoRobux) {
                    try {
                        const embedCancelado = new EmbedBuilder()
                            .setColor('#ff0000')
                            .setAuthor({ 
                                name: 'Carrinho Encerrado', 
                                iconURL: 'https://images-ext-1.discordapp.net/external/ZXzGjhpOPu8Pl5ysOHAEieC1Wbr-L3qYWAS4h5cP740/https/public-blob.squarecloud.dev/3605c3eaef113a059abdd63b95adc8db9d08e3a8/CarrinhoFechado_mfvwnn44-fea7.png' 
                            })
                            .setTitle('Pedido Cancelado')
                            .setDescription(`Seu carrinho de Robux foi encerrado. Você pode iniciar uma nova compra a qualquer momento.`)
                            .addFields(
                                { name: 'Detalhes do Pedido Cancelado', value: `\`${carrinhoRobux?.quantidade || 0}x - Robux | R$ ${carrinhoRobux?.valorTotal || '0.00'}\`` }
                            )
                            .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleDateString('pt-BR')}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                            .setTimestamp();
                        
                        const canalPai = interaction.channel.parent || interaction.channel;
                        const linkCanal = `https://discord.com/channels/${interaction.guild.id}/${canalPai.id}`;
                        
                        const rowBotao = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Abrir Novo Carrinho')
                                .setURL(linkCanal)
                                .setStyle(5)
                        );
                        
                        await interaction.user.send({ embeds: [embedCancelado], components: [rowBotao] });
                    } catch (error) {
                    }
                    
                    await carrinhosrobux.delete(interaction.channel.id);
                    
                    await interaction.channel.delete();
                    return;
                }
                
                const carrinhoNormal = await carrinhos.get(interaction.channel.id);
                
                if (carrinhoNormal) {
                    try {
                        const embedCancelado = new EmbedBuilder()
                            .setColor('#ff0000')
                            .setAuthor({ 
                                name: 'Carrinho Encerrado', 
                                iconURL: 'https://images-ext-1.discordapp.net/external/ZXzGjhpOPu8Pl5ysOHAEieC1Wbr-L3qYWAS4h5cP740/https/public-blob.squarecloud.dev/3605c3eaef113a059abdd63b95adc8db9d08e3a8/CarrinhoFechado_mfvwnn44-fea7.png' 
                            })
                            .setTitle('Pedido Cancelado')
                            .setDescription(`Seu carrinho foi encerrado. Você pode iniciar uma nova compra a qualquer momento.`)
                            .addFields(
                                { name: 'Detalhes do Pedido Cancelado', value: `\`${carrinhoNormal?.quantidadeselecionada || 1}x ${carrinhoNormal?.infos?.produto || 'Produto'} - ${carrinhoNormal?.infos?.campo || 'Campo'}\`` }
                            )
                            .setFooter({ text: `${interaction.guild.name} • ${new Date().toLocaleDateString('pt-BR')}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                            .setTimestamp();
                        
                        const canalPai = interaction.channel.parent || interaction.channel;
                        const linkCanal = `https://discord.com/channels/${interaction.guild.id}/${canalPai.id}`;
                        
                        const rowBotao = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Abrir Novo Carrinho')
                                .setURL(linkCanal)
                                .setStyle(5)
                        );
                        
                        await interaction.user.send({ embeds: [embedCancelado], components: [rowBotao] });
                    } catch (error) {
                    }
                    
                    await interaction.channel.delete();
                }
            }


            if (interaction.customId.startsWith('voltar1')) {
                try {
                await Painel(interaction, client);
                  } catch (err) {
                 console.error('Erro ao executar Painel:', err);
                await interaction.reply({ content: '❌ Ocorreu um erro.', ephemeral: true });
                }
              }



            if (interaction.customId.startsWith('addfuncaoticket')) {

                const dd = tickets.get('tickets.funcoes')
               
                
                if (dd && Object.keys(dd).length > 24) {
                    return interaction.reply({ content: `${Emojis.get('negative')} | Você não pode criar mais de 24 funções em seu TICKET!` });
                }
                  
                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsj1233js123dua123')
                    .setTitle(`Adicionar função`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DA FUNÇÃO`)
                    .setPlaceholder(`Insira aqui um nome, como: Suporte`)
                    .setStyle(TextInputStyle.Short)

                    .setRequired(true)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`PRÉ DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma pré descrição, ex: "Preciso de suporte."`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(99)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui a descrição da função.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(false)
                    .setMaxLength(99)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`EMOJI DA FUNÇÃO`)
                    .setPlaceholder(`Insira um nome ou id de um emoji do servidor.`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);


                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }
            if (interaction.customId.startsWith('definiraparencia')) {



                const modalaAA = new ModalBuilder()
                    .setCustomId('0-89du0awd8awdaw8daw')
                    .setTitle(`Editar Ticket`);

                const dd = tickets.get(`tickets.aparencia`)

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`TITULO`)
                    .setPlaceholder(`Insira aqui um nome, como: Entrar em contato`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.title == undefined ? '' : dd.title)
                    .setRequired(true)


                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`DESCRIÇÃO`)
                    .setPlaceholder(`Insira aqui uma descrição.`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setValue(dd?.description == undefined ? '' : dd.description)
                    .setMaxLength(500)
                    .setRequired(true)


                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`BANNER (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui uma URL de uma imagem ou GIF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.banner == undefined ? '' : dd.banner)
                    .setRequired(false)



                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DO EMBED (OPCIONAL)`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: FFFFFF`)
                    .setStyle(TextInputStyle.Short)
                    .setValue(dd?.color == undefined ? '' : dd.color)
                    .setRequired(false)


                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);



            }

            if (interaction.customId.startsWith('painelconfigticket')) {
                PainelTickets(interaction, client)
            }

            if (interaction.customId === 'ticket_config_aparencia') {
                await ConfigurarAparencia(interaction, client);
            }

            if (interaction.customId === 'ticket_config_ilusion_ai') {
                await ConfigurarIlusionAI(interaction, client);
            }

            if (interaction.customId === 'ticket_toggle_ia') {
                await ToggleIlusionAI(interaction, client);
            }

            if (interaction.customId === 'ticket_editar_prompt') {
                return await ModalEditarPrompt(interaction);
            }

            if (interaction.customId === 'ticket_alterar_modo_exibicao') {
                await AlterarModoExibicao(interaction, client);
            }

            if (interaction.customId === 'ticket_editar_aparencia') {
                return await ModalEditarAparencia(interaction);
            }

            if (interaction.customId === 'ticket_config_funcoes') {
                await ConfigurarFuncoes(interaction, client);
            }

            if (interaction.customId === 'ticket_adicionar_funcao') {
                return await ModalAdicionarFuncao(interaction);
            }

            if (interaction.customId === 'ticket_remover_funcao') {
                await PaginaRemoverFuncao(interaction, client);
            }

            if (interaction.customId === 'ticket_excluir_todas_funcoes') {
                await HandleExcluirTodasFuncoes(interaction, client);
            }

            if (interaction.customId === 'ticket_editar_funcao') {
                await PaginaEditarFuncao(interaction, client);
            }

            if (interaction.customId.startsWith('ticket_deletar_funcao_')) {
                const funcaoId = interaction.customId.replace('ticket_deletar_funcao_', '');
                await HandleDeletarFuncao(interaction, client, funcaoId);
            }

            if (interaction.customId === 'ticket_postar_mensagem') {
                await PaginaPostarMensagem(interaction, client);
                return;
            }

            if (interaction.customId === 'ticket_horario_atendimento') {
                await ConfigurarHorarioAtendimento(interaction, client);
            }

            if (interaction.customId === 'ticket_toggle_horario') {
                await ToggleHorarioAtendimento(interaction, client);
            }

            if (interaction.customId === 'ticket_toggle_folgas') {
                await ToggleSistemaFolgas(interaction, client);
            }

            if (interaction.customId === 'ticket_config_horarios') {
                return await ModalConfigurarHorarios(interaction);
            }

            if (interaction.customId === 'ticket_config_dias_folga') {
                await PaginaConfigurarDiasFolga(interaction, client);
            }

            if (interaction.customId.startsWith('abrir_ticket_')) {
                const { CreateTicket } = require("../../Functions/CreateTicket");
                const funcaoId = interaction.customId.replace('abrir_ticket_', '');
                await CreateTicket(interaction, client, funcaoId);
                return;
            }

            if (interaction.customId === 'ticket_criar_painel') {
                return await ModalCriarPainelTicket(interaction);
            }

            if (interaction.customId === 'ticket_voltar_lista') {
                await painelTicket(interaction);
            }

            if (interaction.customId.startsWith('ticket_editar_')) {
                const painelId = interaction.customId.replace('ticket_editar_', '');
                return await ModalEditarPainel(interaction, painelId);
            }

            if (interaction.customId.startsWith('ticket_addfuncao_')) {
                const painelId = interaction.customId.replace('ticket_addfuncao_', '');
                return await ModalAddFuncaoTicket(interaction, painelId);
            }

            if (interaction.customId.startsWith('ticket_remfuncao_')) {
                const painelId = interaction.customId.replace('ticket_remfuncao_', '');
                await PaginaRemoverFuncao(interaction, painelId);
            }

            if (interaction.customId.startsWith('ticket_gerenciar_')) {
                const painelId = interaction.customId.replace('ticket_gerenciar_', '');
                await PaginaGerenciarPainel(interaction, painelId);
            }

            if (interaction.customId.startsWith('ticket_preview_')) {
                const painelId = interaction.customId.replace('ticket_preview_', '');
                await PreviewTicket(interaction, painelId);
            }

            if (interaction.customId.startsWith('ticket_categorias_')) {
                const painelId = interaction.customId.replace('ticket_categorias_', '');
                await PaginaCategorias(interaction, painelId);
            }

            if (interaction.customId.startsWith('painelconfigrobux')) {
                painelRobux(interaction)
            }

            if (interaction.customId === 'robux_config_valores') {
                await modalConfigValores(interaction);
            }

            if (interaction.customId === 'robux_config_limites') {
                await modalConfigLimites(interaction);
            }

            if (interaction.customId === 'voltar_robux_painel') {
                await painelRobux(interaction);
            }

            if (interaction.customId === 'robux_config_mensagem') {
                await painelConfigMensagem(interaction);
            }

            if (interaction.customId === 'robux_enviar_mensagem') {
                const Discord = require("discord.js");
                const selectChannel = new Discord.ChannelSelectMenuBuilder()
                    .setCustomId(`robux_channel_enviar_mensagem`)
                    .setPlaceholder('Selecione o canal para enviar a mensagem')
                    .setChannelTypes(Discord.ChannelType.GuildText);

                const row = new ActionRowBuilder().addComponents(selectChannel);
                await interaction.reply({ 
                    content: `${Emojis.get('info')} | Selecione o canal onde deseja enviar a mensagem de compra:`, 
                    components: [row], 
                    ephemeral: true 
                });
            }

            if (interaction.customId === 'robux_configurar_container') {
                await modalConfigurarContainer(interaction);
            }

            if (interaction.customId === 'robux_visualizar_mensagem') {
                await visualizarMensagem(interaction);
            }

            if (interaction.customId === 'voltar_config_mensagem') {
                await painelConfigMensagem(interaction);
            }

            if (interaction.customId === 'robux_personalizar') {
                await interaction.reply({ content: `${Emojis.get('negative')} | Esta função ainda está em desenvolvimento.`, ephemeral: true });
            }

            if (interaction.customId === 'robux_iniciar_compra_robux') {
                await modalNickRoblox(interaction, 'robux');
            }

            if (interaction.customId === 'robux_iniciar_compra_gamepass') {
                await modalNickRoblox(interaction, 'gamepass');
            }

            if (interaction.customId === 'robux_cancelar_compra') {
                await cancelarCompra(interaction, client);
            }

            if (interaction.customId === 'robux_atualizar_gamepass') {
                await atualizarGamepasses(interaction);
            }

            if (interaction.customId === 'robux_voltar_gamepasses') {
                await voltarParaGamepasses(interaction);
            }

            if (interaction.customId === 'robux_ir_pagamento') {
                await irParaPagamentoRobux(interaction, client);
            }

            if (interaction.customId === 'robux_copiar_pix') {
                await copiarPixRobux(interaction);
            }

            if (interaction.customId === 'robux_copiar_pix_semi') {
                const { carrinhosRobux } = require("../../Functions/CarrinhoRobux");
                const carrinho = carrinhosRobux.get(`${interaction.user.id}`);
                
                if (carrinho && carrinho.pagamento?.pixCopiaCola) {
                    const pagamento = configuracao.get(`pagamentos.SemiAutomatico`);
                    await interaction.reply({ 
                        content: `Chave pix: ${pagamento?.pix || carrinho.pagamento.pixCopiaCola}`, 
                        ephemeral: true 
                    });
                } else {
                    await interaction.reply({ 
                        content: `${Emojis.get('negative') || '❌'} | Código PIX não encontrado!`, 
                        ephemeral: true 
                    });
                }
            }

            if (interaction.customId === 'robux_confirmar_pagamento_manual') {
                const { confirmarPagamentoManualRobux } = require("../../Functions/PagamentoRobux");
                await confirmarPagamentoManualRobux(interaction, client);
            }

            if (interaction.customId.startsWith('robux_entrega_concluida_')) {
                const pedidoId = interaction.customId.replace('robux_entrega_concluida_', '');
                await confirmarEntregaRobux(interaction, pedidoId, client);
            }



            if (interaction.customId.startsWith('personalizarbot')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111231idsjjs123dua123')
                    .setTitle(`Editar perfil do bot`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`NOME DE USUÁRIO`)
                    .setValue(`${client.user.username}`)
                    .setPlaceholder(`Insira um nome de usuário (só pode mudar 3x por hora)`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`AVATAR`)
                    .setPlaceholder(`Insira uma URL de um ícone`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`STATUS 1`)
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`STATUS 2`)
                    .setPlaceholder(`Insira aqui um status personalizado`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);

                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6);
                await interaction.showModal(modalaAA);

            }


            if (interaction.customId.startsWith('coresembeds')) {

                const modalaAA = new ModalBuilder()
                    .setCustomId('sdaju11111idsjjs123dua123')
                    .setTitle(`Editar cores dos embeds`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`COR PRINCIPAL`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #Obd4cd`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN2 = new TextInputBuilder()
                    .setCustomId('tokenMP2')
                    .setLabel(`COR DE PROCESSAMENTO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #fcba03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN4 = new TextInputBuilder()
                    .setCustomId('tokenMP3')
                    .setLabel(`COR DE SUCESSO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #39fc03`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN5 = new TextInputBuilder()
                    .setCustomId('tokenMP5')
                    .setLabel(`COR DE FALHA`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #ff0000`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const newnameboteN6 = new TextInputBuilder()
                    .setCustomId('tokenMP6')
                    .setLabel(`COR DE FINALIZADO`)
                    .setPlaceholder(`Insira aqui um código Hex Color, ex: #7363ff`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)

                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN);
                const firstActionRow4 = new ActionRowBuilder().addComponents(newnameboteN2);
                const firstActionRow5 = new ActionRowBuilder().addComponents(newnameboteN4);
                const firstActionRow6 = new ActionRowBuilder().addComponents(newnameboteN5);
                const firstActionRow7 = new ActionRowBuilder().addComponents(newnameboteN6);



                modalaAA.addComponents(firstActionRow3, firstActionRow4, firstActionRow5, firstActionRow6, firstActionRow7);
                await interaction.showModal(modalaAA);

            }



            if (interaction.customId.startsWith('voltar2')) {
                Gerenciar(interaction, client)

            }

            if (interaction.customId.startsWith('eaffaawwawa')) {
                automatico(interaction, client)
            }

            if (interaction.customId === 'ilusionai_dev') {
                interaction.reply({ 
                    content: `🤖 **Ilusion AI** está em desenvolvimento!\n\n> Em breve você terá acesso a recursos de inteligência artificial para automatizar ainda mais seu servidor.`, 
                    ephemeral: true 
                });
            }
            if (interaction.customId.startsWith('voltarautomaticos')) {
                automatico(interaction, client)
            }

            if (interaction.customId === 'visualizar_configs_reacao') {
                const { visualizarConfiguracoes } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                await visualizarConfiguracoes(interaction, client);
            }

            if (interaction.customId === 'adicionar_config_reacao') {
                const { painelSelecionarCanal } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                await painelSelecionarCanal(interaction);
            }

            if (interaction.customId === 'apagar_config_reacao') {
                const { painelExcluirConfig } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                await painelExcluirConfig(interaction, client);
            }

            if (interaction.customId === 'ativar_reacoes_auto' || interaction.customId === 'desativar_reacoes_auto') {
                const { loadReacoesData, saveReacoesData, painelReacoesAutomaticas } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                const data = loadReacoesData();
                data.ativo = !data.ativo;
                saveReacoesData(data);
                await painelReacoesAutomaticas(interaction, client);
            }

            if (interaction.customId === 'voltar_painel_reacoes') {
                const { painelReacoesAutomaticas } = require("../../Eventos/Sistemas Automaticos/reacoesautomaticas.js");
                await painelReacoesAutomaticas(interaction, client);
            }

            if (interaction.customId === 'ativar_invite_tracker' || interaction.customId === 'desativar_invite_tracker') {
                const { loadInvitesData, saveInvitesData, painelInviteTracker } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                const data = loadInvitesData();
                data.ativo = !data.ativo;
                saveInvitesData(data);
                await painelInviteTracker(interaction, client);
            }

            if (interaction.customId === 'definir_canal_invite') {
                const { painelDefinirCanal } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                await painelDefinirCanal(interaction);
            }

            if (interaction.customId === 'configurar_msgs_invite') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadInvitesData } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                const data = loadInvitesData();

                const modal = new ModalBuilder()
                    .setCustomId('modal_configurar_msgs_invite')
                    .setTitle('Configurar Mensagens do Invite Tracker');

                modal.addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('mensagemEntradaNormal')
                            .setLabel('Mensagem de Entrada (Normal)')
                            .setStyle(TextInputStyle.Paragraph)
                            .setValue(data.mensagemEntradaNormal)
                            .setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('mensagemEntradaVanity')
                            .setLabel('Mensagem de Entrada (Vanity URL)')
                            .setStyle(TextInputStyle.Paragraph)
                            .setValue(data.mensagemEntradaVanity)
                            .setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('mensagemSaida')
                            .setLabel('Mensagem de Saída')
                            .setStyle(TextInputStyle.Paragraph)
                            .setValue(data.mensagemSaida)
                            .setRequired(true)
                    )
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'voltar_invite_tracker') {
                const { painelInviteTracker } = require("../../Eventos/Sistemas Automaticos/invitetracker.js");
                await painelInviteTracker(interaction, client);
            }

            if (interaction.customId === 'ativar_boasvindas' || interaction.customId === 'desativar_boasvindas') {
                const { loadBoasvindasData, saveBoasvindasData, painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                const data = loadBoasvindasData();
                data.ativo = !data.ativo;
                saveBoasvindasData(data);
                await painelBoasVindas(interaction, client);
            }

            if (interaction.customId === 'ativar_exclusao_boasvindas' || interaction.customId === 'desativar_exclusao_boasvindas') {
                const { loadBoasvindasData, saveBoasvindasData, painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                const data = loadBoasvindasData();
                data.exclusaoAutomatica = !data.exclusaoAutomatica;
                saveBoasvindasData(data);
                await painelBoasVindas(interaction, client);
            }

            if (interaction.customId === 'definir_canal_boasvindas') {
                const { painelDefinirCanal } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                await painelDefinirCanal(interaction);
            }

            if (interaction.customId === 'remover_canal_boasvindas') {
                const { painelRemoverCanal } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                await painelRemoverCanal(interaction, client);
            }

            if (interaction.customId === 'configurar_msg_boasvindas') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadBoasvindasData } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                
                const data = loadBoasvindasData();

                const modal = new ModalBuilder()
                    .setCustomId('modal_configurar_msg_boasvindas')
                    .setTitle('Configurar Mensagem de Boas-vindas');

                const inputMensagem = new TextInputBuilder()
                    .setCustomId('mensagem_boasvindas')
                    .setLabel('Mensagem de Boas-vindas')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('Use: {membro}, {servidor}, {total}')
                    .setValue(data.mensagem || '')
                    .setRequired(true)
                    .setMaxLength(2000);

                const inputBotaoTexto = new TextInputBuilder()
                    .setCustomId('botao_texto')
                    .setLabel('Texto do Botão (Opcional)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: Clique aqui')
                    .setValue(data.botao?.texto || '')
                    .setRequired(false)
                    .setMaxLength(80);

                const inputBotaoLink = new TextInputBuilder()
                    .setCustomId('botao_link')
                    .setLabel('Link do Botão (Opcional)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: https://discord.gg/...')
                    .setValue(data.botao?.link || '')
                    .setRequired(false)
                    .setMaxLength(512);

                const inputBotaoEmoji = new TextInputBuilder()
                    .setCustomId('botao_emoji')
                    .setLabel('Emoji do Botão (Opcional)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 👋 ou <:emoji:123456>')
                    .setValue(data.botao?.emoji || '')
                    .setRequired(false)
                    .setMaxLength(100);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(inputMensagem),
                    new ActionRowBuilder().addComponents(inputBotaoTexto),
                    new ActionRowBuilder().addComponents(inputBotaoLink),
                    new ActionRowBuilder().addComponents(inputBotaoEmoji)
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'definir_exclusao_boasvindas') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadBoasvindasData } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                
                const data = loadBoasvindasData();

                const modal = new ModalBuilder()
                    .setCustomId('modal_definir_exclusao_boasvindas')
                    .setTitle('Definir Tempo de Exclusão');

                const inputTempo = new TextInputBuilder()
                    .setCustomId('tempo_exclusao')
                    .setLabel('Tempo em Segundos')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 10')
                    .setValue(data.tempoExclusao?.toString() || '10')
                    .setRequired(true)
                    .setMaxLength(5);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(inputTempo)
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'preview_boasvindas') {
                const { previewBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                await previewBoasVindas(interaction);
            }

            if (interaction.customId === 'alterar_modo_boasvindas') {
                const { loadBoasvindasData, saveBoasvindasData, painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                const data = loadBoasvindasData();
                data.modo = data.modo === 'canal' ? 'dm' : 'canal';
                saveBoasvindasData(data);
                await painelBoasVindas(interaction, client);
            }

            if (interaction.customId === 'voltar_boasvindas') {
                const { painelBoasVindas } = require("../../Eventos/Sistemas Automaticos/boasvindas.js");
                await painelBoasVindas(interaction, client);
            }

            if (interaction.customId === 'ativar_nuke_auto' || interaction.customId === 'desativar_nuke_auto') {
                const { loadNukeData, saveNukeData, painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                const { iniciarNukeAutomatico, pararNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeexecutor.js");
                
                const data = loadNukeData();
                data.ativo = !data.ativo;
                saveNukeData(data);

                if (data.ativo) {
                    iniciarNukeAutomatico(client);
                } else {
                    pararNukeAutomatico();
                }

                await painelNukeAutomatico(interaction, client);
            }

            if (interaction.customId === 'definir_horario_nuke') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadNukeData } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                
                const data = loadNukeData();

                const modal = new ModalBuilder()
                    .setCustomId('modal_definir_horario_nuke')
                    .setTitle('Definir Horário do Nuke');

                const inputHorario = new TextInputBuilder()
                    .setCustomId('horario_nuke')
                    .setLabel('Horário (HH:MM - Horário de Brasília)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 03:00')
                    .setValue(data.horario || '00:00')
                    .setRequired(true)
                    .setMaxLength(5)
                    .setMinLength(5);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(inputHorario)
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'definir_canais_nuke') {
                const { painelDefinirCanaisNuke } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                await painelDefinirCanaisNuke(interaction);
            }

            if (interaction.customId === 'voltar_nuke_auto') {
                const { painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                await painelNukeAutomatico(interaction, client);
            }

            if (interaction.customId === 'abrir_sistema_nuke') {
                const { painelNukeAutomatico } = require("../../Eventos/Sistemas Automaticos/nukeautomatico.js");
                await painelNukeAutomatico(interaction, client);
            }

            if (interaction.customId === 'ativar_autolock' || interaction.customId === 'desativar_autolock') {
                const { loadAutolockData, saveAutolockData, painelAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                const { iniciarAutoLock, pararAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockexecutor.js");
                
                const guildId = interaction.guild.id;
                const data = loadAutolockData(guildId);
                data.ativo = !data.ativo;
                saveAutolockData(guildId, data);

                if (data.ativo) {
                    iniciarAutoLock(client, guildId);
                } else {
                    pararAutoLock(guildId);
                }

                await painelAutoLock(interaction, client);
            }

            if (interaction.customId === 'definir_horarios_autolock') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadAutolockData } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                
                const guildId = interaction.guild.id;
                const data = loadAutolockData(guildId);

                const modal = new ModalBuilder()
                    .setCustomId('modal_definir_horarios_autolock')
                    .setTitle('Definir Horários do AutoLock');

                const inputBloquear = new TextInputBuilder()
                    .setCustomId('horario_bloquear')
                    .setLabel('Horário de Bloqueio (HH:MM)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 00:00')
                    .setValue(data.horarioBloquear || '00:00')
                    .setRequired(true)
                    .setMaxLength(5)
                    .setMinLength(5);

                const inputDesbloquear = new TextInputBuilder()
                    .setCustomId('horario_desbloquear')
                    .setLabel('Horário de Desbloqueio (HH:MM)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 08:00')
                    .setValue(data.horarioDesbloquear || '08:00')
                    .setRequired(true)
                    .setMaxLength(5)
                    .setMinLength(5);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(inputBloquear),
                    new ActionRowBuilder().addComponents(inputDesbloquear)
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'definir_canais_autolock') {
                const { painelDefinirCanaisAutolock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                await painelDefinirCanaisAutolock(interaction);
            }

            if (interaction.customId === 'voltar_autolock') {
                const { painelAutoLock } = require("../../Eventos/Sistemas Automaticos/autolockpainel.js");
                await painelAutoLock(interaction, client);
            }

            if (interaction.customId === 'ativar_limpeza_auto' || interaction.customId === 'desativar_limpeza_auto') {
                const { loadLimpezaData, saveLimpezaData, painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                const { iniciarLimpezaAutomatica, pararLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaexecutor.js");
                
                const data = loadLimpezaData();
                data.ativo = !data.ativo;
                saveLimpezaData(data);

                if (data.ativo) {
                    iniciarLimpezaAutomatica(client);
                } else {
                    pararLimpezaAutomatica();
                }

                await painelLimpezaAutomatica(interaction, client);
            }

            if (interaction.customId === 'definir_horario_limpeza') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
                const { loadLimpezaData } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                
                const data = loadLimpezaData();

                const modal = new ModalBuilder()
                    .setCustomId('modal_definir_horario_limpeza')
                    .setTitle('Definir Horário da Limpeza');

                const inputHorario = new TextInputBuilder()
                    .setCustomId('horario_limpeza')
                    .setLabel('Horário (HH:MM - Horário de Brasília)')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Ex: 03:00')
                    .setValue(data.horario || '00:00')
                    .setRequired(true)
                    .setMaxLength(5)
                    .setMinLength(5);

                modal.addComponents(
                    new ActionRowBuilder().addComponents(inputHorario)
                );

                await interaction.showModal(modal);
            }

            if (interaction.customId === 'definir_canais_limpeza') {
                const { painelDefinirCanaisLimpeza } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                await painelDefinirCanaisLimpeza(interaction);
            }

            if (interaction.customId === 'voltar_limpeza_auto') {
                const { painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                await painelLimpezaAutomatica(interaction, client);
            }

            if (interaction.customId === 'abrir_sistema_limpeza') {
                const { painelLimpezaAutomatica } = require("../../Eventos/Sistemas Automaticos/limpezaautomatica.js");
                await painelLimpezaAutomatica(interaction, client);
            }

            if (interaction.customId === 'confirmar_resetar_convites') {
                const { GuildsInvites } = require("../../DataBaseJson");
                const guildId = interaction.guild.id;

                GuildsInvites.delete(`${guildId}.invites`);

                const containerContent = res.main(
                    { type: 10, content: `## ✅ Convites Resetados` },
                    { type: 14 },
                    { type: 10, content: `> Todos os convites do servidor foram resetados com sucesso!` },
                    { type: 14 },
                    { type: 10, content: `**Ação realizada por:** ${interaction.user}` },
                    { type: 14 }
                );

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'cancelar_resetar_convites') {
                const containerContent = res.main(
                    { type: 10, content: `## ❌ Ação Cancelada` },
                    { type: 14 },
                    { type: 10, content: `> O reset de convites foi cancelado.` },
                    { type: 14 }
                );

                await interaction.update(containerContent);
            }

            if (interaction.customId === 'ativar_monitor_feedback' || interaction.customId === 'desativar_monitor_feedback') {
                const { loadMonitorData, saveMonitorData, painelMonitorFeedback } = require("../../Eventos/Sistemas Automaticos/monitorfeedback.js");
                
                const data = loadMonitorData();
                data.ativo = !data.ativo;
                saveMonitorData(data);

                await painelMonitorFeedback(interaction, client);
            }

            if (interaction.customId === 'definir_canal_logs_feedback') {
                const { painelDefinirCanalLogs } = require("../../Eventos/Sistemas Automaticos/monitorfeedback.js");
                await painelDefinirCanalLogs(interaction);
            }

            if (interaction.customId === 'voltar_monitor_feedback') {
                const { painelMonitorFeedback } = require("../../Eventos/Sistemas Automaticos/monitorfeedback.js");
                await painelMonitorFeedback(interaction, client);
            }

            if (interaction.customId.startsWith('deletar_feedback_')) {
                const parts = interaction.customId.replace('deletar_feedback_', '').split('_');
                const messageId = parts[0];
                const channelId = parts[1];
                
                try {
                    const channel = await interaction.client.channels.fetch(channelId).catch(() => null);
                    
                    if (!channel) {
                        await interaction.reply({ 
                            content: `${Emojis.get('negative')} | Canal não encontrado.`, 
                            ephemeral: true 
                        });
                        
                        const botaoDeletar = new ButtonBuilder()
                            .setCustomId(interaction.customId)
                            .setLabel('Mensagem Apagada Automaticamente')
                            .setEmoji(Emojis.get('_trash_emoji'))
                            .setStyle(4)
                            .setDisabled(true);
                        
                        const rowAtualizada = new ActionRowBuilder().addComponents(botaoDeletar);
                        await interaction.message.edit({ components: [rowAtualizada] }).catch(() => {});
                        return;
                    }
                    
                    const message = await channel.messages.fetch(messageId).catch(() => null);
                    
                    if (message) {
                        await message.delete();
                        await interaction.reply({ 
                            content: `${Emojis.get('checker')} | Mensagem deletada com sucesso!`, 
                            ephemeral: true 
                        });
                        
                        const botaoDeletar = new ButtonBuilder()
                            .setCustomId(interaction.customId)
                            .setLabel('Mensagem Apagada Automaticamente')
                            .setEmoji(Emojis.get('_trash_emoji'))
                            .setStyle(4)
                            .setDisabled(true);
                        
                        const rowAtualizada = new ActionRowBuilder().addComponents(botaoDeletar);
                        await interaction.message.edit({ components: [rowAtualizada] }).catch(() => {});
                    } else {
                        await interaction.reply({ 
                            content: `${Emojis.get('negative')} | Mensagem não encontrada (já foi deletada).`, 
                            ephemeral: true 
                        });
                        
                        const botaoDeletar = new ButtonBuilder()
                            .setCustomId(interaction.customId)
                            .setLabel('Mensagem Apagada Automaticamente')
                            .setEmoji(Emojis.get('_trash_emoji'))
                            .setStyle(4)
                            .setDisabled(true);
                        
                        const rowAtualizada = new ActionRowBuilder().addComponents(botaoDeletar);
                        await interaction.message.edit({ components: [rowAtualizada] }).catch(() => {});
                    }
                } catch (error) {
                    console.error('[MonitorFeedback] Erro ao deletar mensagem:', error);
                    await interaction.reply({ 
                        content: `${Emojis.get('negative')} | Erro ao deletar mensagem.`, 
                        ephemeral: true 
                    }).catch(() => {});
                }
            }

            if (interaction.customId === 'sugestao_config_canal') {
                const { PaginaConfigurarCanal } = require("../../Functions/SistemaSugestoes.js");
                PaginaConfigurarCanal(interaction);
            }

            if (interaction.customId === 'sugestao_config_cargo') {
                const { PaginaConfigurarCargo } = require("../../Functions/SistemaSugestoes.js");
                PaginaConfigurarCargo(interaction);
            }

            if (interaction.customId === 'sugestao_toggle') {
                const { ToggleSugestoes } = require("../../Functions/SistemaSugestoes.js");
                ToggleSugestoes(interaction, client);
            }

            if (interaction.customId === 'sugestao_voltar_painel') {
                const { PainelSistemaSugestoes } = require("../../Functions/SistemaSugestoes.js");
                PainelSistemaSugestoes(interaction, client);
            }

            if (interaction.customId.startsWith('sug_votar_pos_')) {
                const sugestaoId = interaction.customId.replace('sug_votar_pos_', '');
                const { VotarSugestao } = require("../../Functions/SistemaSugestoes.js");
                VotarSugestao(interaction, sugestaoId, 'positivo');
            }

            if (interaction.customId.startsWith('sug_votar_neg_')) {
                const sugestaoId = interaction.customId.replace('sug_votar_neg_', '');
                const { VotarSugestao } = require("../../Functions/SistemaSugestoes.js");
                VotarSugestao(interaction, sugestaoId, 'negativo');
            }

            if (interaction.customId.startsWith('sug_gerenciar_')) {
                const sugestaoId = interaction.customId.replace('sug_gerenciar_', '');
                const { GerenciarSugestao } = require("../../Functions/SistemaSugestoes.js");
                GerenciarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId.startsWith('sug_aprovar_')) {
                const sugestaoId = interaction.customId.replace('sug_aprovar_', '');
                const { AprovarSugestao } = require("../../Functions/SistemaSugestoes.js");
                AprovarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId.startsWith('sug_reprovar_')) {
                const sugestaoId = interaction.customId.replace('sug_reprovar_', '');
                const { ReprovarSugestao } = require("../../Functions/SistemaSugestoes.js");
                ReprovarSugestao(interaction, sugestaoId);
            }

            if (interaction.customId === 'sug_cancelar_gerenciar') {
                await interaction.update({ content: `${Emojis.get('checker')} | Ação cancelada.`, components: [] });
            }

            if (interaction.customId.startsWith('ecloud')) {
                ecloud(interaction, client)
            }

            if (interaction.customId.startsWith('configauth')) {
                configauth(interaction, client)
            }

            if (interaction.customId.startsWith('gerenciarconfigs')) {
                Gerenciar(interaction, client)
            }
            if (interaction.customId.startsWith('configcargos')) {
                ConfigRoles(interaction, client)
            
            }
            if (interaction.customId.startsWith('painelpersonalizar')) {
                const { PainelPersonalizarBot } = require("../../Functions/PersonalizarBot");
                await PainelPersonalizarBot(interaction, client);
            }
            if (interaction.customId.startsWith('painelconfigbv')) {

                msgbemvindo(interaction, client)

            }
            if (interaction.customId.startsWith('gerenciarperm')) {
            GerenciarPermsADM(interaction, client);
            }
            if (interaction.customId.startsWith('systemsugestao')) {
            SistemaSugestao(interaction, client);
            }

            if (interaction.customId === 'stock_definir_canal') {
                const { PaginaDefinirCanalStock } = require("../../Functions/PainelSolicitarStock.js");
                PaginaDefinirCanalStock(interaction);
            }

            if (interaction.customId === 'stock_configurar_embed') {
                const { PaginaConfigurarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                PaginaConfigurarEmbed(interaction, client);
            }

            if (interaction.customId === 'stock_enviar') {
                const { PaginaEscolherCanalPostar } = require("../../Functions/PainelSolicitarStock.js");
                PaginaEscolherCanalPostar(interaction);
            }

            if (interaction.customId === 'stock_resetar') {
                const { ResetarConfiguracoes } = require("../../Functions/PainelSolicitarStock.js");
                ResetarConfiguracoes(interaction, client);
            }

            if (interaction.customId === 'stock_visualizar') {
                const { VisualizarEmbed } = require("../../Functions/PainelSolicitarStock.js");
                VisualizarEmbed(interaction);
            }

            if (interaction.customId === 'stock_voltar_painel') {
                const { PainelSolicitarStock } = require("../../Functions/PainelSolicitarStock.js");
                PainelSolicitarStock(interaction, client);
            }

            if (interaction.customId === 'solicitar_estoque_btn') {
                const { ModalSolicitarEstoque } = require("../../Functions/PainelSolicitarStock.js");
                ModalSolicitarEstoque(interaction);
            }

            if (interaction.customId.startsWith('voltar3')) {

                Gerenciar2(interaction, client)

            }

            if (interaction.customId.startsWith('voltar_painel_vendas')) {

                Gerenciar2(interaction, client)

            }
            if (interaction.customId.startsWith('automaticRepostar')) {

                AcoesRepostAutomatics(interaction, client)

            }
            if (interaction.customId.startsWith('voltar00')) {

                Painel(interaction, client)

            }

            if (interaction.customId === 'voltarilusioncloud' || interaction.customId === 'voltar_ilusioncloud') {
                const { PainelIlusionCloud } = require("../../Functions/IlusionCloud");
                PainelIlusionCloud(interaction, client);
            }

            if (interaction.customId === 'voltarextensoes') {
                PainelExtensoes(interaction, client);
            }

            if (interaction.customId === 'backup_manual') {
                const { SincronizarDados } = require('../../Functions/SincronizarDados');
                const { BackupStorage } = require('../../DataBaseJson');
                
                await interaction.reply({
                    content: `${Emojis.get('loading')} **Iniciando backup manual...**\n\nPor favor, aguarde enquanto salvamos todos os dados do servidor.`,
                    flags: [64]
                });

                try {
                    await SincronizarDados(client);
                    
                    const guildId = interaction.guild.id;
                    const backupInfo = BackupStorage.get(`BackupInfo_${guildId}`) || {};
                    backupInfo.lastBackup = Date.now();
                    
                    if (backupInfo.autoBackupEnabled) {
                        backupInfo.nextBackup = Date.now() + (backupInfo.intervalMinutes * 60 * 1000);
                    }
                    
                    BackupStorage.set(`BackupInfo_${guildId}`, backupInfo);

                    await interaction.editReply({
                        content: `${Emojis.get('_check_emoji')} **Backup realizado com sucesso!**\n\nTodos os dados do servidor foram salvos com segurança.`
                    });

                    setTimeout(() => {
                        const { PainelBackupSystem } = require('../../Functions/BackupSystem');
                        PainelBackupSystem(interaction, client);
                    }, 2000);
                } catch (error) {
                    console.error('Erro ao fazer backup:', error);
                    await interaction.editReply({
                        content: `${Emojis.get('_x_emoji')} **Erro ao realizar backup**\n\nOcorreu um erro ao salvar os dados. Tente novamente.`
                    });
                }
            }

            if (interaction.customId === 'backup_restore') {
                const { BackupStorage } = require('../../DataBaseJson');
                const fs = require('fs');
                const path = require('path');
                
                const configPath = path.join(__dirname, '../../config.json');
                const configData = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                
                if (interaction.user.id !== configData.owner) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} Apenas o Titular da compra pode restaurar o servidor\n-# isso é uma medida de Segurança!!!`,
                        flags: [64]
                    });
                }
                
                const allBackups = BackupStorage.fetchAll();
                const backupOptions = [];
                
                for (const backup of allBackups) {
                    if (backup.ID.startsWith('Backup_') && !backup.ID.startsWith('BackupInfo_')) {
                        const guildId = backup.ID.replace('Backup_', '');
                        const backupData = backup.data;
                        
                        if (backupData && backupData.length > 0) {
                            const data = backupData[0];
                            const backupInfo = BackupStorage.get(`BackupInfo_${guildId}`) || {};
                            
                            const backupDate = backupInfo.lastBackup 
                                ? new Date(backupInfo.lastBackup).toLocaleString('pt-BR', {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                })
                                : 'Data desconhecida';
                            
                            const serverName = data.name || 'Servidor Desconhecido';
                            const isCurrentServer = guildId === interaction.guild.id;
                            
                            backupOptions.push({
                                label: `${serverName}${isCurrentServer ? ' (Servidor Atual)' : ''}`,
                                description: `Backup de ${backupDate} • ${data.channels?.length || 0} canais`,
                                value: `backup_${guildId}`,
                                emoji: isCurrentServer ? '1472812384539115601' : '1472812384539115601'
                            });
                        }
                    }
                }
                
                if (backupOptions.length === 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} **Nenhum backup encontrado!**\n\nVocê precisa fazer um backup antes de poder restaurar.`,
                        flags: [64]
                    });
                }
                
                backupOptions.sort((a, b) => {
                    if (a.emoji === '🟢') return -1;
                    if (b.emoji === '🟢') return 1;
                    return 0;
                });

                const botMember = interaction.guild.members.me;
                const highestRole = interaction.guild.roles.highest;
                
                if (botMember.roles.highest.position < highestRole.position - 1) {
                    return interaction.reply({
                        content: `${Emojis.get('negative')} **Permissão Insuficiente!**\nO cargo do bot precisa ser o mais alto do servidor para realizar a restauração completa.`,
                        flags: [64]
                    });
                }

                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('backup_restore_select')
                    .setPlaceholder('Selecione um backup para restaurar')
                    .addOptions(backupOptions);

                const row = new ActionRowBuilder().addComponents(selectMenu);

                await interaction.reply({
                    content: `# Selecione o Backup para Restaurar
**Atenção:** Esta ação irá deletar e recriar todo o servidor conforme o backup selecionado.
-# Você pode restaurar backups de outros servidores neste servidor.`,
                    components: [row],
                    flags: [64]
                });
            }

            if (interaction.customId === 'backup_restore_select') {
                const fs = require('fs');
                const path = require('path');
                const { BackupStorage } = require('../../DataBaseJson');
                
                const configPath = path.join(__dirname, '../../config.json');
                const configData = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                
                if (interaction.user.id !== configData.owner) {
                    return interaction.update({
                        content: `${Emojis.get('negative')} Apenas o Titular da compra pode restaurar o servidor\n-# isso é uma medida de Segurança!!!`,
                        components: []
                    });
                }
                
                const selectedBackup = interaction.values[0];
                const guildId = selectedBackup.replace('backup_', '');
                
                const backupData = BackupStorage.get(`Backup_${guildId}`);
                const backupInfo = BackupStorage.get(`BackupInfo_${guildId}`) || {};
                
                if (!backupData || backupData.length === 0) {
                    return interaction.update({
                        content: `${Emojis.get('negative')} **Erro!** Backup não encontrado.`,
                        components: []
                    });
                }
                
                const data = backupData[0];
                const backupDate = backupInfo.lastBackup 
                    ? new Date(backupInfo.lastBackup).toLocaleString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    })
                    : 'Data desconhecida';
                
                const isCurrentServer = guildId === interaction.guild.id;
                const serverName = data.name || 'Servidor Desconhecido';

                const confirmButton = new ButtonBuilder()
                    .setCustomId(`backup_restore_confirm_${guildId}`)
                    .setLabel('Confirmar Restauração')
                    .setStyle(4);

                const cancelButton = new ButtonBuilder()
                    .setCustomId('backup_restore_cancel')
                    .setLabel('Cancelar')
                    .setStyle(2);

                const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

                await interaction.update({
                    content: `# Confirmação de Restauração

**Backup Selecionado:** ${serverName}
**Data do Backup:** ${backupDate}
**Origem:** ${isCurrentServer ? 'Servidor Atual' : 'Outro Servidor'}

**Conteúdo do Backup:**
- Canais: ${data.channels?.length || 0}
- Cargos: ${data.roles?.length || 0}
- Emojis: ${data.emojis?.length || 0}
- Stickers: ${data.stickers?.length || 0}

⚠️ **Esta ação é IRREVERSÍVEL!**
Todos os canais, cargos, emojis e stickers atuais serão deletados e recriados conforme o backup.

-# Você receberá atualizações do processo na sua DM.`,
                    components: [row]
                });
            }

            if (interaction.customId.startsWith('backup_restore_confirm_')) {
                const fs = require('fs');
                const path = require('path');
                
                const configPath = path.join(__dirname, '../../config.json');
                const configData = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                
                if (interaction.user.id !== configData.owner) {
                    return interaction.update({
                        content: `${Emojis.get('negative')} Apenas o Titular da compra pode restaurar o servidor\n-# isso é uma medida de Segurança!!!`,
                        components: []
                    });
                }
                
                const guildId = interaction.customId.replace('backup_restore_confirm_', '');
                const { BackupStorage } = require('../../DataBaseJson');
                const { RestaurarBackup } = require('../../Functions/RestaurarBackup');

                const backupData = BackupStorage.get(`Backup_${guildId}`);

                if (!backupData) {
                    return interaction.update({
                        content: `${Emojis.get('negative')} **Erro!** Backup não encontrado.`,
                        components: []
                    });
                }

                await interaction.update({
                    content: `${Emojis.get('loading')} **Iniciando Restauração...**\n\nVerifique sua DM para acompanhar o progresso.`,
                    components: []
                });

                RestaurarBackup(interaction.guild, backupData, interaction.user);
            }

            if (interaction.customId === 'backup_restore_cancel') {
                await interaction.update({
                    content: `${Emojis.get('checker')} **Restauração Cancelada**\n\nNenhuma alteração foi feita no servidor.`,
                    components: []
                });
            }

            if (interaction.customId.startsWith('painelconfigvendas')) {


              Gerenciar2(interaction, client)
           }

            if (interaction.customId === 'painelextensoes') {
              PainelExtensoes(interaction, client);
           }

            if (interaction.customId === 'sistemamoderacao') {
              interaction.reply({ 
                content: `🛡️ **Sistema de Moderação** está em desenvolvimento!\n\n> Em breve você terá acesso a ferramentas de moderação avançadas para seu servidor.`, 
                ephemeral: true 
              });
           }

            if (interaction.customId === 'painelpermissions') {
              PainelPermissions(interaction, client);
           }

            if (interaction.customId === 'adicionar_perm') {
              ModalAdicionarPerm(interaction);
           }

            if (interaction.customId === 'remover_perm') {
              ModalRemoverPerm(interaction);
           }

            if (interaction.customId === 'resetar_perms') {
              HandleResetarPerms(interaction, client);
           }

            if (interaction.customId.startsWith('sistemasorteios')) {
              PainelSorteios(interaction, client);
           }

            if (interaction.customId === 'criar_sorteio') {
              ModalCriarSorteio(interaction);
           }

            if (interaction.customId === 'gerenciar_sorteios') {
              PaginaGerenciarSorteios(interaction, client);
           }

            if (interaction.customId.startsWith('gerenciar_sorteio_')) {
              const sorteioId = interaction.customId.replace('gerenciar_sorteio_', '');
              PaginaGerenciarSorteioEspecifico(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('gerenciar_forcar_')) {
              const sorteioId = interaction.customId.replace('gerenciar_forcar_', '');
              PaginaConfirmarForcarFinalizacao(interaction, sorteioId);
           }

            if (interaction.customId.startsWith('confirmar_forcar_')) {
              const sorteioId = interaction.customId.replace('confirmar_forcar_', '');
              forcarFinalizacao(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('gerenciar_addtempo_')) {
              const sorteioId = interaction.customId.replace('gerenciar_addtempo_', '');
              ModalAdicionarTempo(interaction, sorteioId);
           }


            if (interaction.customId === 'configuracoesavancadas') {
              const { PainelConfigAvancadas } = require("../../Functions/ConfigAvancadas.js");
              PainelConfigAvancadas(interaction);
           }

            if (interaction.customId === 'config_termos') {
              const { ConfigurarTermos } = require("../../Functions/ConfigAvancadas.js");
              ConfigurarTermos(interaction);
           }

            if (interaction.customId === 'config_botao_duvidas') {
              const { ConfigurarBotaoDuvidas } = require("../../Functions/ConfigAvancadas.js");
              ConfigurarBotaoDuvidas(interaction);
           }

            if (interaction.customId === 'painel_botao_duvidas') {
              const { PainelBotaoDuvidas } = require("../../Functions/ConfigAvancadas.js");
              PainelBotaoDuvidas(interaction);
           }

            if (interaction.customId === 'painel_termos_loja') {
              const { PainelTermosLoja } = require("../../Functions/ConfigAvancadas.js");
              PainelTermosLoja(interaction);
           }

            if (interaction.customId === 'limpar_termos') {
              const { LimparTermos } = require("../../Functions/ConfigAvancadas.js");
              LimparTermos(interaction);
           }

            if (interaction.customId === 'toggle_botao_duvidas') {
              const { ToggleBotaoDuvidas } = require("../../Functions/ConfigAvancadas.js");
              ToggleBotaoDuvidas(interaction);
           }

            if (interaction.customId === 'config_status_comercio') {
              const { ConfigurarStatusComercio } = require("../../Functions/ConfigAvancadas.js");
              ConfigurarStatusComercio(interaction);
           }

            if (interaction.customId.startsWith('alterar_status_')) {
              const novoStatus = interaction.customId.replace('alterar_status_', '');
              const { AlterarStatusComercio } = require("../../Functions/ConfigAvancadas.js");
              AlterarStatusComercio(interaction, novoStatus);
           }

            if (interaction.customId.startsWith('gerenciar_descontinuar_')) {
              const sorteioId = interaction.customId.replace('gerenciar_descontinuar_', '');
              PaginaConfirmarDescontinuar(interaction, sorteioId);
           }

            if (interaction.customId.startsWith('confirmar_descontinuar_')) {
              const sorteioId = interaction.customId.replace('confirmar_descontinuar_', '');
              descontinuarSorteio(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('gerenciar_verparticipantes_')) {
              const sorteioId = interaction.customId.replace('gerenciar_verparticipantes_', '');
              gerarListaParticipantes(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('sorteio_tempo_manual_')) {
              const sorteioId = interaction.customId.replace('sorteio_tempo_manual_', '');
              ModalTempoPersonalizado(interaction, sorteioId);
           }

            if (interaction.customId.startsWith('sorteio_voltar_tempo_')) {
              const sorteioId = interaction.customId.replace('sorteio_voltar_tempo_', '');
              PaginaSetarTempo(interaction, sorteioId);
           }

            if (interaction.customId.startsWith('sorteio_voltar_canal_')) {
              const sorteioId = interaction.customId.replace('sorteio_voltar_canal_', '');
              PaginaEscolherCanal(interaction, sorteioId);
           }

            if (interaction.customId.startsWith('sorteio_finalizar_')) {
              const sorteioId = interaction.customId.replace('sorteio_finalizar_', '');
              EnviarMensagemSorteio(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('sorteio_participar_')) {
              const sorteioId = interaction.customId.replace('sorteio_participar_', '');
              const sorteioData = sorteios.get(sorteioId);

              if (!sorteioData || sorteioData.status !== "ativo") {
                return interaction.reply({ content: `${Emojis.get('negative')} | Este sorteio não está mais ativo!`, ephemeral: true });
              }

              const userId = interaction.user.id;
              const participantes = sorteioData.participantes || [];

              if (sorteioData.cargosPermitidos && sorteioData.cargosPermitidos.length > 0) {
                const temCargoPermitido = sorteioData.cargosPermitidos.some(cargoId => 
                  interaction.member.roles.cache.has(cargoId)
                );
                if (!temCargoPermitido) {
                  return interaction.reply({ content: `${Emojis.get('negative')} | Você não possui os cargos necessários para participar!`, ephemeral: true });
                }
              }

              if (sorteioData.cargosBloqueados && sorteioData.cargosBloqueados.length > 0) {
                const temCargoBloqueado = sorteioData.cargosBloqueados.some(cargoId => 
                  interaction.member.roles.cache.has(cargoId)
                );
                if (temCargoBloqueado) {
                  return interaction.reply({ content: `${Emojis.get('negative')} | Você possui um cargo que não pode participar deste sorteio!`, ephemeral: true });
                }
              }

              if (participantes.includes(userId)) {
                return interaction.reply({ content: `${Emojis.get('negative')} | Você já está participando deste sorteio!`, ephemeral: true });
              }

              participantes.push(userId);
              sorteios.set(`${sorteioId}.participantes`, participantes);

              await atualizarEmbedSorteio(sorteioId, client);

              interaction.reply({ content: `${Emojis.get('checker')} | Você está participando do sorteio **${sorteioData.titulo}**! 🎉`, ephemeral: true });
           }

            if (interaction.customId.startsWith('sorteio_reroll_')) {
              const sorteioId = interaction.customId.replace('sorteio_reroll_', '');
              await rerollSorteio(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('sorteio_lista_')) {
              const sorteioId = interaction.customId.replace('sorteio_lista_', '');
              await gerarListaParticipantes(interaction, sorteioId, client);
           }

            if (interaction.customId.startsWith('sorteio_cancelar_')) {
              const sorteioId = interaction.customId.replace('sorteio_cancelar_', '');
              sorteios.delete(sorteioId);
              PainelSorteios(interaction, client);
           }

            if (interaction.customId === 'voltaraparencia') {
                const { Painel } = require("../../Functions/Painel");
                await Painel(interaction, client);
            }

            if (interaction.customId === 'voltar_personalizar_cores') {
                const { PainelPersonalizarBot } = require("../../Functions/PersonalizarBot");
                await PainelPersonalizarBot(interaction, client);
            }

            if (interaction.customId === 'personalizar_select_menu') {
                const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder } = require("discord.js");
                const selectedOption = interaction.values[0];

                if (selectedOption === 'alterar_nome') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_alterar_nome')
                        .setTitle('Alterar Nome do Bot');

                    const inputNome = new TextInputBuilder()
                        .setCustomId('novo_nome')
                        .setLabel('Novo Nome do Bot')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Digite o novo nome do bot')
                        .setValue(client.user.username)
                        .setRequired(true)
                        .setMaxLength(32)
                        .setMinLength(2);

                    modal.addComponents(new ActionRowBuilder().addComponents(inputNome));
                    await interaction.showModal(modal);
                }

                if (selectedOption === 'alterar_avatar') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_alterar_avatar')
                        .setTitle('Alterar Avatar do Bot');

                    const inputAvatar = new TextInputBuilder()
                        .setCustomId('novo_avatar')
                        .setLabel('URL do Novo Avatar')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Cole a URL da imagem aqui')
                        .setRequired(true);

                    modal.addComponents(new ActionRowBuilder().addComponents(inputAvatar));
                    await interaction.showModal(modal);
                }

                if (selectedOption === 'alterar_status') {
                    const modal = new ModalBuilder()
                        .setCustomId('modal_alterar_status')
                        .setTitle('Alterar Status do Bot');

                    const inputStatus = new TextInputBuilder()
                        .setCustomId('novo_status')
                        .setLabel('Novo Status do Bot')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('Digite o novo status')
                        .setValue(client.user.presence?.activities[0]?.name || '')
                        .setRequired(true)
                        .setMaxLength(128);

                    modal.addComponents(new ActionRowBuilder().addComponents(inputStatus));
                    await interaction.showModal(modal);
                }

                if (selectedOption === 'editar_cores') {
                    const { obterEmoji } = require("../../Handler/EmojiFunctions");
                    const { EmbedBuilder } = require("discord.js");
                    
                    const embed = new EmbedBuilder()
                        .setTitle(`${await obterEmoji(28)} Editar Cores dos Embeds`)
                        .setDescription(`> Configure as cores das embeds do seu bot.`)
                        .setColor("#2b2d31");

                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId("coresembeds")
                                .setLabel('Configurar Cores')
                                .setEmoji('🎨')
                                .setStyle(1),
                            new ButtonBuilder()
                                .setCustomId("voltar_personalizar_cores")
                                .setLabel('Voltar')
                                .setEmoji(await obterEmoji(11))
                                .setStyle(2)
                        );

                    await interaction.update({ embeds: [embed], components: [row], ephemeral: true });
                }
            }

            if (interaction.customId === 'modal_alterar_nome') {
                const novoNome = interaction.fields.getTextInputValue('novo_nome');
                
                try {
                    await client.user.setUsername(novoNome);
                    await interaction.reply({ content: `✅ Nome do bot alterado com sucesso para: **${novoNome}**\n\n*Atualizando painel...*`, ephemeral: true });
                } catch (error) {
                    await interaction.reply({ 
                        content: `❌ Erro ao alterar o nome do bot. Você só pode alterar o nome 2 vezes por hora.\n\nErro: ${error.message}`, 
                        ephemeral: true 
                    });
                }
            }

            if (interaction.customId === 'modal_alterar_avatar') {
                const novoAvatar = interaction.fields.getTextInputValue('novo_avatar');
                
                try {
                    await client.user.setAvatar(novoAvatar);
                    await interaction.reply({ content: `✅ Avatar do bot alterado com sucesso!\n\n*Atualizando painel...*`, ephemeral: true });
                } catch (error) {
                    await interaction.reply({ 
                        content: `❌ Erro ao alterar o avatar do bot. Verifique se a URL é válida.\n\nErro: ${error.message}`, 
                        ephemeral: true 
                    });
                }
            }

            if (interaction.customId === 'modal_alterar_status') {
                const novoStatus = interaction.fields.getTextInputValue('novo_status');
                
                try {
                    await client.user.setActivity(novoStatus, { type: 0 });
                    await interaction.reply({ content: `✅ Status do bot alterado com sucesso para: **${novoStatus}**\n\n*Atualizando painel...*`, ephemeral: true });
                } catch (error) {
                    await interaction.reply({ 
                        content: `❌ Erro ao alterar o status do bot.\n\nErro: ${error.message}`, 
                        ephemeral: true 
                    });
                }
            }
        }
}