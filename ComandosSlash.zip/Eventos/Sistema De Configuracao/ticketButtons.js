const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const { configuracao } = require("../../DataBaseJson");
const emojis = require("../../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        if (!interaction.isButton()) return;

        const customId = interaction.customId;

        if (customId.startsWith('chamar_suporte_humano_')) {
            const { atendimentosAI } = require("../../DataBaseJson");
            
            const channelId = customId.replace('chamar_suporte_humano_', '');
            
            try {
                await interaction.deferReply({ ephemeral: true });
                
                const guild = interaction.guild;
                const cargoSup = configuracao.get("ConfigRoles.cargosup");
                const cargoAdm = configuracao.get("ConfigRoles.cargoadm");
                
                const membrosNotificados = new Set();
                
                const membros = await guild.members.fetch();
                
                for (const [memberId, member] of membros) {
                    if (member.user.bot) continue;
                    
                    let deveNotificar = false;
                    
                    if (cargoSup && member.roles.cache.has(cargoSup)) {
                        deveNotificar = true;
                    }
                    
                    if (cargoAdm && member.roles.cache.has(cargoAdm)) {
                        deveNotificar = true;
                    }
                    
                    if (member.permissions.has("Administrator")) {
                        deveNotificar = true;
                    }
                    
                    if (deveNotificar && !membrosNotificados.has(memberId)) {
                        try {
                            const rowIrTicket = new ActionRowBuilder().addComponents(
                                new ButtonBuilder()
                                    .setLabel('Ir para o Ticket')
                                    .setEmoji('🎫')
                                    .setStyle(5)
                                    .setURL(`https://discord.com/channels/${guild.id}/${channelId}`)
                            );

                            await member.send({
                                content: `# 🆘 ${guild.name} - Suporte Humano Solicitado

**Usuário:** ${interaction.user} (${interaction.user.tag})
**Ticket:** <#${channelId}>
**Solicitado via:** Botão de Suporte

📌 **Ação Necessária:** Clique no botão abaixo para ir direto ao ticket e assumir o atendimento.`,
                                components: [rowIrTicket]
                            });
                            membrosNotificados.add(memberId);
                        } catch (dmError) {
                        }
                    }
                }
                
                atendimentosAI.set(`${channelId}.suporteHumanoSolicitado`, {
                    timestamp: Date.now(),
                    userId: interaction.user.id,
                    userTag: interaction.user.tag,
                    mensagem: 'Solicitado via botão',
                    membrosNotificados: membrosNotificados.size
                });
                
                await interaction.editReply({
                    content: `${Emojis.get('checker') || '✅'} Suporte humano notificado! ${membrosNotificados.size} membro(s) da equipe foram alertados.`,
                    ephemeral: true
                });
                
                await interaction.message.edit({
                    components: interaction.message.components.map(row => ({
                        ...row,
                        components: row.components.map(btn => ({
                            ...btn.toJSON(),
                            disabled: true
                        }))
                    }))
                });
                
            } catch (error) {
                await interaction.editReply({
                    content: `${Emojis.get('negative') || '❌'} Erro ao notificar o suporte. Tente novamente.`,
                    ephemeral: true
                });
            }
            return;
        }

        const botoesGerenciamento = ['ticket_notificar_', 'ticket_deletar_', 'ticket_renomear_'];
        const isGerenciamentoButton = botoesGerenciamento.some(prefix => customId.startsWith(prefix));
        
        if (!isGerenciamentoButton) return;

        const [, action, ...rest] = customId.split('_');
        const threadId = rest[rest.length - 1];

        const cargoSup = configuracao.get('ConfigRoles.cargosup');
        const cargoAdm = configuracao.get('ConfigRoles.cargoadm');

        const hasPermission = interaction.member.roles.cache.has(cargoSup) || 
                            interaction.member.roles.cache.has(cargoAdm) ||
                            interaction.member.permissions.has('Administrator');

        if (!hasPermission) {
            return interaction.reply({
                content: `${Emojis.get('negative') || '❌'} | Opa, opa! Parece que você não tem permissão para mexer nisso.`,
                ephemeral: true
            });
        }

        if (action === 'notificar') {
            try {
                await interaction.deferReply({ ephemeral: true });

                const { atendimentosAI } = require("../../DataBaseJson");
                
                const ticketData = atendimentosAI.get(threadId);
                
                if (!ticketData || !ticketData.dono) {
                    return interaction.editReply({
                        content: `${Emojis.get('negative') || '❌'} | Não foi possível encontrar o dono do ticket no banco de dados.`
                    });
                }

                const ticketOwner = await client.users.fetch(ticketData.dono).catch(() => null);

                if (!ticketOwner) {
                    return interaction.editReply({
                        content: `${Emojis.get('negative') || '❌'} | Não foi possível encontrar o usuário dono do ticket.`
                    });
                }

                try {
                    const dmContent = `Olá! Um membro da equipe está te chamando no seu ticket.Se você demorar para responder ou não responder, há chances do ticket ser excluído sem aviso prévio.`;

                    const buttonRow = new ActionRowBuilder().addComponents(
                        new (require('discord.js').ButtonBuilder)()
                            .setURL(`https://discord.com/channels/${interaction.guild.id}/${threadId}`)
                            .setLabel('Ir para o Ticket')
                            .setStyle(5)
                    );

                    await ticketOwner.send({ 
                        content: dmContent,
                        components: [buttonRow]
                    });

                    await interaction.editReply({
                        content: `${Emojis.get('checker') || '✅'} | Notificação enviada com sucesso para ${ticketOwner}!`
                    });
                } catch (dmError) {
                    await interaction.editReply({
                        content: `${Emojis.get('negative') || '❌'} | Não foi possível enviar a DM para o usuário. Ele pode estar com DMs desativadas.`
                    });
                }
            } catch (error) {
                console.error('[ERRO NOTIFICAR TICKET]', error);
                if (interaction.deferred) {
                    await interaction.editReply({
                        content: `${Emojis.get('negative') || '❌'} | Erro ao notificar usuário: ${error.message}`
                    });
                }
            }
        }

        if (action === 'renomear') {
            try {
                const modal = new ModalBuilder()
                    .setCustomId(`ticket_rename_modal_${threadId}`)
                    .setTitle('Renomear Ticket');

                const nomeInput = new TextInputBuilder()
                    .setCustomId('novo_nome')
                    .setLabel('Novo nome do ticket')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('Digite o novo nome do ticket')
                    .setRequired(true)
                    .setMaxLength(100);

                const row = new ActionRowBuilder().addComponents(nomeInput);
                modal.addComponents(row);

                await interaction.showModal(modal);
            } catch (error) {
                console.error('[ERRO RENOMEAR TICKET]', error);
            }
        }

        if (action === 'deletar' && customId.includes('salvar')) {
            try {
                await interaction.deferReply({ ephemeral: true });

                const thread = interaction.channel;
                
                let allMessages = [];
                let lastId;

                while (true) {
                    const options = { limit: 100 };
                    if (lastId) options.before = lastId;

                    const messages = await thread.messages.fetch(options);
                    if (messages.size === 0) break;

                    allMessages.push(...messages.values());
                    lastId = messages.last().id;

                    if (messages.size < 100) break;
                }

                allMessages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

                let transcript = `═══════════════════════════════════════════════════\n`;
                transcript += `           TRANSCRIÇÃO DO TICKET\n`;
                transcript += `═══════════════════════════════════════════════════\n\n`;
                transcript += `Ticket: ${thread.name}\n`;
                transcript += `Criado em: ${new Date(thread.createdTimestamp).toLocaleString('pt-BR')}\n`;
                transcript += `Fechado por: ${interaction.user.tag}\n`;
                transcript += `Fechado em: ${new Date().toLocaleString('pt-BR')}\n`;
                transcript += `Total de mensagens: ${allMessages.length}\n\n`;
                transcript += `═══════════════════════════════════════════════════\n\n`;

                for (const msg of allMessages) {
                    const timestamp = new Date(msg.createdTimestamp).toLocaleString('pt-BR');
                    transcript += `[${timestamp}] ${msg.author.tag} (${msg.author.id})\n`;
                    
                    if (msg.content) {
                        transcript += `${msg.content}\n`;
                    }
                    
                    if (msg.embeds.length > 0) {
                        transcript += `[Embed: ${msg.embeds.length} embed(s)]\n`;
                    }
                    
                    if (msg.attachments.size > 0) {
                        transcript += `[Anexos: ${msg.attachments.map(a => a.url).join(', ')}]\n`;
                    }
                    
                    transcript += `\n`;
                }

                transcript += `═══════════════════════════════════════════════════\n`;
                transcript += `              FIM DA TRANSCRIÇÃO\n`;
                transcript += `═══════════════════════════════════════════════════\n`;

                const buffer = Buffer.from(transcript, 'utf-8');
                const attachment = new AttachmentBuilder(buffer, { 
                    name: `ticket-${thread.id}.txt` 
                });

                const logsChannel = configuracao.get('ConfigChannels.logsticket');
                
                if (logsChannel) {
                    const channel = await client.channels.fetch(logsChannel).catch(() => null);
                    
                    if (channel) {
                        const logEmbed = new EmbedBuilder()
                            .setTitle(`${Emojis.get('ticket') || '🎫'} Ticket Fechado`)
                            .setDescription(`**Ticket:** ${thread.name}\n**Fechado por:** ${interaction.user}\n**Data:** ${new Date().toLocaleString('pt-BR')}`)
                            .setColor('#ff0000')
                            .setTimestamp();

                        await channel.send({
                            embeds: [logEmbed],
                            files: [attachment]
                        });
                    }
                }

                await interaction.editReply({
                    content: `${Emojis.get('checker') || '✅'} | Ticket salvo com sucesso! Deletando em 3 segundos...`
                });

                setTimeout(async () => {
                    try {
                        await thread.delete();
                    } catch (error) {
                        console.error('[ERRO DELETAR THREAD]', error);
                    }
                }, 3000);

            } catch (error) {
                console.error('[ERRO DELETAR E SALVAR TICKET]', error);
                if (interaction.deferred) {
                    await interaction.editReply({
                        content: `${Emojis.get('negative') || '❌'} | Erro ao salvar e deletar ticket: ${error.message}`
                    });
                }
            }
        }
    }
};
