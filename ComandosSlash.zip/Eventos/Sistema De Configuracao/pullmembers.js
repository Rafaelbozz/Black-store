const { ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, InteractionType, ButtonBuilder, ButtonStyle, EmbedBuilder } = require("discord.js");
const axios = require("axios");
const fs = require('fs');
const path = require('path');
const { Emojis } = require("../../DataBaseJson/index");

const API_URL = "https://ryzenecloud.squareweb.app/";
const AUTH_TOKEN = "galaodamassa581";
const dbPathAuth = path.join(__dirname, "..", "..", "DataBaseJson", "configauth02api.json");

module.exports = {
    name: 'interactionCreate',

    async run(interaction, client) {
        if (interaction.isButton() && interaction.customId === 'recuperarmembroauth') {
            const modal = new ModalBuilder()
                .setCustomId('modal_pull_members')
                .setTitle('🔄 Recuperar Membros');

            const inputGuild = new TextInputBuilder()
                .setCustomId('guild_id_input')
                .setLabel('ID DO SERVIDOR DESTINO')
                .setPlaceholder('Ex: 123456789012345678')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const inputQtd = new TextInputBuilder()
                .setCustomId('qtd_input')
                .setLabel('QUANTIDADE DE MEMBROS')
                .setPlaceholder('Ex: 50')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(inputGuild),
                new ActionRowBuilder().addComponents(inputQtd)
            );

            return await interaction.showModal(modal);
        }

        if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'modal_pull_members') {
            await interaction.deferReply({ ephemeral: true });

            const guildId = interaction.fields.getTextInputValue('guild_id_input').trim();
            const quantidade = parseInt(interaction.fields.getTextInputValue('qtd_input').trim());

            if (isNaN(quantidade) || quantidade <= 0) {
                return interaction.editReply(`${Emojis.get('negative')} Informe uma quantidade válida!`);
            }

            try {
                if (!fs.existsSync(dbPathAuth)) {
                    return interaction.editReply("❌ Erro: Configuração do Bot Auth02 não encontrada!");
                }
                
                const config = JSON.parse(fs.readFileSync(dbPathAuth, 'utf-8'));

                if (!config.token) {
                    return interaction.editReply("❌ Erro: Token do Bot Auth02 não configurado!");
                }

                try {
                    const { Client, GatewayIntentBits } = require('discord.js');
                    
                    const authBot = new Client({
                        intents: [GatewayIntentBits.Guilds]
                    });

                    await authBot.login(config.token);

                    await new Promise((resolve) => {
                        authBot.once('ready', resolve);
                    });

                    const guildDestino = authBot.guilds.cache.get(guildId);
                    
                    if (!guildDestino) {
                        await authBot.destroy();
                        
                        const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${config.bot_id}&permissions=8&scope=bot%20applications.commands`;
                        const rowInvite = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setLabel('Adicionar Bot Auth02 ao Servidor')
                                .setStyle(ButtonStyle.Link)
                                .setURL(inviteUrl)
                        );
                        return interaction.editReply({
                            content: `${Emojis.get('negative')} **Bot Auth02 não encontrado!**\n> O bot Auth02 precisa estar no servidor destino (\`${guildId}\`) para realizar a puxada.`,
                            components: [rowInvite]
                        });
                    }

                    await authBot.destroy();

                } catch (checkErr) {
                    console.error("Erro ao verificar presença do bot:", checkErr.message);
                    return interaction.editReply(`${Emojis.get('negative')} Erro ao verificar se o Bot Auth02 está no servidor destino. Verifique se o token está correto e se o ID do servidor está válido.`);
                }

                const infoRes = await axios.get(`${API_URL}/api/auth02/info/${config.bot_id}`, {
                    headers: { 'Authorization': AUTH_TOKEN }
                });

                const membrosDisponiveis = infoRes.data.membros || 0;

                if (quantidade > membrosDisponiveis) {
                    return interaction.editReply(`${Emojis.get('negative')} Você tentou puxar \`${quantidade}\` membros, mas seu bot possui apenas \`${membrosDisponiveis}\` verificados na database.`);
                }

                const pullRes = await axios.post(`${API_URL}/api/auth02/pull`, {
                    bot_id: String(config.bot_id).trim(),
                    guild_id: String(guildId).trim(),
                    quantidade: quantidade
                }, {
                    headers: { 'Authorization': AUTH_TOKEN }
                });

                if (pullRes.data.sucesso) {
                    const pedidoId = pullRes.data.pedido_id;
                    const estimativaSegundos = pullRes.data.estimativa_segundos || 0;
                    
                    const timestampEstimado = Math.floor(Date.now() / 1000) + estimativaSegundos;
                    
                    await interaction.editReply(
                        `${Emojis.get('loading')} **Puxando Membros, Aguarde...**\n` +
                        `> Estimativa: <t:${timestampEstimado}:R>`
                    );

                    let statusPedido = null;
                    let tentativas = 0;
                    const maxTentativas = Math.ceil(estimativaSegundos / 2) + 30;

                    while (tentativas < maxTentativas) {
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        
                        try {
                            const statusRes = await axios.get(`${API_URL}/api/auth02/pedido/${pedidoId}`);
                            
                            if (statusRes.data.sucesso) {
                                const pedido = statusRes.data.pedido;
                                
                                if (pedido.status === 'concluido' || pedido.status === 'falhou') {
                                    statusPedido = pedido;
                                    break;
                                }
                            }
                        } catch (err) {
                            console.error("Erro ao consultar status:", err.message);
                        }
                        
                        tentativas++;
                    }

                    if (!statusPedido) {
                        return interaction.editReply(
                            `${Emojis.get('negative')} **Timeout:** Não foi possível confirmar a conclusão do pedido.\n` +
                            `> ID do Pedido: \`${pedidoId}\`\n` +
                            `> Consulte o status manualmente.`
                        );
                    }

                    let nomeServidor = guildId;
                    try {
                        const guildDestino = await client.guilds.fetch(guildId);
                        nomeServidor = guildDestino.name;
                    } catch (e) {
                    }

                    const dataPuxada = new Date(statusPedido.concluido_em || Date.now());
                    const dataFormatada = dataPuxada.toLocaleString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });

                    const mensagemFinal = 
                        `# Puxada Finalizada\n` +
                        `- Membros Puxados: \`\`${quantidade}\`\`\n` +
                        `- Status do Pedido: \`\`🟢 Concluído\`\`\n` +
                        `- Membros Adicionados: ${statusPedido.resultados?.sucessos || 0}\n` +
                        `- Membros que já estavam no servidor: ${statusPedido.resultados?.falhas || 0}\n` +
                        `- Data da Puxada: ${dataFormatada}\n` +
                        `-# Sistema OAuth02 - Ryzen SysteM`;

                    return interaction.editReply(mensagemFinal);
                } else {
                    return interaction.editReply(`❌ **Erro na API:** ${pullRes.data.message || "Falha desconhecida"}`);
                }

            } catch (err) {
                console.error("Erro no Interaction Pull:", err.response?.data || err.message);
                
                const apiMessage = err.response?.data?.message || err.message;
                return interaction.editReply(`❌ **Falha no Pull:** \`${apiMessage}\``);
            }
        }
    }
};