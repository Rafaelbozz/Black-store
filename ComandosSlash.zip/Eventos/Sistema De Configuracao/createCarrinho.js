
const Discord = require("discord.js")
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder } = require("discord.js")
const { produtos, carrinhos, configuracao, pagamentos } = require("../../DataBaseJson");
const { QuickDB } = require("quick.db");
const { GerenciarCampos, GerenciarCampos2 } = require("../../Functions/GerenciarCampos");
const { MessageStock } = require("../../Functions/ConfigEstoque.js");
const { MessageCreate } = require("../../Functions/SenderMessagesOrUpdates");
const { VerificaçõesCarrinho, CreateCarrinho } = require("../../Functions/CreateCarrinho");
const { DentroCarrinho1, DentroCarrinho2, DentroCarrinhoPix, DentroCarrinhoEfiBank, DentroCarrinhoMisticPay, DentroCarrinhoImap, DentroCarrinhoCard } = require("../../Functions/DentroCarrinho");
const { VerificarCupom, AplicarCupom } = require("../../Functions/VerificarCupom");
const { getPermissions } = require("../../Functions/PermissionsCache.js");
const db = new QuickDB()
const emojis = require("../../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

function formatarEmoji(emojiData) {
    if (!emojiData || emojiData === "") return { id: '1250848496987406487' }; 
    if (/^\d+$/.test(emojiData)) return { id: emojiData };
    if (emojiData.includes(':')) {
        const id = emojiData.split(':')[2].replace('>', '');
        return { id: id };
    }
    return { name: emojiData };
}



module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {


        if (interaction.type == Discord.InteractionType.ModalSubmit) {

            if (interaction.customId === '2313awdawdawdawdaw123141') {

                let cupom = interaction.fields.getTextInputValue('tokenMP');

                await VerificarCupom(interaction, cupom)



            }


            if (interaction.customId === '2313141') {

                let qtd = interaction.fields.getTextInputValue('tokenMP');



                const ggg = carrinhos.get(interaction.channel.id)


                const hhhh = produtos.get(`${ggg.infos.produto}.Campos`)
                const gggaaa = hhhh.find(campo22 => campo22.Nome === ggg.infos.campo)

                if (isNaN(qtd) || qtd <= 0 || qtd % 1 !== 0) {
                    return interaction.reply({
                        content: `${Emojis.get(`question_emoji`)} A quantidade \`${qtd}\` não é um número inteiro válido ou é menor ou igual a zero, tente novamente.`,
                        ephemeral: true
                    });
                }

                if (qtd > gggaaa.estoque.length) {
                    return interaction.reply({
                        content: `${Emojis.get(`negative`)} A quantidade solicitada de \`${qtd}\` excede o estoque disponível.`,
                        ephemeral: true
                    });
                }


                if (ggg.cupomadicionado !== undefined) {
                    const hhhh = produtos.get(`${ggg.infos.produto}.Cupom`)
                    const gggaaa = hhhh.find(campo22 => campo22.Nome === ggg.cupomadicionado)

                    if (gggaaa.condicoes?.precominimo !== undefined) {

                        if (qtd < gggaaa.condicoes?.precominimo) {
                            return interaction.reply({ content: `${Emojis.get(`negative`)} A quantidade solicitada de \`${qtd}\` não está no valor minimo para utilizar o cupom de \`${gggaaa.condicoes?.precominimo}\`.`, ephemeral: true })
                        }

                        if (qtd > gggaaa.condicoes?.qtdmaxima) {
                            return interaction.reply({ content: `${Emojis.get(`negative`)} A quantidade solicitada de \`${qtd}\` excede o limite para o uso do cupom de \`${gggaaa.condicoes?.precominimo}\`.`, ephemeral: true })
                        }

                    }

                }

                await carrinhos.set(`${interaction.channel.id}.quantidadeselecionada`, qtd)

                DentroCarrinho1(interaction, 1)

            }
        }





        let infos = {}

        if (interaction.isButton()) {

            if (interaction.customId == 'codigocopiaecola') {
                const yy = await carrinhos.get(interaction.channel.id)
                interaction.reply({ content: `${yy.pagamentos.cp}`, ephemeral: true })

            }

            if (interaction.customId == 'codigocopiaecola_gerado') {
                const pag = await pagamentos.get(interaction.channel.id)
                if (pag && pag.pagamentos && pag.pagamentos.cp) {
                    interaction.reply({ content: `${pag.pagamentos.cp}`, ephemeral: true })
                } else {
                    interaction.reply({ content: `${Emojis.get('negative')} Código PIX não encontrado!`, ephemeral: true })
                }
            }

if (interaction.customId == 'pagarpix') {
    const misticStatus = configuracao.get("pagamentos.MisticSystem") || false;
    const imapStatus = configuracao.get("pagamentos.imap.status") || false;
    const efiStatus = configuracao.get("pagamentos.sistema_efi") || false;
    const mpStatus = configuracao.get("pagamentos.MpOnOff") || false;

    if (misticStatus) {
        DentroCarrinhoMisticPay(interaction, client);
    } 
    else if (imapStatus) {
        DentroCarrinhoImap(interaction, client);
    } 
    else if (efiStatus) {
        DentroCarrinhoEfiBank(client, interaction);
    } 
    else if (mpStatus) {
        DentroCarrinhoPix(interaction, 1);
    }
    else {
        interaction.reply({
            content: `${Emojis.get('negative') || '❌'} Nenhum método de pagamento automático está ativado no momento. Entre em contato com o Suporte.`,
            ephemeral: true
        });
        return;
    }
}
          
            if (interaction.customId == 'voltarcarrinho') {
                DentroCarrinho1(interaction, 1)
            }

            if (interaction.customId == 'pagarCard') {
                DentroCarrinhoCard(interaction, client);
            }

            if (interaction.customId == 'irparapagamento') {
                if (configuracao.get(`pagamentos.SemiAutomatico.status`) == true) {
                    interaction.deferUpdate()
                    await interaction.message.edit({ content: `${Emojis.get(`loading`)} Espere um momento...`, components: [], embeds: [] })

                    const pagamento = configuracao.get(`pagamentos.SemiAutomatico`)
                    const yy = await carrinhos.get(interaction.channel.id)

                    const hhhh = produtos.get(`${yy.infos.produto}.Campos`)
                    const gggaaa = hhhh.find(campo22 => campo22.Nome === yy.infos.campo)


                    let valor = 0

                    if (yy.cupomadicionado !== undefined) {
                        const valor2 = gggaaa.valor * yy.quantidadeselecionada

                        const hhhh2 = produtos.get(`${yy.infos.produto}.Cupom`)
                        const gggaaaawdwadwa = hhhh2.find(campo22 => campo22.Nome === yy.cupomadicionado)
                        valor = valor2 * (1 - gggaaaawdwadwa.desconto / 100);
                    } else {
                        valor = gggaaa.valor * yy.quantidadeselecionada
                    }

                    const { QrCodePix } = require('qrcode-pix')

                    const valor2 = Number(valor.toFixed(2))
                    const qrCodePix = QrCodePix({
                        version: '01',
                        key: pagamento.pix,
                        name: pagamento.pix,
                        city: 'BRASILIA',
                        cep: '28360000',
                        value: valor2,
                    });

                    const chavealeatorio = qrCodePix.payload()

                    const { qrGenerator } = require('../../Lib/QRCodeLib.js');
                    const qr = new qrGenerator({ imagePath: './Lib/aaaaa.png' });
                    const qrcode = await qr.generate(chavealeatorio);
                    
                    let attachment = null;
                    if (qrcode.status === 'success' && qrcode.response) {
                        attachment = new AttachmentBuilder(Buffer.from(qrcode.response, "base64"), { name: "payment.png" });
                    }

                    const embed = new EmbedBuilder()
                        .setColor(`${configuracao.get(`Cores.Principal`) == null ? `#2b2d31` : configuracao.get(`Cores.Principal`)}`)
                        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                         .setDescription(`-# ${Emojis.get(`geradosucesso`)} **Ambiente Seguro**\n-# Seu pagamento será processado em um ambiente 100% seguro e protegido.\n\n-# ${Emojis.get(`info`)} **Pagamento Semi Auto**\n-# Assim que o pagamento for confirmado, Envie o Comprovante nesse Canal para o pagamento ser Aprovado!!`)
                        .setTitle(`${Emojis.get(`pix_stamp_emoji`)} Pagamento via PIX criado`)
                        .addFields(
                            { name: `${Emojis.get(`brand_emoji`)} Valor da Compra`, value: `\`R$ ${Number(valor).toFixed(2)}\``, inline: true }
                        )
                        .setFooter(
                            { text: `${interaction.guild.name} - Pagamento expira em 10 minutos.` }
                        )
                        .setTimestamp()

                    if (attachment) {
                        embed.setImage('attachment://payment.png')
                    }

                    const row3 = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId("codigocopiaecolaadwdawd")
                                .setLabel('Código copia e cola')
                                .setEmoji(`1192868868784394381`)
                                .setStyle(2),

                            new ButtonBuilder()
                                .setCustomId("confirmarpagamentomanual")
                                .setLabel('Confirmar pagamento')
                                .setStyle(3)
                                .setEmoji(`${Emojis.get(`setaduoroyalty`)}`),
                            new ButtonBuilder()
                                .setCustomId("deletchannel")
                                .setLabel('Deletar')
                                .setEmoji(`${Emojis.get(`_trash_emoji`)}`)
                                .setStyle(4),

                        )

                    const editOptions = { content: ``, embeds: [embed], components: [row3] };
                    if (attachment) {
                        editOptions.files = [attachment];
                    }
                    await interaction.message.edit(editOptions)
                    await interaction.channel.send({ content: `||${interaction.user}|| ${pagamento.msg}` })

                    interaction.channel.setName(`➕・${interaction.user.username}・${interaction.user.id}`)

                } else {
                    DentroCarrinho2(interaction)
                }

            }

            if (interaction.customId == 'confirmarpagamentomanual') {

                const perm = await getPermissions(client.user.id)
                if (perm === null || !perm.includes(interaction.user.id)) {
                    return interaction.reply({ content: `${Emojis.get(`negative`)} | Você não possui permissão para usar esse comando.`, ephemeral: true });
                }

                if (carrinhos.has(interaction.channel.id) == false) return interaction.reply({ content: `${Emojis.get(`negative`)} Não há um carrinho aberto neste canal.`, ephemeral: true })

                interaction.message.delete()

                const yy = await carrinhos.get(interaction.channel.id)

                const hhhh = produtos.get(`${yy.infos.produto}.Campos`)
                const gggaaa = hhhh.find(campo22 => campo22.Nome === yy.infos.campo)


                let valor = 0

                if (yy.cupomadicionado !== undefined) {
                    const valor2 = gggaaa.valor * yy.quantidadeselecionada

                    const hhhh2 = produtos.get(`${yy.infos.produto}.Cupom`)
                    const gggaaaawdwadwa = hhhh2.find(campo22 => campo22.Nome === yy.cupomadicionado)
                    valor = valor2 * (1 - gggaaaawdwadwa.desconto / 100);
                } else {
                    valor = gggaaa.valor * yy.quantidadeselecionada
                }




                const mandanopvdocara = new EmbedBuilder()
                    .setColor(`${configuracao.get(`Cores.Processamento`) == null ? `#fcba03` : configuracao.get(`Cores.Processamento`)}`)
                    .setAuthor({ name: `Pedido #Aprovado Manualmente` })
                    .setTitle(`🛍️ Pedido solicitado`)
                    .setFooter(
                        { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
                    )
                    .setTimestamp()
                    .setDescription(`Seu pedido foi criado e agora está aguardando a confirmação do pagamento`)
                    .addFields(
                        { name: `**Detalhes**`, value: `\`${yy.quantidadeselecionada}x ${yy.infos.produto} - ${yy.infos.campo} | R$ ${Number(valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\`` }
                    )

                try {
                    await interaction.user.send({ embeds: [mandanopvdocara] })
                } catch (error) {

                }



                const dsfjmsdfjnsdfj = new EmbedBuilder()
                    .setColor(`${configuracao.get(`Cores.Processamento`) == null ? `#fcba03` : configuracao.get(`Cores.Processamento`)}`)
                    .setAuthor({ name: `Pedido #Aprovado Manualmente` })
                    .setTitle(`🛍️ Pedido solicitado`)
                    .setDescription(`Usuário ${interaction.user} solicitou um pedido`)
                    .addFields(
                        { name: `**Detalhes**`, value: `\`${yy.quantidadeselecionada}x ${yy.infos.produto} - ${yy.infos.campo} | R$ ${Number(valor).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\`` },
                        { name: `**Forma de pagamento**`, value: `Manualmente` }
                    )
                    .setFooter(
                        { text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) }
                    )
                    .setTimestamp()





                try {
                    const channela = await client.channels.fetch(configuracao.get(`ConfigChannels.logpedidos`));
                    await channela.send({ embeds: [dsfjmsdfjnsdfj] }).then(yyyyy => {
                        carrinhos.set(`${interaction.channel.id}.replys`, { channelid: yyyyy.channel.id, idmsg: yyyyy.id })
                    })
                } catch (error) {

                }

                pagamentos.set(`${interaction.channel.id}`, { pagamentos: { id: `Aprovado Manualmente`, method: `pix`, data: Date.now() } })
                interaction.reply({ content: `${Emojis.get(`check`)} Pagamento aprovado manualmente. Aguarde..`, ephemeral: true })

            }

            if (interaction.customId == 'codigocopiaecolaadwdawd') {
                const pagamento = configuracao.get(`pagamentos.SemiAutomatico`)
                interaction.reply({ content: `Chave pix: ${pagamento.pix}`, ephemeral: true })
            }

            if (interaction.customId == 'deletchannel') {
                const yy = await carrinhos.get(interaction.channel.id);
                
                
                interaction.channel.delete()
            }


            if (interaction.customId == 'usarcupom') {


                const modalaAA = new ModalBuilder()
                    .setCustomId('2313awdawdawdawdaw123141')
                    .setTitle(`Aplicar Cupom`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`CUPOM`)
                    .setPlaceholder(`Qual nome do cupom?`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)


                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN)



                modalaAA.addComponents(firstActionRow3);
                await interaction.showModal(modalaAA);


            }


            if (interaction.customId == 'editarquantidade') {

                const modalaAA = new ModalBuilder()
                    .setCustomId('2313141')
                    .setTitle(`Alterar Quantidade`);

                const newnameboteN = new TextInputBuilder()
                    .setCustomId('tokenMP')
                    .setLabel(`CÓDIGO`)
                    .setPlaceholder(`Insira a quantia que deseja comprar, exemplo: 3`)
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)


                const firstActionRow3 = new ActionRowBuilder().addComponents(newnameboteN)



                modalaAA.addComponents(firstActionRow3);
                await interaction.showModal(modalaAA);

            }


            if (interaction.customId.startsWith('comprarid_')) {

                const gg = interaction.customId
                const yy = gg.replace('comprarid_', '')
                const partes = yy.split('_');
                const campo = partes[0]
                const produto = partes[1]



                const hhhh = produtos.get(`${produto}.Campos`)
                if (hhhh == null) return interaction.reply({ content: `${Emojis.get(`negative`)} Este produto não existe.`, ephemeral: true }).then(msg => {
                    interaction.message.delete()
                })
                const gggaaa = hhhh.find(campo22 => campo22.Nome === campo)



                infos = {
                    estoque: gggaaa.estoque.length,
                    produto: produto,
                    campo: campo
                }

            }

            if (interaction.customId.startsWith('veropcoes_')) {
                const produtoId = interaction.customId.replace('veropcoes_', '');
                
                const produtoInfo = produtos.get(produtoId);
                if (!produtoInfo) {
                    return interaction.reply({ 
                        content: `${Emojis.get('negative')} Este produto não existe.`, 
                        ephemeral: true 
                    });
                }

                await interaction.reply({
                    content: `${Emojis.get('loading')} Carregando Produtos...`,
                    ephemeral: true
                });

                const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
                
                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('comprarid')
                    .setPlaceholder('Selecione uma opção');

                produtoInfo.Campos.forEach(element => {
                    const emojiFormatado = formatarEmoji(element.emoji);
                    const option = {
                        label: element.Nome,
                        description: `R$ ${Number(element.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })} - Estoque: ${element.estoque.length}`,
                        value: `${element.Nome}_${produtoId}`
                    };
                    
                    if (emojiFormatado.id) {
                        option.emoji = emojiFormatado.id;
                    } else if (emojiFormatado.name) {
                        option.emoji = emojiFormatado.name;
                    }
                    
                    selectMenu.addOptions(option);
                });

                const row = new ActionRowBuilder().addComponents(selectMenu);

                await interaction.editReply({
                    content: null,
                    components: [row]
                });
            }


            if (interaction.customId.startsWith('editestoque_')) {


                const regex = /editestoque_(.*?)_(.*)/;
                const correspondencias = interaction.customId.match(regex);

                const produto = correspondencias[1];
                const campo = correspondencias[2];

                MessageStock(interaction, 1, produto, campo)





            }



            if (interaction.customId.startsWith('foraestoquealarme_')) {
                try {
                    const regex = /foraestoquealarme_(.*?)_(.*)_(.*)/;
                    const correspondencias = interaction.customId.match(regex);

                    if (!correspondencias) {
                        return await interaction.reply({ 
                            content: `${Emojis.get('negative')} Erro ao processar o botão. Tente novamente.`, 
                            ephemeral: true 
                        });
                    }

                    const produto = correspondencias[1];
                    const campo = correspondencias[2];
                    const status = correspondencias[3];

                    const hhhh = produtos.get(`${produto}.Campos`);
                    if (!hhhh) {
                        return await interaction.reply({ 
                            content: `${Emojis.get('negative')} Produto não encontrado.`, 
                            ephemeral: true 
                        });
                    }

                    const gggaaa = hhhh.find(campo22 => campo22.Nome === campo);
                    if (!gggaaa) {
                        return await interaction.reply({ 
                            content: `${Emojis.get('negative')} Campo não encontrado.`, 
                            ephemeral: true 
                        });
                    }

                    const produtoNome = produtos.get(`${produto}.Config.name`) || produto;

                    if (gggaaa.avisar !== undefined) {
                        if (!gggaaa.avisar.includes(interaction.user.id)) {
                            gggaaa.avisar.push(interaction.user.id);
                            if (status == 1) {
                                await interaction.reply({ 
                                    content: `${Emojis.get('checker')} Pronto! Você será notificado quando \`${produtoNome} - ${gggaaa.Nome}\` estiver com estoque disponível.`,
                                    ephemeral: true 
                                });
                            } else {
                                await interaction.deferUpdate();
                                await interaction.editReply({ 
                                    content: `${Emojis.get('loading')} Aguarde..`, 
                                    embeds: [], 
                                    components: [] 
                                });
                                await new Promise(resolve => setTimeout(resolve, 1000));
                                await interaction.editReply({ 
                                    content: `${Emojis.get('checker')} Pronto! Você será notificado quando \`${produtoNome} - ${gggaaa.Nome}\` estiver com estoque disponível.`,
                                    embeds: [], 
                                    components: [] 
                                });
                            }
                        } else {
                            const indexToRemove = gggaaa.avisar.indexOf(interaction.user.id);
                            if (indexToRemove !== -1) {
                                gggaaa.avisar.splice(indexToRemove, 1);
                            }
                            if (status == 1) {
                                await interaction.reply({ 
                                    content: `${Emojis.get('checker')} Você foi removido da lista de notificações de \`${produtoNome} - ${gggaaa.Nome}\`.`,
                                    ephemeral: true 
                                });
                            } else {
                                await interaction.deferUpdate();
                                await interaction.editReply({ 
                                    content: `${Emojis.get('loading')} Aguarde..`, 
                                    embeds: [], 
                                    components: [] 
                                });
                                await new Promise(resolve => setTimeout(resolve, 1000));
                                await interaction.editReply({ 
                                    content: `${Emojis.get('checker')} Você foi removido da lista de notificações de \`${produtoNome} - ${gggaaa.Nome}\`.`,
                                    embeds: [], 
                                    components: [] 
                                });
                            }
                        }
                    } else {
                        gggaaa.avisar = [interaction.user.id];
                        if (status == 1) {
                            await interaction.reply({ 
                                content: `${Emojis.get('checker')} Pronto! Você será notificado quando \`${produtoNome} - ${gggaaa.Nome}\` estiver com estoque disponível.`,
                                ephemeral: true 
                            });
                        } else {
                            await interaction.deferUpdate();
                            await interaction.editReply({ 
                                content: `${Emojis.get('loading')} Aguarde..`, 
                                embeds: [], 
                                components: [] 
                            });
                            await new Promise(resolve => setTimeout(resolve, 1000));
                            await interaction.editReply({ 
                                content: `${Emojis.get('checker')} Pronto! Você será notificado quando \`${produtoNome} - ${gggaaa.Nome}\` estiver com estoque disponível.`,
                                embeds: [], 
                                components: [] 
                            });
                        }
                    }

                    await produtos.set(`${produto}.Campos`, hhhh);
                } catch (error) {
                    console.error('[AVISAR ESTOQUE] Erro:', error);
                    try {
                        if (interaction.replied || interaction.deferred) {
                            await interaction.editReply({ 
                                content: `${Emojis.get('negative')} Erro ao processar sua solicitação. Tente novamente.`, 
                                embeds: [], 
                                components: [] 
                            });
                        } else {
                            await interaction.reply({ 
                                content: `${Emojis.get('negative')} Erro ao processar sua solicitação. Tente novamente.`, 
                                ephemeral: true 
                            });
                        }
                    } catch (err) {
                        console.error('[AVISAR ESTOQUE] Erro ao responder:', err);
                    }
                }
            }

            if (interaction.customId.startsWith('copiarprodutos_')) {
                try {
                    await interaction.deferReply({ ephemeral: true });

                    const message = interaction.message;
                    
                    if (!message || !message.embeds || message.embeds.length === 0) {
                        return await interaction.editReply({ 
                            content: '❌ | Não foi possível encontrar a mensagem com os produtos.' 
                        });
                    }

                    const embed = message.embeds[0];
                    
                    const detalhesField = embed.fields.find(field => 
                        field.name === 'Segue abaixo seus produtos:' || 
                        field.name.includes('produtos')
                    );
                    
                    if (detalhesField && detalhesField.value) {
                        const produtoDetalhes = detalhesField.value;
                        
                        if (produtoDetalhes.length > 1900) {
                            return await interaction.editReply({ 
                                content: `\`\`\`\n${produtoDetalhes.substring(0, 1900)}...\n\`\`\`\n*Conteúdo muito grande, verifique a mensagem original para ver todos os produtos.*` 
                            });
                        }
                        
                        await interaction.editReply({ 
                            content: `\`\`\`\n${produtoDetalhes}\n\`\`\`` 
                        });
                    } else {
                        if (message.attachments.size > 0) {
                            const attachment = message.attachments.first();
                            await interaction.editReply({ 
                                content: `Seu produto foi enviado em um arquivo anexo.\n**Arquivo:** ${attachment.name}\n**Link:** ${attachment.url}` 
                            });
                        } else {
                            await interaction.editReply({ 
                                content: 'Seu produto não foi encontrado na embed. Verifique se foi enviado em um arquivo .txt anexo.' 
                            });
                        }
                    }
                } catch (error) {
                    console.error('[COPIAR PRODUTOS] Erro:', error);
                    try {
                        await interaction.editReply({ 
                            content: '❌ | Houve um erro ao tentar copiar o produto. Tente novamente.' 
                        });
                    } catch (err) {
                        await interaction.followUp({ 
                            content: '❌ | Houve um erro ao tentar copiar o produto.', 
                            ephemeral: true 
                        }).catch(() => {});
                    }
                }
            }

        }

        if (interaction.isStringSelectMenu()) {
            if (interaction.customId == 'preview_selectmenu') {
                return interaction.reply({ 
                    content: `${Emojis.get('negative')} Você está no modo preview, não é possível abrir carrinho. Poste o produto para que você consiga abrir carrinho.`, 
                    ephemeral: true 
                });
            }

            if (interaction.customId == 'comprarid') {

                const gg = interaction.values[0]
                const partes = gg.split('_');
                const campo = partes[0]
                const produto = partes[1]

                const hhhh = produtos.get(`${produto}.Campos`)
                const gggaaa = hhhh.find(campo22 => campo22.Nome === campo)

                infos = {
                    estoque: gggaaa.estoque.length,
                    produto: produto,
                    campo: campo,
                    isFromSelectMenu: true
                }

            }
        }


        if (Object.keys(infos).length !== 0) {

            const verify = await VerificaçõesCarrinho(infos)

            if (verify.error == 400) {
                if (infos.isFromSelectMenu) {
                    await interaction.update({ 
                        content: `${Emojis.get('loading')} Iniciando Verificações de Segurança...`, 
                        components: []
                    });

                    await interaction.editReply({ 
                        content: `${Emojis.get('loading')} Verificando disponibilidade no estoque...`,
                        embeds: [],
                        components: []
                    });
                } else {
                    await interaction.reply({ 
                        content: `${Emojis.get('loading')} Iniciando Verificações de Segurança...`, 
                        ephemeral: true 
                    });

                    await interaction.editReply({ 
                        content: `${Emojis.get('loading')} Verificando disponibilidade no estoque...`,
                        embeds: [],
                        components: []
                    });
                }

                const row3 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`foraestoquealarme_${infos.produto}_${infos.campo}_0`)
                            .setLabel('Avisar quando o restock Voltar')
                            .setEmoji(`${Emojis.get(`_notify_emoji`)}`)
                            .setStyle(1),
                    )

                await interaction.editReply({ 
                    content: `${Emojis.get(`negative`)} Este produto está sem estoque no momento, caso quiser clique abaixo para ser notificado.`, 
                    components: [row3]
                });

                return;

            }
            const hhhh = produtos.get(`${infos.produto}.Campos`)
            const gggaaa = hhhh.find(campo22 => campo22.Nome === infos.campo)

            if (gggaaa.condicao?.idcargo !== undefined) {

                const member = await interaction.guild.members.fetch(interaction.user.id);
                const temCargo = member.roles.cache.has(gggaaa.condicao?.idcargo);
                if (temCargo == false) return interaction.reply({ content: `${Emojis.get(`negative`)} Você não possui permissão para comprar esse produto!`, ephemeral: true })
            }

            if (verify.status == 202) {



                CreateCarrinho(interaction, infos)




            }
        }

    }
}