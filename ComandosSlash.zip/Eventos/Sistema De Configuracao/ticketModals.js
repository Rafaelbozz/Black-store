const emojis = require("../../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        if (!interaction.isModalSubmit()) return;

        const customId = interaction.customId;

        if (!customId.startsWith('ticket_rename_modal_')) return;

        try {
            await interaction.deferReply({ ephemeral: true });

            const novoNome = interaction.fields.getTextInputValue('novo_nome');
            const thread = interaction.channel;

            await thread.setName(novoNome);

            await interaction.editReply({
                content: `${Emojis.get('checker') || '✅'} | Ticket renomeado com sucesso para: **${novoNome}**`
            });

        } catch (error) {
            console.error('[ERRO MODAL RENOMEAR TICKET]', error);
            
            if (interaction.deferred) {
                await interaction.editReply({
                    content: `${Emojis.get('negative') || '❌'} | Erro ao renomear ticket: ${error.message}`
                });
            }
        }
    }
};
