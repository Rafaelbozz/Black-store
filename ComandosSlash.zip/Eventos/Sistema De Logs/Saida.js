const { WebhookClient, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'guildMemberRemove',
    run: async (member, client) => {

        try {
            const testando = configuracao.get(`ConfigChannels.saídas`);
            const canal_logs = member.guild.channels.cache.get(testando);
            if (!canal_logs) return 
            
            const nomeUsuario = member.user.username;
            const timeInServer = member.joinedTimestamp ? Date.now() - member.joinedTimestamp : 0;
            const daysInServer = Math.floor(timeInServer / (1000 * 60 * 60 * 24));
            const hoursInServer = Math.floor((timeInServer % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const tempoNoServidor = daysInServer > 0 ? `${daysInServer} dia(s) e ${hoursInServer} hora(s)` : `${hoursInServer} hora(s)`;

            const rolesCount = member.roles.cache.size - 1;

            const containerContent = res.main(
                { type: 10, content: `**Nexus Pro - Logs Saídas**` },
                { type: 14 },
                { type: 10, content: `${Emojis.get('logsusers')} **Usuário:** \`${member.user.tag}\` **Saiu do Servidor**\n${Emojis.get('time_emoji')} Permaneceu aqui por \`${tempoNoServidor}\`` },
                { type: 14 },
                { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>\n${Emojis.get('user')} **Membros Totais no Servidor:** \`${member.guild.memberCount}\`` }
            ).with({});

            canal_logs.send(containerContent);
        } catch (error) {
            console.error('Erro:', error);
        }
    }
}