const { EmbedBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'voiceStateUpdate',
    run: async (oldState, newState, client) => {
        if (oldState.channelId !== newState.channelId) {
            const logChannelId = configuracao.get(`ConfigChannels.tráfego`);
            const logChannel = client.channels.cache.get(logChannelId);
            if (!logChannel) return;

            if (!oldState.channelId && newState.channelId) {
                const containerContent = res.main(
                    { type: 10, content: `**Nexus Pro - Logs Voz (Entrada)**` },
                    { type: 14 },
                    { type: 10, content: `**Usuário:** \`${newState.member.user.tag}\` **Entrou no Canal de Voz**\n**Canal:** ${newState.channel}\n**Membros no canal:** \`${newState.channel.members.size}\`` },
                    { type: 14 },
                    { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
                ).with({});

                logChannel.send(containerContent).catch(console.error);
            }
            else if (oldState.channelId && !newState.channelId) {
                const containerContent = res.main(
                    { type: 10, content: `**Nexus Pro - Logs Voz (Saída)**` },
                    { type: 14 },
                    { type: 10, content: `**Usuário:** \`${oldState.member.user.tag}\` **Saiu do Canal de Voz**\n**Canal:** ${oldState.channel}\n**Membros restantes:** \`${oldState.channel.members.size}\`` },
                    { type: 14 },
                    { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
                ).with({});

                logChannel.send(containerContent).catch(console.error);
            }
            else if (oldState.channelId && newState.channelId) {
                const containerContent = res.main(
                    { type: 10, content: `**Nexus Pro - Logs Voz (Mudança)**` },
                    { type: 14 },
                    { type: 10, content: `**Usuário:** \`${oldState.member.user.tag}\` **Mudou de Canal de Voz**\n**De:** ${oldState.channel}\n**Para:** ${newState.channel}\n**Membros no novo canal:** \`${newState.channel.members.size}\`` },
                    { type: 14 },
                    { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
                ).with({});

                logChannel.send(containerContent).catch(console.error);
            }
        }
    }
};
