const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { configuracao, EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'emojiCreate',
    run: async (emoji, client) => {
        const logChannelId = configuracao.get(`ConfigChannels.auditoria`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setURL(emoji.url)
                    .setLabel('Url do Emoji')
                    .setStyle(ButtonStyle.Link)
            );

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Logs Emojis**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('dowloademoji')} **Emoji Adicionado**\n${Emojis.get('reactiona')} **Emoji:** ${emoji}\n${Emojis.get('_text_emoji')} **Nome:** \`${emoji.name}\`\n${Emojis.get('information_emoji')} **ID:** \`${emoji.id}\`\n${Emojis.get('_change_emoji')} **Animado:** ${emoji.animated ? '\`✅ Sim\`' : '\`❌ Não\`'}` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({
            components: [row]
        });

        logChannel.send(containerContent);
    }
};
