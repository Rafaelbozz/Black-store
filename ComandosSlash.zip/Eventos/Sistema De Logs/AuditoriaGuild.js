const { EmbedBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'guildUpdate',
    run: async (oldGuild, newGuild, client) => {
        const logChannelId = configuracao.get(`ConfigChannels.auditoria`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        let changes = [];
        if (oldGuild.name !== newGuild.name) {
            changes.push(`> **Nome:** \`${oldGuild.name}\` → \`${newGuild.name}\``);
        }
        if (oldGuild.iconURL() !== newGuild.iconURL()) {
            changes.push(`>  **Ícone:** Alterado ${newGuild.iconURL() ? `[Ver novo ícone](${newGuild.iconURL()})` : ''}`);
        }
        if (oldGuild.bannerURL() !== newGuild.bannerURL()) {
            changes.push(`>  **Banner:** Alterado ${newGuild.bannerURL() ? `[Ver novo banner](${newGuild.bannerURL()})` : ''}`);
        }
        if (oldGuild.description !== newGuild.description) {
            changes.push(`>  **Descrição:** \`${oldGuild.description || 'Nenhuma'}\` → \`${newGuild.description || 'Nenhuma'}\``);
        }
        if (oldGuild.vanityURLCode !== newGuild.vanityURLCode) {
            changes.push(`>  **URL Personalizada:** \`${oldGuild.vanityURLCode || 'Nenhuma'}\` → \`${newGuild.vanityURLCode || 'Nenhuma'}\``);
        }
        if (oldGuild.verificationLevel !== newGuild.verificationLevel) {
            const levels = { 0: 'Nenhum', 1: 'Baixo', 2: 'Médio', 3: 'Alto', 4: 'Muito Alto' };
            changes.push(`> **Nível de Verificação:** \`${levels[oldGuild.verificationLevel]}\` → \`${levels[newGuild.verificationLevel]}\``);
        }

        if (changes.length === 0) return;

        const containerContent = res.main(
            { type: 10, content: `Nexus Pro - Logs Servidor Atualizado` },
            { type: 14 },
            { type: 10, content: `**Alterações Detectadas**` },
            { type: 10, content: `> ${Emojis.get('store_emoji')} **Servidor:** \`${newGuild.name}\`\n> ${Emojis.get('information_emoji')}  **ID:** \`${newGuild.id}\`` },
            { type: 14 },
            { type: 10, content: `**Mudanças Realizadas**` },
            { type: 10, content: changes.join('\n') },
            { type: 14 },
            { type: 10, content: `-# ${Emojis.get('calendarlogs')} Data: <t:${Math.floor(Date.now() / 1000)}:F>` }
        ).with({});

        logChannel.send(containerContent);
    }
};
