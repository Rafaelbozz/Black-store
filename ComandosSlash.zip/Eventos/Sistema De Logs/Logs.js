const { WebhookClient, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'messageDelete',
    run: async (message, client) => {
        if (!message.guild || message.author.bot) return;

        const logChannelId = configuracao.get(`ConfigChannels.mensagens`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const messageContent = message.content || '*Sem conteúdo*';
        const truncatedContent = messageContent.length > 500 ? messageContent.substring(0, 500) + '...' : messageContent;
        
        const hasAttachments = message.attachments.size > 0;

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Logs Mensagens Deletadas**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('_trash_emoji')} **Autor:** \`${message.author.tag}\`\n${Emojis.get('logss')} **Canal:** ${message.channel}${hasAttachments ? `\n${Emojis.get('_folder_emoji')} **Anexos:** \`${message.attachments.size} arquivo(s)\`` : ''}` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('_messages_emoji')} **Conteúdo:** \`${truncatedContent}\`` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({});

        logChannel.send(containerContent);
    }
};
