const { EmbedBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'channelDelete',
    run: async (channel, client) => {
        if (!channel.guild) return;

        const logChannelId = configuracao.get(`ConfigChannels.auditoria`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const channelTypes = {
            0: 'Texto',
            2: 'Voz',
            4: 'Categoria',
            5: 'Anúncios',
            13: 'Palco',
            15: 'Fórum'
        };

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Auditoria (Canal Deletado)**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('_trash_emoji')} **Canal Deletado**\n${Emojis.get('_fixe_emoji')} **Nome:** \`${channel.name}\`\n${Emojis.get('cargovery')} **ID:** \`${channel.id}\`\n${Emojis.get('information_emoji')} **Tipo:** \`${channelTypes[channel.type] || 'Desconhecido'}\`\n${Emojis.get('_folder_emoji')} **Categoria:** ${channel.parent ? `\`${channel.parent.name}\`` : '\`Nenhuma\`'}` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({});

        logChannel.send(containerContent);
    }
};
