const { EmbedBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'channelUpdate',
    run: async (oldChannel, newChannel, client) => {
        if (!oldChannel.guild) return;

        const logChannelId = configuracao.get(`ConfigChannels.auditoria`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        let changes = [];
        if (oldChannel.name !== newChannel.name) {
            changes.push(`> **Nome:** \`${oldChannel.name}\` → \`${newChannel.name}\``);
        }
        if (oldChannel.topic !== newChannel.topic) {
            const oldTopic = oldChannel.topic ? (oldChannel.topic.length > 50 ? oldChannel.topic.substring(0, 50) + '...' : oldChannel.topic) : 'Nenhum';
            const newTopic = newChannel.topic ? (newChannel.topic.length > 50 ? newChannel.topic.substring(0, 50) + '...' : newChannel.topic) : 'Nenhum';
            changes.push(`> **Tópico:** \`${oldTopic}\` → \`${newTopic}\``);
        }
        if (oldChannel.parentId !== newChannel.parentId) {
            changes.push(`>  **Categoria:** \`${oldChannel.parent?.name || 'Nenhuma'}\` → \`${newChannel.parent?.name || 'Nenhuma'}\``);
        }
        if (oldChannel.nsfw !== newChannel.nsfw) {
            changes.push(`>  **NSFW:** ${oldChannel.nsfw ? '\`✅ Sim\`' : '\`❌ Não\`'} → ${newChannel.nsfw ? '\`✅ Sim\`' : '\`❌ Não\`'}`);
        }
        if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) {
            changes.push(`> **Modo Lento:** \`${oldChannel.rateLimitPerUser}s\` → \`${newChannel.rateLimitPerUser}s\``);
        }

        if (changes.length === 0) return;

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Logs Auditoria**` },
            { type: 14 },
            { type: 10, content: `**Canal Editado**\n${Emojis.get('textes')} **Canal:** ${newChannel}\n${Emojis.get('information_emoji')} **ID:** \`${newChannel.id}\`\n\n${Emojis.get('cargovery')} **Alterações:**\n${changes.join('\n')}` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({});

        logChannel.send(containerContent);
    }
};
