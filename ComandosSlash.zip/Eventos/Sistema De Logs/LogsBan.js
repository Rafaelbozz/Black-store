const { EmbedBuilder } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'guildBanAdd',
    run: async (ban, client) => {
        const logChannelId = configuracao.get(`ConfigChannels.logsban`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        let reason = ban.reason || 'Motivo não informado';

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Logs Banimentos**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('logsusers')} **Usuário:** \`${ban.user.tag}\`\n${Emojis.get('information_emoji')} **ID:** \`${ban.user.id}\`\n${Emojis.get('_clean_emoji')} **Conta Criada:** <t:${Math.floor(ban.user.createdTimestamp / 1000)}:R>\n${Emojis.get('_fixe_emoji')} **Motivo:** ${reason}` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({});

        logChannel.send(containerContent);
    }
};
