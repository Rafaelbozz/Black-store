const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { configuracao,EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'messageUpdate',
    run: async (oldMessage, newMessage, client) => {
        if (!oldMessage.guild || oldMessage.author.bot || oldMessage.content === newMessage.content) return;

        const logChannelId = configuracao.get(`ConfigChannels.mensagens`);
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;

        const oldContent = oldMessage.content || '*Sem conteúdo*';
        const newContent = newMessage.content || '*Sem conteúdo*';
        
        const truncatedOld = oldContent.length > 400 ? oldContent.substring(0, 400) + '...' : oldContent;
        const truncatedNew = newContent.length > 400 ? newContent.substring(0, 400) + '...' : newContent;

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setURL(newMessage.url)
                    .setLabel('Ir para Mensagem')
                    .setStyle(ButtonStyle.Link)
            );

        const containerContent = res.main(
            { type: 10, content: `**Nexus Pro - Logs Mensagens Editadas**` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('_lapis_emoji')} **Autor:** \`${oldMessage.author.tag}\`\n${Emojis.get('logss')} **Canal:** ${oldMessage.channel}` },
            { type: 14 },
            { type: 10, content: `**Antes:** \`${truncatedOld}\`` },
            { type: 14 },
            { type: 10, content: `**Depois:** \`${truncatedNew}\`` },
            { type: 14 },
            { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
        ).with({
            components: [row]
        });

        logChannel.send(containerContent);
    }
};
