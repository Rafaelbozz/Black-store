const { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const { EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');

const Emojis = EmojisHelper;
const boasvindasPath = path.resolve(__dirname, '../../DataBaseJson/boasvindas.json');

function loadBoasvindasData() {
    try {
        if (fs.existsSync(boasvindasPath)) {
            const data = JSON.parse(fs.readFileSync(boasvindasPath, 'utf8'));
            
            if (data.canalId && !Array.isArray(data.canalId)) {
                data.canaisIds = [data.canalId];
                delete data.canalId;
                saveBoasvindasData(data);
            }
            
            if (!data.canaisIds) {
                data.canaisIds = [];
            }
            
            return data;
        }
    } catch (e) {
        console.error('[BoasVindas] Erro ao carregar dados:', e);
    }
    return {
        ativo: false,
        exclusaoAutomatica: false,
        tempoExclusao: 10,
        canaisIds: [],
        modo: "canal",
        mensagem: "Seja bem-vindo(a) {membro} ao servidor **{servidor}**!\n\nVocê é o membro número **{total}**!",
        botao: {
            ativo: false,
            texto: "",
            link: "",
            emoji: ""
        }
    };
}

function saveBoasvindasData(data) {
    try {
        fs.writeFileSync(boasvindasPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[BoasVindas] Erro ao salvar dados:', e);
    }
}

async function painelBoasVindas(interaction, client) {
    const data = loadBoasvindasData();
    const statusSistema = data.ativo || false;
    const statusExclusao = data.exclusaoAutomatica || false;
    
    let canaisConfigurados = '`Nenhum canal configurado`';
    if (data.canaisIds && data.canaisIds.length > 0) {
        canaisConfigurados = data.canaisIds.map(id => `<#${id}>`).join(', ');
    }
    
    const modoAtual = data.modo === 'canal' ? 'Canal' : 'DM (Mensagem Privada)';

    const rowBotoes1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusSistema ? "desativar_boasvindas" : "ativar_boasvindas")
            .setLabel(statusSistema ? 'Desativar Sistema' : 'Ativar Sistema')
            .setEmoji(statusSistema ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusSistema ? 4 : 3),
        new ButtonBuilder()
            .setCustomId(statusExclusao ? "desativar_exclusao_boasvindas" : "ativar_exclusao_boasvindas")
            .setLabel(statusExclusao ? 'Desativar Exclusão' : 'Ativar Exclusão')
            .setEmoji(statusExclusao ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusExclusao ? 4 : 3)
            .setDisabled(data.modo === 'dm'),
        new ButtonBuilder()
            .setCustomId("definir_canal_boasvindas")
            .setLabel('Adicionar Canal')
            .setEmoji(Emojis.get('logss'))
            .setStyle(1)
            .setDisabled(data.modo === 'dm')
    );

    const rowBotoes2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("configurar_msg_boasvindas")
            .setLabel('Configurar Mensagem')
            .setEmoji(Emojis.get('_lapis_emoji'))
            .setStyle(2),
        new ButtonBuilder()
            .setCustomId("definir_exclusao_boasvindas")
            .setLabel('Definir Exclusão')
            .setEmoji(Emojis.get('expix'))
            .setStyle(2)
            .setDisabled(data.modo === 'dm'),
        new ButtonBuilder()
            .setCustomId("preview_boasvindas")
            .setLabel('Ver Preview')
            .setEmoji(Emojis.get('_search_emoji'))
            .setStyle(2)
    );

    const rowBotoes3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("alterar_modo_boasvindas")
            .setLabel('Alterar Modo')
            .setEmoji(Emojis.get('_change_emoji'))
            .setStyle(2),
        new ButtonBuilder()
            .setCustomId("remover_canal_boasvindas")
            .setLabel('Remover Canal')
            .setEmoji(Emojis.get('_trash_emoji'))
            .setStyle(4)
            .setDisabled(data.modo === 'dm' || !data.canaisIds || data.canaisIds.length === 0)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Mensagem de Boas-vindas` },
        { type: 14 },
        { type: 10, content: `## Sistema de Mensagem de Boas-vindas\n\n> Configure mensagens personalizadas para dar boas-vindas aos novos membros.\n> Escolha entre enviar no canal ou na DM do usuário.` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusSistema ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Exclusão Automática: ${statusExclusao ? '``🟢 Ativada``' : '``🔴 Desativada``'}${data.modo === 'dm' ? ' (Indisponível no modo DM)' : ''}\n- Tempo de Exclusão: \`${data.tempoExclusao} segundos\`\n- Canais: ${canaisConfigurados}${data.modo === 'dm' ? ' (Não usado no modo DM)' : ''}\n- Total de Canais: \`${data.canaisIds?.length || 0}\`\n- Modo: \`${modoAtual}\`\n- Botão: ${data.botao?.ativo ? '``🟢 Configurado``' : '``🔴 Não configurado``'}` },
        { type: 14 },
        { type: 10, content: `**Variáveis Disponíveis**\n- \`\`{membro}\`\` - Mencionar membro novo\n- \`\`{servidor}\`\` - Nome do servidor\n- \`\`{total}\`\` - Total de membros` },
        { type: 14 }
    ).with({
        components: [rowBotoes1, rowBotoes2, rowBotoes3, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function painelDefinirCanal(interaction) {
    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canal_boasvindas")
            .setPlaceholder("Selecione um ou mais canais")
            .setChannelTypes([ChannelType.GuildText])
            .setMinValues(1)
            .setMaxValues(10)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_boasvindas")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Boas-vindas > Adicionar Canais` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canais\n\n> Escolha um ou mais canais onde as mensagens de boas-vindas serão enviadas.\n> Você pode selecionar até 10 canais de uma vez.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

async function painelRemoverCanal(interaction, client) {
    const { StringSelectMenuBuilder } = require("discord.js");
    const data = loadBoasvindasData();

    if (!data.canaisIds || data.canaisIds.length === 0) {
        return interaction.reply({
            content: `${Emojis.get('negative') || '❌'} Nenhum canal configurado para remover.`,
            ephemeral: true
        });
    }

    const options = data.canaisIds.map((canalId, index) => {
        const canal = client.channels.cache.get(canalId);
        const canalNome = canal ? `#${canal.name}` : 'Canal não encontrado';
        
        return {
            label: canalNome,
            description: `ID: ${canalId}`,
            value: canalId
        };
    });

    const rowSelect = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId("select_remover_canal_boasvindas")
            .setPlaceholder("Selecione os canais para remover")
            .setMinValues(1)
            .setMaxValues(options.length)
            .addOptions(options)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_boasvindas")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Boas-vindas > Remover Canais` },
        { type: 14 },
        { type: 10, content: `## Remover Canais\n\n> Selecione os canais que deseja remover da lista de boas-vindas.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

async function previewBoasVindas(interaction) {
    const data = loadBoasvindasData();
    const { ButtonBuilder, ActionRowBuilder } = require("discord.js");

    let mensagem = data.mensagem || "Seja bem-vindo(a) {membro} ao servidor **{servidor}**!\n\nVocê é o membro número **{total}**!";
    
    mensagem = mensagem
        .replace(/{membro}/g, `<@${interaction.user.id}>`)
        .replace(/{servidor}/g, interaction.guild.name)
        .replace(/{total}/g, interaction.guild.memberCount.toString());

    const components = [];

    if (data.botao?.ativo && data.botao?.texto && data.botao?.link) {
        const botaoRow = new ActionRowBuilder();
        const botao = new ButtonBuilder()
            .setLabel(data.botao.texto)
            .setURL(data.botao.link)
            .setStyle(5);

        if (data.botao.emoji) {
            const emojiMatch = data.botao.emoji.match(/:(\d+)>/);
            if (emojiMatch) {
                botao.setEmoji(emojiMatch[1]);
            } else {
                botao.setEmoji(data.botao.emoji);
            }
        }

        botaoRow.addComponents(botao);
        components.push(botaoRow);
    }

    await interaction.reply({
        content: mensagem,
        components: components,
        ephemeral: true
    });
}

module.exports = {
    painelBoasVindas,
    painelDefinirCanal,
    painelRemoverCanal,
    previewBoasVindas,
    loadBoasvindasData,
    saveBoasvindasData
};
