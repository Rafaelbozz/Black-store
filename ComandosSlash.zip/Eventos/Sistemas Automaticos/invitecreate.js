module.exports = {
    name: 'inviteCreate',
    run: async (invite) => {
        try {
            const invitesCache = global.invitesCache || new Map();
            const convitesAtuais = invitesCache.get(invite.guild.id) || new Map();
            convitesAtuais.set(invite.code, invite.uses);
            invitesCache.set(invite.guild.id, convitesAtuais);
            global.invitesCache = invitesCache;
        } catch (error) {
            console.error('[InviteTracker] Erro ao processar criação de convite:', error);
        }
    }
};
