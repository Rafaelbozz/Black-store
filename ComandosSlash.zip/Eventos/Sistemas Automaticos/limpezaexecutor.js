const { loadLimpezaData } = require("./limpezaautomatica");
const { ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { res } = require("../../res");
const moment = require('moment-timezone');

let limpezaTimeout = null;
let limpezaCheckInterval = null;

async function executarLimpeza(client) {
    try {
        const data = loadLimpezaData();
        
        if (!data.ativo) return;
        
        if (!data.canais || data.canais.length === 0) return;

        const currentTime = moment.tz("America/Sao_Paulo");
        console.log(`[LimpezaAutomatica] Iniciando limpeza automática às ${currentTime.format('HH:mm:ss')}`);
        
        for (const canalId of data.canais) {
            try {
                for (const [guildId, guild] of client.guilds.cache) {
                    const canal = guild.channels.cache.get(canalId);
                    
                    if (canal) {
                        console.log(`[LimpezaAutomatica] Limpando canal ${canal.name} no servidor ${guild.name}`);
                        
                        let totalDeleted = 0;
                        let fetched;
                        
                        do {
                            fetched = await canal.messages.fetch({ limit: 100 });
                            if (fetched.size > 0) {
                                const deletedMessages = await canal.bulkDelete(fetched, true).catch(() => ({ size: 0 }));
                                totalDeleted += deletedMessages.size;
                                
                                if (deletedMessages.size < fetched.size) {
                                    console.log(`[LimpezaAutomatica] Deletando mensagens antigas individualmente...`);
                                    
                                    for (const [id, message] of fetched) {
                                        try {
                                            const stillExists = await canal.messages.fetch(id).catch(() => null);
                                            if (stillExists) {
                                                await message.delete();
                                                totalDeleted++;
                                                await new Promise(resolve => setTimeout(resolve, 100));
                                            }
                                        } catch (error) {
                                            console.error(`[LimpezaAutomatica] Erro ao deletar mensagem ${id}:`, error);
                                        }
                                    }
                                }
                            }
                        } while (fetched.size >= 2);

                        console.log(`[LimpezaAutomatica] Canal ${canal.name} limpo! ${totalDeleted} mensagens removidas.`);
                        
                        const timestamp = Math.floor(currentTime.valueOf() / 1000);

                        const containerContent = res.main(
                            { type: 10, content: `##  Canal Limpo Automaticamente` },
                            { type: 10, content: `> Este canal foi limpo automaticamente pelo sistema <t:${timestamp}:R>.` },
                            { type: 14 },
                            { type: 10, content: `**Estatísticas:**\n- Total de mensagens removidas: \`${totalDeleted}\`` },
                            { type: 14 },
                            {
                                type: 1,
                                components: [
                                    { type: 2, style: 2, label: 'Mensagem do Sistema', custom_id: 'abrir_sistema_limpeza', disabled: true }
                                ]
                            }
                        );

                        await canal.send(containerContent);

                        break;
                    }
                }
            } catch (error) {
                console.error(`[LimpezaAutomatica] Erro ao limpar canal ${canalId}:`, error);
            }
        }

        agendarProximaLimpeza(client);
    } catch (error) {
        console.error('[LimpezaAutomatica] Erro no executor:', error);
    }
}

function agendarProximaLimpeza(client) {
    if (limpezaTimeout) {
        clearTimeout(limpezaTimeout);
        limpezaTimeout = null;
    }

    const data = loadLimpezaData();
    
    if (!data.ativo) return;

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hours, minutes] = data.horario.split(':').map(Number);
    
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hours, 
        minute: minutes, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextExecutionTime.isSameOrBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const msUntilExecution = nextExecutionTime.diff(currentTime);
    
    console.log(`[LimpezaAutomatica] Próxima execução agendada para ${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')} (em ${Math.round(msUntilExecution / 1000 / 60)} minutos)`);
    
    limpezaTimeout = setTimeout(() => {
        executarLimpeza(client);
    }, msUntilExecution);
}

function iniciarLimpezaAutomatica(client) {
    pararLimpezaAutomatica();

    const data = loadLimpezaData();
    
    if (!data.ativo) {
        console.log('[LimpezaAutomatica] Sistema desativado');
        return;
    }

    agendarProximaLimpeza(client);

    limpezaCheckInterval = setInterval(async () => {
        const currentData = loadLimpezaData();
        
        if (!currentData.ativo) return;

        const currentTime = moment.tz("America/Sao_Paulo");
        const currentHour = currentTime.format('HH:mm');

        if (currentHour === currentData.horario) {
            console.log('[LimpezaAutomatica] Verificação de 1 minuto - Executando limpeza');
            await executarLimpeza(client);
        }
    }, 60000);

    console.log('[LimpezaAutomatica] Sistema de limpeza automática iniciado');
}

function pararLimpezaAutomatica() {
    if (limpezaTimeout) {
        clearTimeout(limpezaTimeout);
        limpezaTimeout = null;
    }
    if (limpezaCheckInterval) {
        clearInterval(limpezaCheckInterval);
        limpezaCheckInterval = null;
    }
    console.log('[LimpezaAutomatica] Sistema de limpeza automática parado');
}

module.exports = {
    iniciarLimpezaAutomatica,
    pararLimpezaAutomatica
};
