const { loadBoasvindasData, saveBoasvindasData, painelBoasVindas } = require("./boasvindas");

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        try {
            if (interaction.isModalSubmit() && interaction.customId === 'modal_configurar_msg_boasvindas') {
                const mensagem = interaction.fields.getTextInputValue('mensagem_boasvindas');
                const botaoTexto = interaction.fields.getTextInputValue('botao_texto');
                const botaoLink = interaction.fields.getTextInputValue('botao_link');
                const botaoEmoji = interaction.fields.getTextInputValue('botao_emoji');
                
                const data = loadBoasvindasData();
                data.mensagem = mensagem;

                if (botaoTexto && botaoLink) {
                    try {
                        new URL(botaoLink);
                        data.botao = {
                            ativo: true,
                            texto: botaoTexto,
                            link: botaoLink,
                            emoji: botaoEmoji || ""
                        };
                    } catch (e) {
                        await interaction.reply({ 
                            content: `❌ | Link inválido! Use um URL completo (ex: https://discord.gg/...)`, 
                            ephemeral: true 
                        });
                        return;
                    }
                } else {
                    data.botao = {
                        ativo: false,
                        texto: "",
                        link: "",
                        emoji: ""
                    };
                }

                saveBoasvindasData(data);

                await interaction.deferUpdate();
                await painelBoasVindas(interaction, client);
            }

            if (interaction.isModalSubmit() && interaction.customId === 'modal_definir_exclusao_boasvindas') {
                const tempoStr = interaction.fields.getTextInputValue('tempo_exclusao');
                const tempo = parseInt(tempoStr);

                if (isNaN(tempo) || tempo < 1 || tempo > 300) {
                    await interaction.reply({ 
                        content: `❌ | Tempo inválido! Use um número entre 1 e 300 segundos.`, 
                        ephemeral: true 
                    });
                    return;
                }

                const data = loadBoasvindasData();
                data.tempoExclusao = tempo;
                saveBoasvindasData(data);

                await interaction.deferUpdate();
                await painelBoasVindas(interaction, client);
            }

            if (interaction.isChannelSelectMenu() && interaction.customId === 'select_canal_boasvindas') {
                const canaisSelecionados = interaction.values;
                const data = loadBoasvindasData();
                
                if (!data.canaisIds) {
                    data.canaisIds = [];
                }
                
                let adicionados = 0;
                for (const canalId of canaisSelecionados) {
                    if (!data.canaisIds.includes(canalId)) {
                        data.canaisIds.push(canalId);
                        adicionados++;
                    }
                }
                
                saveBoasvindasData(data);
                
                await interaction.deferUpdate();
                await painelBoasVindas(interaction, client);
                
                if (adicionados > 0) {
                    await interaction.followUp({
                        content: `✅ | ${adicionados} canal(is) adicionado(s) com sucesso!`,
                        ephemeral: true
                    });
                } else {
                    await interaction.followUp({
                        content: `⚠️ | Todos os canais selecionados já estavam configurados.`,
                        ephemeral: true
                    });
                }
            }

            if (interaction.isStringSelectMenu() && interaction.customId === 'select_remover_canal_boasvindas') {
                const canaisParaRemover = interaction.values;
                const data = loadBoasvindasData();
                
                data.canaisIds = data.canaisIds.filter(id => !canaisParaRemover.includes(id));
                
                saveBoasvindasData(data);
                
                await interaction.deferUpdate();
                await painelBoasVindas(interaction, client);
                
                await interaction.followUp({
                    content: `✅ | ${canaisParaRemover.length} canal(is) removido(s) com sucesso!`,
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error('[BoasVindasHandler] Erro:', error);
        }
    }
};
