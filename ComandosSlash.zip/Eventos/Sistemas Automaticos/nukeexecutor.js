const { loadNukeData } = require("./nukeautomatico");
const { ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { res } = require("../../res");
const moment = require('moment-timezone');

let nukeTimeout = null;
let nukeCheckInterval = null;

async function executarNuke(client) {
    try {
        const data = loadNukeData();
        
        if (!data.ativo) return;
        
        if (!data.canais || data.canais.length === 0) return;

        const currentTime = moment.tz("America/Sao_Paulo");
        console.log(`[NukeAutomatico] Iniciando nuke automático às ${currentTime.format('HH:mm:ss')}`);
        
        for (const canalId of data.canais) {
            try {
                for (const [guildId, guild] of client.guilds.cache) {
                    const canal = guild.channels.cache.get(canalId);
                    
                    if (canal) {
                        console.log(`[NukeAutomatico] Nukando canal ${canal.name} no servidor ${guild.name}`);
                        
                        const position = canal.position;
                        const parent = canal.parent;
                        const permissionOverwrites = canal.permissionOverwrites.cache;
                        const name = canal.name;
                        const topic = canal.topic;
                        const nsfw = canal.nsfw;
                        const rateLimitPerUser = canal.rateLimitPerUser;

                        const novoCanal = await canal.clone({
                            name: name,
                            topic: topic,
                            nsfw: nsfw,
                            rateLimitPerUser: rateLimitPerUser,
                            parent: parent,
                            permissionOverwrites: permissionOverwrites,
                            position: position,
                            reason: 'Nuke Automático'
                        });

                        await canal.delete('Nuke Automático');

                        console.log(`[NukeAutomatico] Canal ${name} nukado com sucesso!`);
                        
                        const currentTime = moment.tz("America/Sao_Paulo");
                        const timestamp = Math.floor(currentTime.valueOf() / 1000);

                        const containerContent = res.main(
                            { type: 10, content: `## Canal Nukado Automaticamente` },
                            { type: 10, content: `> Este canal foi nukado automaticamente pelo sistema <t:${timestamp}:R>.` },
                            { type: 14 },
                            { type: 10, content: `**Informações:**\n- Canal recriado com todas as configurações preservadas\n- Todas as mensagens anteriores foram removidas\n- Horário do nuke: \`${currentTime.format('HH:mm:ss')}\`` },
                            { type: 14 },
                            {
                                type: 1,
                                components: [
                                    { type: 2, style: 2, label: 'Mensagem do Sistema', custom_id: 'abrir_sistema_nuke', disabled: true }
                                ]
                            }
                        );

                        await novoCanal.send(containerContent);

                        break;
                    }
                }
            } catch (error) {
                console.error(`[NukeAutomatico] Erro ao nukar canal ${canalId}:`, error);
            }
        }

        agendarProximoNuke(client);
    } catch (error) {
        console.error('[NukeAutomatico] Erro no executor:', error);
    }
}

function agendarProximoNuke(client) {
    if (nukeTimeout) {
        clearTimeout(nukeTimeout);
        nukeTimeout = null;
    }

    const data = loadNukeData();
    
    if (!data.ativo) return;

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hours, minutes] = data.horario.split(':').map(Number);
    
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hours, 
        minute: minutes, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextExecutionTime.isSameOrBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const msUntilExecution = nextExecutionTime.diff(currentTime);
    
    console.log(`[NukeAutomatico] Próxima execução agendada para ${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')} (em ${Math.round(msUntilExecution / 1000 / 60)} minutos)`);
    
    nukeTimeout = setTimeout(() => {
        executarNuke(client);
    }, msUntilExecution);
}

function iniciarNukeAutomatico(client) {
    pararNukeAutomatico();

    const data = loadNukeData();
    
    if (!data.ativo) {
        console.log('[NukeAutomatico] Sistema desativado');
        return;
    }

    agendarProximoNuke(client);

    nukeCheckInterval = setInterval(async () => {
        const currentData = loadNukeData();
        
        if (!currentData.ativo) return;

        const currentTime = moment.tz("America/Sao_Paulo");
        const currentHour = currentTime.format('HH:mm');

        if (currentHour === currentData.horario) {
            console.log('[NukeAutomatico] Verificação de 1 minuto - Executando nuke');
            await executarNuke(client);
        }
    }, 60000);

    console.log('[NukeAutomatico] Sistema de nuke automático iniciado');
}

function pararNukeAutomatico() {
    if (nukeTimeout) {
        clearTimeout(nukeTimeout);
        nukeTimeout = null;
    }
    if (nukeCheckInterval) {
        clearInterval(nukeCheckInterval);
        nukeCheckInterval = null;
    }
    console.log('[NukeAutomatico] Sistema de nuke automático parado');
}

module.exports = {
    iniciarNukeAutomatico,
    pararNukeAutomatico
};
