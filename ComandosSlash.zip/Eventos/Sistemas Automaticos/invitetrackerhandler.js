const { loadInvitesData, saveInvitesData, painelInviteTracker } = require("./invitetracker");

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        try {
            if (interaction.isModalSubmit() && interaction.customId === 'modal_configurar_msgs_invite') {
                const mensagemEntradaNormal = interaction.fields.getTextInputValue('mensagemEntradaNormal');
                const mensagemEntradaVanity = interaction.fields.getTextInputValue('mensagemEntradaVanity');
                const mensagemSaida = interaction.fields.getTextInputValue('mensagemSaida');
                
                const data = loadInvitesData();
                data.mensagemEntradaNormal = mensagemEntradaNormal;
                data.mensagemEntradaVanity = mensagemEntradaVanity;
                data.mensagemSaida = mensagemSaida;
                saveInvitesData(data);

                await interaction.deferUpdate();
                await painelInviteTracker(interaction, interaction.client);
            }
        } catch (error) {
            console.error('[InviteTrackerHandler] Erro:', error);
        }
    }
};
