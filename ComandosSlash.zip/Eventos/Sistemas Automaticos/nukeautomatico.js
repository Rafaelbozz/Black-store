const { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const { EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

const Emojis = EmojisHelper;
const nukeAutomaticoPath = path.resolve(__dirname, '../../DataBaseJson/nukeautomatico.json');

function loadNukeData() {
    try {
        if (fs.existsSync(nukeAutomaticoPath)) {
            return JSON.parse(fs.readFileSync(nukeAutomaticoPath, 'utf8'));
        }
    } catch (e) {
        console.error('[NukeAutomatico] Erro ao carregar dados:', e);
    }
    return {
        ativo: false,
        horario: "00:00",
        canais: []
    };
}

function saveNukeData(data) {
    try {
        fs.writeFileSync(nukeAutomaticoPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[NukeAutomatico] Erro ao salvar dados:', e);
    }
}

async function painelNukeAutomatico(interaction, client) {
    const data = loadNukeData();
    const statusSistema = data.ativo || false;
    const horarioConfig = data.horario || "00:00";
    const canaisConfig = data.canais || [];

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hours, minutes] = horarioConfig.split(':').map(Number);
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ hour: hours, minute: minutes, second: 0, millisecond: 0 });
    
    if (nextExecutionTime.isBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const nextExecutionTimestamp = Math.floor(nextExecutionTime.valueOf() / 1000);

    let canaisTexto = '`Nenhum canal configurado`';
    if (canaisConfig.length > 0) {
        canaisTexto = canaisConfig.map(id => `<#${id}>`).join(', ');
    }

    const rowBotoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusSistema ? "desativar_nuke_auto" : "ativar_nuke_auto")
            .setLabel(statusSistema ? 'Desativar' : 'Ativar')
            .setEmoji(statusSistema ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusSistema ? 4 : 3),
        new ButtonBuilder()
            .setCustomId("definir_horario_nuke")
            .setLabel('Definir Horário')
            .setEmoji(Emojis.get('relogio'))
            .setStyle(2)
            .setDisabled(!statusSistema),
        new ButtonBuilder()
            .setCustomId("definir_canais_nuke")
            .setLabel('Definir Canais')
            .setEmoji(Emojis.get('textes'))
            .setStyle(2)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Nuke Automático` },
        { type: 14 },
        { type: 10, content: `## Sistema de Nuke Automático\n\n> Configure o sistema para limpar (nuke) canais automaticamente em horários específicos.\n> O nuke clona o canal, deletando todas as mensagens antigas.` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusSistema ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Horário configurado: \`${horarioConfig}\` (Horário de Brasília)\n- Canais configurados: \`${canaisConfig.length}\`\n- Próxima execução: ${statusSistema ? `\`${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '\`Desativado\`'}\n- Tempo restante: ${statusSistema ? `<t:${nextExecutionTimestamp}:R>` : '\`Desativado\`'}` },
        { type: 14 },
        { type: 10, content: `**Canais:**\n${canaisTexto}` },
        { type: 14 }
    ).with({
        components: [rowBotoes, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function painelDefinirCanaisNuke(interaction) {
    const data = loadNukeData();
    
    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canais_nuke")
            .setPlaceholder("Selecione os canais para nuke automático")
            .setChannelTypes([ChannelType.GuildText])
            .setMinValues(0)
            .setMaxValues(25)
            .setDefaultChannels(data.canais || [])
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_nuke_auto")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Nuke Automático > Definir Canais` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canais\n\n> Escolha os canais que serão limpos automaticamente no horário configurado.\n> Você pode selecionar múltiplos canais.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    painelNukeAutomatico,
    painelDefinirCanaisNuke,
    loadNukeData,
    saveNukeData
};
