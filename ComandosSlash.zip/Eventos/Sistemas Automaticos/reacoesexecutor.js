const { loadReacoesData } = require("./reacoesautomaticas");

module.exports = {
    name: 'messageCreate',
    run: async (message, client) => {
        try {
            if (message.author.bot) return;

            const data = loadReacoesData();

            if (!data.ativo) return;

            if (!data.configs || data.configs.length === 0) return;

            const config = data.configs.find(c => c.canalId === message.channel.id);
            if (!config) return;

            for (const emoji of config.emojis) {
                try {
                    const customEmojiMatch = emoji.match(/<a?:(\w+):(\d+)>/);
                    if (customEmojiMatch) {
                        const emojiId = customEmojiMatch[2];
                        await message.react(emojiId);
                    } else {
                        await message.react(emoji);
                    }
                } catch (error) {
                    console.error(`[ReacoesExecutor] Erro ao reagir com ${emoji}:`, error.message);
                }
            }
        } catch (error) {
            console.error('[ReacoesExecutor] Erro:', error);
        }
    }
};
