const { loadMonitorData } = require("./monitorfeedback");
const { configuracao, EmojisHelper } = require("../../DataBaseJson");
const { ButtonBuilder, ActionRowBuilder } = require("discord.js");
const { res } = require("../../res");

const Emojis = EmojisHelper;

const palavrasNegativas = [
    'ruim', 'péssimo', 'horrível', 'terrível', 'lixo', 'porcaria', 'merda', 'bosta',
    'fraude', 'golpe', 'scam', 'roubo', 'ladrão', 'enganação', 'mentira',
    'não recomendo', 'não comprem', 'fujam', 'cuidado', 'péssima', 'horrivel',
    'decepção', 'decepcionante', 'arrependimento', 'arrependido', 'nunca mais',
    'pior', 'pior loja', 'pior bot', 'pior servidor', 'não funciona', 'não presta'
];

const palavrasExtremas = [
    'lixo', 'porcaria', 'merda', 'bosta', 'fraude', 'golpe', 'scam',
    'ladrão', 'roubo', 'enganação', 'pior loja', 'não comprem', 'fujam'
];

function normalizarTexto(texto) {
    return texto
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[0-9]/g, '')
        .replace(/[^a-z\s]/g, '');
}

function analisarSentimento(mensagem) {
    const textoNormalizado = normalizarTexto(mensagem);
    
    const isExtremo = palavrasExtremas.some(palavra => {
        const palavraNormalizada = normalizarTexto(palavra);
        return textoNormalizado.includes(palavraNormalizada);
    });
    
    const isNegativo = palavrasNegativas.some(palavra => {
        const palavraNormalizada = normalizarTexto(palavra);
        return textoNormalizado.includes(palavraNormalizada);
    });
    
    const countNegativas = palavrasNegativas.filter(palavra => {
        const palavraNormalizada = normalizarTexto(palavra);
        return textoNormalizado.includes(palavraNormalizada);
    }).length;
    
    return {
        isNegativo: isNegativo,
        isExtremo: isExtremo || countNegativas >= 3,
        nivel: isExtremo || countNegativas >= 3 ? 'EXTREMO' : countNegativas >= 2 ? 'ALTO' : countNegativas >= 1 ? 'MODERADO' : 'BAIXO'
    };
}

async function enviarAlerta(client, message, analise, mensagemDeletada = false) {
    try {
        const data = loadMonitorData();
        
        if (!data.canalLogs) return;
        
        const canalLogs = await client.channels.fetch(data.canalLogs).catch(() => null);
        if (!canalLogs) return;

        const nivelEmoji = analise.nivel === 'EXTREMO' ? '🔴' : analise.nivel === 'ALTO' ? '🟠' : '🟡';
        const nivelCor = analise.nivel === 'EXTREMO' ? 'Vermelho' : analise.nivel === 'ALTO' ? 'Laranja' : 'Amarelo';

        const botaoDeletar = new ButtonBuilder()
            .setCustomId(`deletar_feedback_${message.id}_${message.channelId}`)
            .setLabel(mensagemDeletada ? 'Mensagem Apagada Automaticamente' : 'Deletar Mensagem')
            .setEmoji(Emojis.get('_trash_emoji'))
            .setStyle(4)
            .setDisabled(mensagemDeletada);

        const botaoIr = new ButtonBuilder()
            .setLabel('Ir até a Mensagem')
            .setURL(message.url)
            .setEmoji('👁️')
            .setStyle(5)
            .setDisabled(mensagemDeletada);

        const rowBotoes = new ActionRowBuilder().addComponents(botaoDeletar, botaoIr);

        const containerContent = res.main(
            { type: 10, content: `## Alerta de Feedback Negativo` },
            { type: 10, content: `> Um feedback negativo foi detectado no canal de feedbacks.` },
            { type: 14 },
            { type: 10, content: `╭─────────────────────────────────╮` },
            { type: 10, content: `│ **Informações do Feedback**` },
            { type: 10, content: `│` },
            { type: 10, content: `│  **Autor:** ${message.author}` },
            { type: 10, content: `│  **Nível:** \`${analise.nivel}\` ${nivelEmoji}` },
            { type: 10, content: `│  **Canal:** ${message.channel}` },
            { type: 10, content: `│  **Data:** <t:${Math.floor(message.createdTimestamp / 1000)}:F>` },
            { type: 10, content: `│` },
            { type: 10, content: mensagemDeletada ? `│ ⚠️ **Status:** Mensagem deletada automaticamente` : `│ ✅ **Status:** Aguardando moderação` },
            { type: 10, content: `╰─────────────────────────────────╯` },
            { type: 14 },
            { type: 10, content: `**Conteúdo da Mensagem:**` },
            { type: 10, content: `\`\`\`${message.content.substring(0, 1000)}\`\`\`` },
            { type: 14 }
        ).with({
            components: [rowBotoes]
        });

        await canalLogs.send(containerContent);
        
        console.log(`[MonitorFeedback] Alerta enviado - Nível: ${analise.nivel}`);
    } catch (error) {
        console.error('[MonitorFeedback] Erro ao enviar alerta:', error);
    }
}

module.exports = {
    name: 'messageCreate',
    run: async (message) => {
        try {
            if (message.author.bot) return;
            
            if (!message.guild) return;

            const data = loadMonitorData();
            
            if (!data.ativo) return;
            
            const canalFeedback = configuracao.get('ConfigChannels.feedback');
            if (!canalFeedback || message.channel.id !== canalFeedback) return;

            const analise = analisarSentimento(message.content);
            
            if (!analise.isNegativo) return;

            console.log(`[MonitorFeedback] Feedback negativo detectado - Nível: ${analise.nivel}`);

            let mensagemDeletada = false;
            if (analise.isExtremo) {
                try {
                    await message.delete();
                    mensagemDeletada = true;
                    console.log(`[MonitorFeedback] Mensagem extremamente negativa deletada automaticamente`);
                } catch (error) {
                    console.error('[MonitorFeedback] Erro ao deletar mensagem:', error);
                }
            }

            await enviarAlerta(message.client, message, analise, mensagemDeletada);

        } catch (error) {
            console.error('[MonitorFeedback] Erro no executor:', error);
        }
    }
};
