const invitesCache = new Map();

module.exports = {
    name: 'ready',
    run: async (client) => {
        for (const guild of client.guilds.cache.values()) {
            try {
                const invites = await guild.invites.fetch();
                invitesCache.set(guild.id, new Map(invites.map(invite => [invite.code, invite.uses])));
            } catch (error) {
                console.error(`[InviteTracker] Erro ao carregar convites do servidor ${guild.name}:`, error.message);
            }
        }
        console.log('[InviteTracker] Cache de convites carregado!');
        
        global.invitesCache = invitesCache;
    }
};
