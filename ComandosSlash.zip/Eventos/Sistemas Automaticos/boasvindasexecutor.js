const { loadBoasvindasData } = require("./boasvindas");
const { ButtonBuilder, ActionRowBuilder } = require("discord.js");

module.exports = {
    name: 'guildMemberAdd',
    run: async (member) => {
        try {
            const data = loadBoasvindasData();
            
            if (!data.ativo) return;

            let mensagem = data.mensagem || "Seja bem-vindo(a) {membro} ao servidor **{servidor}**!\n\nVocê é o membro número **{total}**!";
            
            mensagem = mensagem
                .replace(/{membro}/g, `<@${member.id}>`)
                .replace(/{servidor}/g, member.guild.name)
                .replace(/{total}/g, member.guild.memberCount.toString());

            const components = [];

            if (data.botao?.ativo && data.botao?.texto && data.botao?.link) {
                const botaoRow = new ActionRowBuilder();
                const botao = new ButtonBuilder()
                    .setLabel(data.botao.texto)
                    .setURL(data.botao.link)
                    .setStyle(5);

                if (data.botao.emoji) {
                    const emojiMatch = data.botao.emoji.match(/:(\d+)>/);
                    if (emojiMatch) {
                        botao.setEmoji(emojiMatch[1]);
                    } else {
                        botao.setEmoji(data.botao.emoji);
                    }
                }

                botaoRow.addComponents(botao);
                components.push(botaoRow);
            }

            const messageOptions = {
                content: mensagem,
                components: components
            };

            if (data.modo === 'dm') {
                try {
                    await member.send(messageOptions);
                    console.log(`[BoasVindas] Mensagem enviada na DM de ${member.user.tag}`);
                } catch (error) {
                    console.error(`[BoasVindas] Erro ao enviar DM para ${member.user.tag}:`, error);
                }
                return;
            }

            if (data.modo === 'canal') {
                if (!data.canaisIds || data.canaisIds.length === 0) return;

                for (const canalId of data.canaisIds) {
                    const canal = member.guild.channels.cache.get(canalId);
                    if (!canal) continue;

                    try {
                        const msg = await canal.send(messageOptions);
                        console.log(`[BoasVindas] Mensagem enviada no canal ${canal.name} para ${member.user.tag}`);

                        if (data.exclusaoAutomatica && data.tempoExclusao > 0) {
                            setTimeout(async () => {
                                try {
                                    await msg.delete();
                                    console.log(`[BoasVindas] Mensagem deletada após ${data.tempoExclusao} segundos no canal ${canal.name}`);
                                } catch (error) {
                                    console.error('[BoasVindas] Erro ao deletar mensagem:', error);
                                }
                            }, data.tempoExclusao * 1000);
                        }
                    } catch (error) {
                        console.error(`[BoasVindas] Erro ao enviar mensagem no canal ${canal.name}:`, error);
                    }
                }
            }

        } catch (error) {
            console.error('[BoasVindasExecutor] Erro:', error);
        }
    }
};
