const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
const { EmojisHelper } = require("../../DataBaseJson");
const { loadReacoesData, saveReacoesData, painelReacoesAutomaticas } = require("./reacoesautomaticas");

const Emojis = EmojisHelper;

module.exports = {
    name: 'interactionCreate',
    run: async (interaction, client) => {
        try {
            if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_emojis_reacao_')) {
                const canalId = interaction.customId.replace('modal_emojis_reacao_', '');
                const emojisInput = interaction.fields.getTextInputValue('emojis').trim();

                const emojisArray = emojisInput.split(/\s+/).filter(e => e.trim());
                const emojisValidos = [];
                const erros = [];

                for (const emoji of emojisArray) {
                    const emojiTrimmed = emoji.trim();
                    if (!emojiTrimmed) continue;

                    const customEmojiMatch = emojiTrimmed.match(/<(a)?:(\w+):(\d+)>/);
                    if (customEmojiMatch) {
                        const emojiId = customEmojiMatch[3];
                        const emojiDoServidor = interaction.guild.emojis.cache.get(emojiId);
                        
                        if (emojiDoServidor) {
                            emojisValidos.push(emojiTrimmed);
                        } else {
                            erros.push(`Emoji ${emojiTrimmed} não encontrado no servidor`);
                        }
                        continue;
                    }

                    if (/^\d{17,20}$/.test(emojiTrimmed)) {
                        const emojiDoServidor = interaction.guild.emojis.cache.get(emojiTrimmed);
                        
                        if (emojiDoServidor) {
                            emojisValidos.push(emojiDoServidor.animated ? `<a:${emojiDoServidor.name}:${emojiDoServidor.id}>` : `<:${emojiDoServidor.name}:${emojiDoServidor.id}>`);
                        } else {
                            erros.push(`Emoji com ID ${emojiTrimmed} não encontrado no servidor`);
                        }
                        continue;
                    }

                    const nomeEmojiMatch = emojiTrimmed.match(/^:(\w+):$/);
                    if (nomeEmojiMatch) {
                        const nomeEmoji = nomeEmojiMatch[1];
                        const emojiDoServidor = interaction.guild.emojis.cache.find(e => e.name.toLowerCase() === nomeEmoji.toLowerCase());
                        
                        if (emojiDoServidor) {
                            emojisValidos.push(emojiDoServidor.animated ? `<a:${emojiDoServidor.name}:${emojiDoServidor.id}>` : `<:${emojiDoServidor.name}:${emojiDoServidor.id}>`);
                        } else {
                            erros.push(`Emoji :${nomeEmoji}: não encontrado no servidor`);
                        }
                        continue;
                    }

                    if (/^[a-zA-Z0-9_]+$/.test(emojiTrimmed)) {
                        const emojiDoServidor = interaction.guild.emojis.cache.find(e => e.name.toLowerCase() === emojiTrimmed.toLowerCase());
                        
                        if (emojiDoServidor) {
                            emojisValidos.push(emojiDoServidor.animated ? `<a:${emojiDoServidor.name}:${emojiDoServidor.id}>` : `<:${emojiDoServidor.name}:${emojiDoServidor.id}>`);
                        } else {
                            erros.push(`Emoji "${emojiTrimmed}" não encontrado no servidor`);
                        }
                        continue;
                    }

                    const emojiRegex = /^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F|\p{Emoji})$/u;
                    if (emojiRegex.test(emojiTrimmed)) {
                        emojisValidos.push(emojiTrimmed);
                        continue;
                    }

                    erros.push(`"${emojiTrimmed}" não é um formato válido`);
                }

                if (erros.length > 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative') || '❌'} Erros encontrados:\n${erros.map(e => `- ${e}`).join('\n')}\n\n**Formatos aceitos:**\n- Emoji padrão: 😀 👍 ❤️\n- Menção completa: <:nome:123456789>\n- Apenas ID: 123456789\n- Nome com dois pontos: :nome:\n- Apenas nome: nome`,
                        ephemeral: true
                    });
                }

                if (emojisValidos.length === 0) {
                    return interaction.reply({
                        content: `${Emojis.get('negative') || '❌'} Nenhum emoji válido foi fornecido!`,
                        ephemeral: true
                    });
                }

                const data = loadReacoesData();
                
                if (!data.configs) {
                    data.configs = [];
                }
                
                const configExistente = data.configs.find(c => c.canalId === canalId);
                if (configExistente) {
                    return interaction.reply({
                        content: `${Emojis.get('negative') || '❌'} Já existe uma configuração para este canal! Delete a configuração existente primeiro.`,
                        ephemeral: true
                    });
                }

                data.configs.push({
                    canalId: canalId,
                    emojis: emojisValidos
                });

                saveReacoesData(data);

                await interaction.deferUpdate();
                await painelReacoesAutomaticas(interaction, client);
            }

            if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_confirmar_excluir_')) {
                const canalId = interaction.customId.replace('modal_confirmar_excluir_', '');
                const confirmacao = interaction.fields.getTextInputValue('confirmacao').trim().toLowerCase();

                if (confirmacao !== 'confirmar') {
                    return interaction.reply({
                        content: `${Emojis.get('negative') || '❌'} Exclusão cancelada. Você precisa digitar "confirmar" para excluir.`,
                        ephemeral: true
                    });
                }

                const data = loadReacoesData();
                data.configs = data.configs.filter(c => c.canalId !== canalId);
                saveReacoesData(data);

                await interaction.deferUpdate();
                await painelReacoesAutomaticas(interaction, client);
            }

            if (interaction.isStringSelectMenu() && interaction.customId === 'select_excluir_reacao') {
                const canalId = interaction.values[0];
                
                const modal = new ModalBuilder()
                    .setCustomId(`modal_confirmar_excluir_${canalId}`)
                    .setTitle('Confirmar Exclusão');

                modal.addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('confirmacao')
                            .setLabel('Digite "confirmar" para excluir')
                            .setStyle(TextInputStyle.Short)
                            .setPlaceholder('confirmar')
                            .setRequired(true)
                    )
                );

                await interaction.showModal(modal);
            }
        } catch (error) {
            console.error('[ReacoesHandler] Erro:', error);
        }
    }
};
