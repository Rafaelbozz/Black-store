const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');

const Emojis = EmojisHelper;
const reacoesPath = path.resolve(__dirname, '../../DataBaseJson/reacoes.json');

function loadReacoesData() {
    try {
        if (fs.existsSync(reacoesPath)) {
            const data = JSON.parse(fs.readFileSync(reacoesPath, 'utf8'));
            if (!data.configs) data.configs = [];
            if (typeof data.ativo !== 'boolean') data.ativo = false;
            return data;
        }
    } catch (e) {
        console.error('[ReacoesAuto] Erro ao carregar dados:', e);
    }
    return { ativo: false, configs: [] };
}

function saveReacoesData(data) {
    try {
        fs.writeFileSync(reacoesPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[ReacoesAuto] Erro ao salvar dados:', e);
    }
}

async function painelReacoesAutomaticas(interaction, client) {
    const data = loadReacoesData();
    const statusAtual = data.ativo || false;
    const configs = data.configs || [];

    const rowBotoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusAtual ? "desativar_reacoes_auto" : "ativar_reacoes_auto")
            .setLabel(statusAtual ? 'Desativar' : 'Ativar')
            .setEmoji(statusAtual ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusAtual ? 4 : 3),
        new ButtonBuilder()
            .setCustomId("adicionar_config_reacao")
            .setLabel('Adicionar Configuração')
            .setEmoji(Emojis.get('_add_emoji'))
            .setStyle(1),
        new ButtonBuilder()
            .setCustomId("apagar_config_reacao")
            .setLabel('Apagar Configuração')
            .setEmoji(Emojis.get('_trash_emoji'))
            .setStyle(4)
            .setDisabled(configs.length === 0)
    );

    const rowBotoes2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("visualizar_configs_reacao")
            .setLabel('Visualizar Configurações')
            .setEmoji(Emojis.get('dowloademoji'))
            .setStyle(2)
            .setDisabled(configs.length === 0)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Reações Automáticas` },
        { type: 14 },
        { type: 10, content: `## ${Emojis.get('reactiona') || '⚡'} Sistema de Reações Automáticas\n\n> Configure reações automáticas em mensagens de canais específicos.\n> O bot irá reagir automaticamente com os emojis configurados.` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusAtual ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Reações Configuradas: \`${configs.length}\`` },
        { type: 14 }
    ).with({
        components: [rowBotoes, rowBotoes2, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function visualizarConfiguracoes(interaction, client) {
    const data = loadReacoesData();
    const configs = data.configs || [];

    if (configs.length === 0) {
        return interaction.reply({
            content: `${Emojis.get('negative') || '❌'} Nenhuma configuração encontrada.`,
            ephemeral: true
        });
    }

    let configsList = '# Configurações\n\n';
    configs.forEach((config, index) => {
        const canal = client.channels.cache.get(config.canalId);
        const canalNome = canal ? `<#${config.canalId}>` : '`Canal não encontrado`';
        const emojis = config.emojis.join(' ');
        
        configsList += `**Config ${index + 1}**\n`;
        configsList += `- Canal: ${canalNome}\n`;
        configsList += `- Emojis: ${emojis}\n\n`;
    });

    await interaction.reply({
        content: configsList,
        ephemeral: true
    });
}

async function painelSelecionarCanal(interaction) {
    const { ChannelSelectMenuBuilder, ChannelType } = require("discord.js");

    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canal_reacao")
            .setPlaceholder("Selecione um canal")
            .setChannelTypes([ChannelType.GuildText])
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_painel_reacoes")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Reações Automáticas > Adicionar` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canal\n\n> Escolha o canal onde as reações automáticas serão aplicadas.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

async function painelExcluirConfig(interaction, client) {
    const { StringSelectMenuBuilder } = require("discord.js");
    const data = loadReacoesData();
    const configs = data.configs || [];

    if (configs.length === 0) {
        return interaction.reply({
            content: `${Emojis.get('negative') || '❌'} Nenhuma configuração para excluir.`,
            ephemeral: true
        });
    }

    const options = configs.map((config, index) => {
        const canal = client.channels.cache.get(config.canalId);
        const canalNome = canal ? `#${canal.name}` : 'Canal não encontrado';
        
        return {
            label: `Config ${index + 1} - ${canalNome}`,
            description: `Emojis: ${config.emojis.slice(0, 3).join(' ')}${config.emojis.length > 3 ? '...' : ''}`,
            value: config.canalId
        };
    });

    const rowSelect = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId("select_excluir_reacao")
            .setPlaceholder("Selecione uma configuração para excluir")
            .addOptions(options)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_painel_reacoes")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Reações Automáticas > Excluir` },
        { type: 14 },
        { type: 10, content: `## Excluir Configuração\n\n> Selecione a configuração que deseja remover.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    painelReacoesAutomaticas,
    visualizarConfiguracoes,
    painelSelecionarCanal,
    painelExcluirConfig,
    loadReacoesData,
    saveReacoesData
};
