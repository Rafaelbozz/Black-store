const { loadInvitesData } = require("./invitetracker");
const { GuildsInvites } = require("../../DataBaseJson");

module.exports = {
    name: 'guildMemberAdd',
    run: async (member) => {
        try {
            const data = loadInvitesData();
            
            if (!data.ativo) return;
            
            if (!data.canalId) return;

            const canal = member.guild.channels.cache.get(data.canalId);
            if (!canal) return;

            const novosConvites = await member.guild.invites.fetch();
            const invitesCache = global.invitesCache || new Map();
            const convitesAntigos = invitesCache.get(member.guild.id) || new Map();

            let conviteUsado = null;
            let isVanity = false;

            for (const [code, invite] of novosConvites) {
                const usosAntigos = convitesAntigos.get(code) || 0;
                
                if (invite.uses > usosAntigos) {
                    conviteUsado = invite;
                    break;
                }
            }

            if (!conviteUsado && member.guild.vanityURLCode) {
                const vanityInvite = novosConvites.find(inv => inv.code === member.guild.vanityURLCode);
                if (vanityInvite) {
                    isVanity = true;
                    conviteUsado = vanityInvite;
                }
            }

            invitesCache.set(member.guild.id, new Map(novosConvites.map(invite => [invite.code, invite.uses])));
            global.invitesCache = invitesCache;

            if (conviteUsado) {
                const convidadorId = conviteUsado.inviter?.id || 'Desconhecido';
                GuildsInvites.set(`${member.guild.id}.${member.id}`, {
                    inviterId: convidadorId,
                    inviterTag: conviteUsado.inviter?.tag || 'Desconhecido',
                    inviteCode: conviteUsado.code,
                    joinedAt: Date.now()
                });

                const convitesDoConvidador = GuildsInvites.get(`${member.guild.id}.invites.${convidadorId}`) || 0;
                GuildsInvites.set(`${member.guild.id}.invites.${convidadorId}`, convitesDoConvidador + 1);
            }

            let mensagem = isVanity ? data.mensagemEntradaVanity : data.mensagemEntradaNormal;
            
            const convidador = conviteUsado?.inviter?.tag || 'Desconhecido';
            const convidadorId = conviteUsado?.inviter?.id || 'Desconhecido';
            const totalConvites = GuildsInvites.get(`${member.guild.id}.invites.${convidadorId}`) || 0;

            mensagem = mensagem
                .replace(/{membro}/g, `<@${member.id}>`)
                .replace(/{convidador}/g, convidador)
                .replace(/{convites}/g, totalConvites.toString());

            await canal.send({ content: mensagem });

            console.log(`[InviteTracker] ${member.user.tag} entrou - Convidado por ${convidador}`);

        } catch (error) {
            console.error('[InviteTracker] Erro ao processar entrada de membro:', error);
        }
    }
};
