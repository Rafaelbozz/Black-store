const { loadInvitesData } = require("./invitetracker");
const { GuildsInvites } = require("../../DataBaseJson");

module.exports = {
    name: 'guildMemberRemove',
    run: async (member) => {
        try {
            const data = loadInvitesData();
            
            if (!data.ativo) return;
            
            if (!data.canalId) return;

            const canal = member.guild.channels.cache.get(data.canalId);
            if (!canal) return;

            const inviteData = GuildsInvites.get(`${member.guild.id}.${member.id}`);
            
            if (inviteData) {
                const convidador = inviteData.inviterTag || 'Desconhecido';
                const convidadorId = inviteData.inviterId;
                
                const convitesDoConvidador = GuildsInvites.get(`${member.guild.id}.invites.${convidadorId}`) || 0;
                if (convitesDoConvidador > 0) {
                    GuildsInvites.set(`${member.guild.id}.invites.${convidadorId}`, convitesDoConvidador - 1);
                }

                const totalConvites = GuildsInvites.get(`${member.guild.id}.invites.${convidadorId}`) || 0;

                let mensagem = data.mensagemSaida
                    .replace(/{membro}/g, member.user.tag)
                    .replace(/{convidador}/g, convidador)
                    .replace(/{convites}/g, totalConvites.toString());

                await canal.send({ content: mensagem });

                console.log(`[InviteTracker] ${member.user.tag} saiu - Convidado por ${convidador}`);

                GuildsInvites.delete(`${member.guild.id}.${member.id}`);
            }

        } catch (error) {
            console.error('[InviteTracker] Erro ao processar saída de membro:', error);
        }
    }
};
