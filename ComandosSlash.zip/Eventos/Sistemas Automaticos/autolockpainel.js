const { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const { EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

const Emojis = EmojisHelper;
const autolockPath = path.resolve(__dirname, '../../DataBaseJson/autolock.json');

function loadAutolockData(guildId) {
    try {
        if (fs.existsSync(autolockPath)) {
            const allData = JSON.parse(fs.readFileSync(autolockPath, 'utf8'));
            return allData[guildId] || {
                ativo: false,
                horarioBloquear: "00:00",
                horarioDesbloquear: "08:00",
                canais: []
            };
        }
    } catch (e) {
        console.error('[AutoLock] Erro ao carregar dados:', e);
    }
    return {
        ativo: false,
        horarioBloquear: "00:00",
        horarioDesbloquear: "08:00",
        canais: []
    };
}

function saveAutolockData(guildId, data) {
    try {
        let allData = {};
        if (fs.existsSync(autolockPath)) {
            allData = JSON.parse(fs.readFileSync(autolockPath, 'utf8'));
        }
        
        if (data === null) {
            delete allData[guildId];
        } else {
            allData[guildId] = data;
        }
        
        fs.writeFileSync(autolockPath, JSON.stringify(allData, null, 2));
    } catch (e) {
        console.error('[AutoLock] Erro ao salvar dados:', e);
    }
}

async function painelAutoLock(interaction, client) {
    const guildId = interaction.guild.id;
    const data = loadAutolockData(guildId);
    const statusSistema = data.ativo || false;
    const horarioBloquear = data.horarioBloquear || "00:00";
    const horarioDesbloquear = data.horarioDesbloquear || "08:00";
    const canaisConfig = data.canais || [];

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hoursBlock, minutesBlock] = horarioBloquear.split(':').map(Number);
    let nextBlockTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hoursBlock, 
        minute: minutesBlock, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextBlockTime.isBefore(currentTime)) {
        nextBlockTime.add(1, 'day');
    }
    
    const nextBlockTimestamp = Math.floor(nextBlockTime.valueOf() / 1000);

    const [hoursUnblock, minutesUnblock] = horarioDesbloquear.split(':').map(Number);
    let nextUnblockTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hoursUnblock, 
        minute: minutesUnblock, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextUnblockTime.isBefore(currentTime)) {
        nextUnblockTime.add(1, 'day');
    }
    
    const nextUnblockTimestamp = Math.floor(nextUnblockTime.valueOf() / 1000);

    let canaisTexto = '`Nenhum canal configurado`';
    if (canaisConfig.length > 0) {
        canaisTexto = canaisConfig.map(id => `<#${id}>`).join(', ');
    }

    const rowBotoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusSistema ? "desativar_autolock" : "ativar_autolock")
            .setLabel(statusSistema ? 'Desativar' : 'Ativar')
            .setEmoji(statusSistema ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusSistema ? 4 : 3),
        new ButtonBuilder()
            .setCustomId("definir_horarios_autolock")
            .setLabel('Definir Horários')
            .setEmoji(Emojis.get('relogio'))
            .setStyle(2)
            .setDisabled(!statusSistema),
        new ButtonBuilder()
            .setCustomId("definir_canais_autolock")
            .setLabel('Definir Canais')
            .setEmoji(Emojis.get('logss'))
            .setStyle(2)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Lock Automático` },
        { type: 14 },
        { type: 10, content: `##  Sistema de Lock Automático\n\n> Configure o sistema para bloquear e desbloquear canais automaticamente em horários específicos.\n> O sistema limpa as mensagens ao bloquear e desbloquear os canais.` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusSistema ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Horário de Bloqueio: \`${horarioBloquear}\` (Horário de Brasília)\n- Horário de Desbloqueio: \`${horarioDesbloquear}\` (Horário de Brasília)\n- Canais configurados: \`${canaisConfig.length}\`\n- Próximo bloqueio: ${statusSistema ? `\`${nextBlockTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '\`Desativado\`'}\n- Tempo até bloqueio: ${statusSistema ? `<t:${nextBlockTimestamp}:R>` : '\`Desativado\`'}\n- Próximo desbloqueio: ${statusSistema ? `\`${nextUnblockTime.format('DD/MM/YYYY HH:mm:ss')}\`` : '\`Desativado\`'}\n- Tempo até desbloqueio: ${statusSistema ? `<t:${nextUnblockTimestamp}:R>` : '\`Desativado\`'}` },
        { type: 14 },
        { type: 10, content: `**Canais:**\n${canaisTexto}` },
        { type: 14 }
    ).with({
        components: [rowBotoes, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function painelDefinirCanaisAutolock(interaction) {
    const guildId = interaction.guild.id;
    const data = loadAutolockData(guildId);
    
    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canais_autolock")
            .setPlaceholder("Selecione os canais para lock automático")
            .setChannelTypes([ChannelType.GuildText])
            .setMinValues(0)
            .setMaxValues(25)
            .setDefaultChannels(data.canais || [])
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_autolock")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Lock Automático > Definir Canais` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canais\n\n> Escolha os canais que serão bloqueados e desbloqueados automaticamente nos horários configurados.\n> Você pode selecionar múltiplos canais.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    painelAutoLock,
    painelDefinirCanaisAutolock,
    loadAutolockData,
    saveAutolockData
};
