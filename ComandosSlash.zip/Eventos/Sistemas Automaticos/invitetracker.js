const { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const { EmojisHelper, GuildsInvites } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');

const Emojis = EmojisHelper;
const invitesPath = path.resolve(__dirname, '../../DataBaseJson/invitetracker.json');

function loadInvitesData() {
    try {
        if (fs.existsSync(invitesPath)) {
            return JSON.parse(fs.readFileSync(invitesPath, 'utf8'));
        }
    } catch (e) {
        console.error('[InviteTracker] Erro ao carregar dados:', e);
    }
    return {
        ativo: false,
        canalId: null,
        mensagemEntradaNormal: "Seja bem-vindo(a) {membro}! Você foi convidado(a) por {convidador} que já agora possui {convites} convites válidos.",
        mensagemEntradaVanity: "Seja bem-vindo(a) {membro}! Você entrou através da Vanity URL do servidor.",
        mensagemSaida: "Que pena, {membro} nos deixou. Ele(a) foi convidado(a) por {convidador} que agora possui {convites} convites válidos."
    };
}

function saveInvitesData(data) {
    try {
        fs.writeFileSync(invitesPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[InviteTracker] Erro ao salvar dados:', e);
    }
}

async function painelInviteTracker(interaction, client) {
    const data = loadInvitesData();
    const statusAtual = data.ativo || false;
    const canalConfigurado = data.canalId ? `<#${data.canalId}>` : '`Não configurado`';

    const rowBotoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusAtual ? "desativar_invite_tracker" : "ativar_invite_tracker")
            .setLabel(statusAtual ? 'Desativar' : 'Ativar')
            .setEmoji(statusAtual ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusAtual ? 4 : 3),
        new ButtonBuilder()
            .setCustomId("definir_canal_invite")
            .setLabel('Definir Canal')
            .setEmoji(Emojis.get('logss'))
            .setStyle(2),
        new ButtonBuilder()
            .setCustomId("configurar_msgs_invite")
            .setLabel('Configurar Mensagens')
            .setEmoji(Emojis.get('_lapis_emoji'))
            .setStyle(2)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Rastreador de Invites` },
        { type: 14 },
        { type: 10, content: `##  Sistema de Rastreamento de Convites\n\n> Rastreie quem convidou cada membro que entra no servidor.\n> Envie mensagens personalizadas quando membros entram ou saem.` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusAtual ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Canal de Logs: ${canalConfigurado}` },
        { type: 14 },
        { type: 10, content: `**Variáveis Disponíveis**\n- \`\`{membro}\`\` - Mencionar membro novo\n- \`\`{convidador}\`\` - Nome do convidador\n- \`\`{convites}\`\` - Total de convites válidos` },
        { type: 14 }
    ).with({
        components: [rowBotoes, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function painelDefinirCanal(interaction) {
    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canal_invite")
            .setPlaceholder("Selecione o canal de logs")
            .setChannelTypes([ChannelType.GuildText])
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_invite_tracker")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Rastreador de Invites > Definir Canal` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canal\n\n> Escolha o canal onde as mensagens de entrada/saída serão enviadas.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    painelInviteTracker,
    painelDefinirCanal,
    loadInvitesData,
    saveInvitesData
};
