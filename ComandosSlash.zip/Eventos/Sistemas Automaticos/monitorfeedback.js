const { ActionRowBuilder, ButtonBuilder, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
const { EmojisHelper, configuracao } = require("../../DataBaseJson");
const { res } = require("../../res");
const fs = require('fs');
const path = require('path');

const Emojis = EmojisHelper;
const monitorFeedbackPath = path.resolve(__dirname, '../../DataBaseJson/monitorfeedback.json');

function loadMonitorData() {
    try {
        if (fs.existsSync(monitorFeedbackPath)) {
            return JSON.parse(fs.readFileSync(monitorFeedbackPath, 'utf8'));
        }
    } catch (e) {
        console.error('[MonitorFeedback] Erro ao carregar dados:', e);
    }
    return {
        ativo: false,
        canalLogs: null
    };
}

function saveMonitorData(data) {
    try {
        fs.writeFileSync(monitorFeedbackPath, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('[MonitorFeedback] Erro ao salvar dados:', e);
    }
}

async function painelMonitorFeedback(interaction, client) {
    const data = loadMonitorData();
    const statusSistema = data.ativo || false;
    const canalLogsConfig = data.canalLogs ? `<#${data.canalLogs}>` : '`Não configurado`';
    
    const canalFeedback = configuracao.get('ConfigChannels.feedback');
    const canalFeedbackTexto = canalFeedback ? `<#${canalFeedback}>` : '`Não configurado`';
    const podeAtivar = !!canalFeedback;

    const rowBotoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(statusSistema ? "desativar_monitor_feedback" : "ativar_monitor_feedback")
            .setLabel(statusSistema ? 'Desativar' : 'Ativar')
            .setEmoji(statusSistema ? Emojis.get('desligado') : Emojis.get('ligado'))
            .setStyle(statusSistema ? 4 : 3)
            .setDisabled(!podeAtivar),
        new ButtonBuilder()
            .setCustomId("definir_canal_logs_feedback")
            .setLabel('Definir Canal de Logs')
            .setEmoji(Emojis.get('logss'))
            .setStyle(2)
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltarautomaticos")
            .setEmoji(Emojis.get('_back_emoji'))
            .setLabel('Voltar')
            .setStyle(2)
    );

    let avisoCanal = '';
    if (!podeAtivar) {
        avisoCanal = '\n\n⚠️ **Atenção:** Configure o canal de feedbacks primeiro em Definiçoes > Canal de Feedback';
    }

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Monitorador de Feedbacks` },
        { type: 14 },
        { type: 10, content: `##  Sistema de Monitoramento de Feedbacks\n\n> Monitore automaticamente feedbacks negativos enviados no canal de feedbacks.\n> O sistema analisa mensagens e alerta sobre feedbacks negativos ou extremos.${avisoCanal}` },
        { type: 14 },
        { type: 10, content: `**Informações Detalhadas**\n- Sistema: ${statusSistema ? '``🟢 Ativado``' : '``🔴 Desativado``'}\n- Canal de Feedbacks: ${canalFeedbackTexto}\n- Canal de Logs: ${canalLogsConfig}` },
        { type: 14 },
        { type: 10, content: `**Funcionalidades:**\n- Análise automática de feedbacks negativos\n- Exclusão automática de feedbacks extremamente negativos\n- Alertas no canal de logs com botões de ação\n- Botões: Deletar Mensagem | Ir até a Mensagem` },
        { type: 14 }
    ).with({
        components: [rowBotoes, rowVoltar],
        flags: [64]
    });

    if (interaction.deferred || interaction.replied) {
        await interaction.editReply(containerContent);
    } else {
        await interaction.update(containerContent);
    }
}

async function painelDefinirCanalLogs(interaction) {
    const rowSelect = new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
            .setCustomId("select_canal_logs_feedback")
            .setPlaceholder("Selecione o canal de logs")
            .setChannelTypes([ChannelType.GuildText])
    );

    const rowVoltar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar_monitor_feedback")
            .setLabel('Voltar')
            .setStyle(2)
    );

    const containerContent = res.main(
        { type: 10, content: `-# Painel > Ações Automáticas > Monitor Feedback > Definir Canal de Logs` },
        { type: 14 },
        { type: 10, content: `## Selecionar Canal de Logs\n\n> Escolha o canal onde os alertas de feedbacks negativos serão enviados.` },
        { type: 14 }
    ).with({
        components: [rowSelect, rowVoltar],
        flags: [64]
    });

    await interaction.update(containerContent);
}

module.exports = {
    painelMonitorFeedback,
    painelDefinirCanalLogs,
    loadMonitorData,
    saveMonitorData
};
