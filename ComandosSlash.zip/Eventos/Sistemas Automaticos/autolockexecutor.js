const { loadAutolockData } = require("./autolockpainel");
const { ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { configuracao } = require("../../DataBaseJson");
const moment = require('moment-timezone');

let lockTimeouts = new Map();
let unlockTimeouts = new Map();
let checkInterval = null;

async function bloquearCanal(client, guildId, channelId, unlockTime) {
    try {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) return;

        console.log(`[AutoLock] Bloqueando canal ${channel.name}`);

        await channel.permissionOverwrites.edit(guild.roles.everyone, {
            SendMessages: false
        });

        let messagesDeleted = 0;
        let fetched;
        do {
            fetched = await channel.messages.fetch({ limit: 100 });
            if (fetched.size > 0) {
                messagesDeleted += fetched.size;
                await channel.bulkDelete(fetched);
            }
        } while (fetched.size >= 2);

        const embed_delet = new EmbedBuilder()
            .setColor(configuracao.get(`Cores.Principal`) || '0cd4cc')
            .setAuthor({ name: 'Limpeza Concluída', iconURL: 'https://media.discordapp.net/attachments/1249514076116353055/1250591781985321072/eu_tambem_tenho_7.png' })
            .setDescription(`Total de \`${messagesDeleted}\` mensagens removidas.`);

        const embed = new EmbedBuilder()
            .setColor(configuracao.get(`Cores.Principal`) || '0cd4cc')
            .setDescription("🔒 Este canal foi trancado automaticamente pelo sistema.")
            .setFooter({ text: `Boa noite! Volte novamente às ${unlockTime}` })
            .setTimestamp();

        await channel.send({
            embeds: [embed_delet, embed],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel("Mensagem Automática")
                        .setCustomId("disabledButton")
                        .setStyle(2)
                        .setDisabled(true)
                )
            ]
        });

        console.log(`[AutoLock] Canal ${channel.name} bloqueado com sucesso!`);
    } catch (error) {
        console.error(`[AutoLock] Erro ao bloquear canal ${channelId}:`, error);
    }
}

async function desbloquearCanal(client, guildId, channelId) {
    try {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;

        const channel = guild.channels.cache.get(channelId);
        if (!channel || channel.type !== ChannelType.GuildText) return;

        console.log(`[AutoLock] Desbloqueando canal ${channel.name}`);

        await channel.permissionOverwrites.edit(guild.roles.everyone, {
            SendMessages: true
        });

        let messagesDeleted = 0;
        const messages = await channel.messages.fetch({ limit: 100 });
        if (messages.size > 0) {
            messagesDeleted = messages.size;
            await channel.bulkDelete(messages);
        }

        const embed = new EmbedBuilder()
            .setColor(configuracao.get(`Cores.Principal`) || '0cd4cc')
            .setDescription("🔓 Este canal foi liberado automaticamente pelo sistema.")
            .setFooter({ text: `Bom dia!` })
            .setTimestamp();

        await channel.send({
            embeds: [embed],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel("Mensagem Automática")
                        .setCustomId("disabledButton")
                        .setStyle(2)
                        .setDisabled(true)
                )
            ]
        });

        console.log(`[AutoLock] Canal ${channel.name} desbloqueado com sucesso!`);
    } catch (error) {
        console.error(`[AutoLock] Erro ao desbloquear canal ${channelId}:`, error);
    }
}

function agendarBloqueio(client, guildId, data) {
    if (lockTimeouts.has(guildId)) {
        for (const timeout of lockTimeouts.get(guildId)) {
            clearTimeout(timeout);
        }
    }

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hours, minutes] = data.horarioBloquear.split(':').map(Number);
    
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hours, 
        minute: minutes, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextExecutionTime.isSameOrBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const msUntilExecution = nextExecutionTime.diff(currentTime);
    
    console.log(`[AutoLock] Bloqueio agendado para ${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')} (em ${Math.round(msUntilExecution / 1000 / 60)} minutos)`);
    
    const timeouts = [];
    for (const channelId of data.canais) {
        const timeout = setTimeout(() => {
            bloquearCanal(client, guildId, channelId, data.horarioDesbloquear);
            setTimeout(() => agendarBloqueio(client, guildId, data), 1000);
        }, msUntilExecution);
        timeouts.push(timeout);
    }
    
    lockTimeouts.set(guildId, timeouts);
}

function agendarDesbloqueio(client, guildId, data) {
    if (unlockTimeouts.has(guildId)) {
        for (const timeout of unlockTimeouts.get(guildId)) {
            clearTimeout(timeout);
        }
    }

    const currentTime = moment.tz("America/Sao_Paulo");
    const [hours, minutes] = data.horarioDesbloquear.split(':').map(Number);
    
    let nextExecutionTime = moment.tz("America/Sao_Paulo").set({ 
        hour: hours, 
        minute: minutes, 
        second: 0, 
        millisecond: 0 
    });
    
    if (nextExecutionTime.isSameOrBefore(currentTime)) {
        nextExecutionTime.add(1, 'day');
    }
    
    const msUntilExecution = nextExecutionTime.diff(currentTime);
    
    console.log(`[AutoLock] Desbloqueio agendado para ${nextExecutionTime.format('DD/MM/YYYY HH:mm:ss')} (em ${Math.round(msUntilExecution / 1000 / 60)} minutos)`);
    
    const timeouts = [];
    for (const channelId of data.canais) {
        const timeout = setTimeout(() => {
            desbloquearCanal(client, guildId, channelId);
            setTimeout(() => agendarDesbloqueio(client, guildId, data), 1000);
        }, msUntilExecution);
        timeouts.push(timeout);
    }
    
    unlockTimeouts.set(guildId, timeouts);
}

function iniciarAutoLock(client, guildId) {
    const data = loadAutolockData(guildId);
    
    if (!data.ativo || !data.canais || data.canais.length === 0) {
        console.log(`[AutoLock] Sistema desativado para guild ${guildId}`);
        return;
    }

    agendarBloqueio(client, guildId, data);
    agendarDesbloqueio(client, guildId, data);
    
    console.log(`[AutoLock] Sistema iniciado para guild ${guildId}`);
}

function pararAutoLock(guildId) {
    if (lockTimeouts.has(guildId)) {
        for (const timeout of lockTimeouts.get(guildId)) {
            clearTimeout(timeout);
        }
        lockTimeouts.delete(guildId);
    }
    
    if (unlockTimeouts.has(guildId)) {
        for (const timeout of unlockTimeouts.get(guildId)) {
            clearTimeout(timeout);
        }
        unlockTimeouts.delete(guildId);
    }
    
    console.log(`[AutoLock] Sistema parado para guild ${guildId}`);
}

function iniciarAutoLockGlobal(client) {
    if (checkInterval) {
        clearInterval(checkInterval);
    }

    for (const guild of client.guilds.cache.values()) {
        const data = loadAutolockData(guild.id);
        if (data.ativo) {
            iniciarAutoLock(client, guild.id);
        }
    }

    checkInterval = setInterval(async () => {
        const currentTime = moment.tz("America/Sao_Paulo");
        const currentHour = currentTime.format('HH:mm');

        for (const guild of client.guilds.cache.values()) {
            const data = loadAutolockData(guild.id);
            
            if (!data.ativo || !data.canais || data.canais.length === 0) continue;

            if (currentHour === data.horarioBloquear) {
                console.log(`[AutoLock] Verificação de 1 minuto - Bloqueando canais da guild ${guild.id}`);
                for (const channelId of data.canais) {
                    await bloquearCanal(client, guild.id, channelId, data.horarioDesbloquear);
                }
            }

            if (currentHour === data.horarioDesbloquear) {
                console.log(`[AutoLock] Verificação de 1 minuto - Desbloqueando canais da guild ${guild.id}`);
                for (const channelId of data.canais) {
                    await desbloquearCanal(client, guild.id, channelId);
                }
            }
        }
    }, 60000);

    console.log('[AutoLock] Sistema global iniciado');
}

module.exports = {
    iniciarAutoLock,
    pararAutoLock,
    iniciarAutoLockGlobal
};
