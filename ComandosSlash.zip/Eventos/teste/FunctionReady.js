const fs = require('fs');
const path = require('path');
const { ActivityType, EmbedBuilder } = require('discord.js');
const { carregarCache } = require('../../Handler/EmojiFunctions');
const { VerificarPagamento } = require('../../Functions/VerficarPagamento');
const { EntregarPagamentos } = require('../../Functions/AprovarPagamento');
const { VerificarPagamentoRobux } = require('../../Functions/VerificarPagamentoRobux');
const { configuracao, produtos, BackupStorage } = require('../../DataBaseJson');
const { SincronizarDados } = require('../../Functions/SincronizarDados.js');
const { restart } = require('../../Functions/Restart.js');
const { Varredura } = require('../../Functions/Varredura.js');
const { iniciarNukeAutomatico } = require('../Sistemas Automaticos/nukeexecutor.js');
const { loadNukeData } = require('../Sistemas Automaticos/nukeautomatico.js');
const { iniciarAutoLockGlobal } = require('../Sistemas Automaticos/autolockexecutor.js');
const { iniciarLimpezaAutomatica } = require('../Sistemas Automaticos/limpezaexecutor.js');
const { loadLimpezaData } = require('../Sistemas Automaticos/limpezaautomatica.js');
const emojis = require('../../DataBaseJson/emojis.json');

const Emojis = {
    get: (name) => emojis[name] || ""
};

module.exports = {
    name: 'ready',

    run: async (client) => {
        console.clear();

        const configuracoes = ['Status1', 'Status2'];
        let indiceAtual = 0;
        setInterval(() => {
            const status = configuracao.get(configuracoes[indiceAtual]);
            if (status) client.user.setActivity(status, { type: ActivityType.Playing });
            indiceAtual = (indiceAtual + 1) % configuracoes.length;
        }, 5000);

        if (client.guilds.cache.size > 1) {
            client.guilds.cache.forEach(guild => {
                if(guild.id !== "ID_DO_TEU_SERVIDOR_PRINCIPAL") guild.leave().catch(() => null);
            });
        }

        const resetCarrinhos = () => fs.writeFileSync(path.resolve(__dirname, '../../DataBaseJson/carrinhos.json'), '{}');
        const updateBio = () => {
            const bioEmojis = [
                Emojis.get('ilusion0'),
                Emojis.get('ilusion1'),
                Emojis.get('ilusion2'),
                Emojis.get('ilusion3'),
                Emojis.get('ilusion4'),
                Emojis.get('ilusion5'),
                Emojis.get('ilusion6'),
                Emojis.get('ilusion7')
            ].join('');
            
            client.application.edit({ 
                description: `**Tecnologia Nexus Applications**\nhttps://discord.gg/nexusapplications` 
            }).catch(() => null);
        };

        await updateBio();
        resetCarrinhos();
        
        setInterval(() => VerificarPagamento(client), 10000);
        setInterval(() => EntregarPagamentos(client), 14000);
        setInterval(() => VerificarPagamentoRobux(client), 10000);

        restart(client);
        Varredura(client);
        
        console.log('\x1b[36m[Backup Automático]\x1b[0m Executando backup inicial...');
        await executarBackupSeAtivo(client);
        
        setInterval(() => executarBackupSeAtivo(client), 3600000);
        
        setInterval(() => Varredura(client), 86400000);

        const nukeData = loadNukeData();
        if (nukeData.ativo) {
            iniciarNukeAutomatico(client);
            console.log('\x1b[36m[NukeAutomatico]\x1b[0m Sistema iniciado!');
        }

        iniciarAutoLockGlobal(client);
        console.log('\x1b[36m[AutoLock]\x1b[0m Sistema iniciado!');

        const limpezaData = loadLimpezaData();
        if (limpezaData.ativo) {
            iniciarLimpezaAutomatica(client);
            console.log('\x1b[36m[LimpezaAutomatica]\x1b[0m Sistema iniciado!');
        }

        console.log(`\x1b[36m[Log]\x1b[0m ${client.user.tag} Online e Sincronizado!`);
        carregarCache();
    }
};

async function executarBackupSeAtivo(client) {
    try {
        const guilds = client.guilds.cache;
        
        for (const [guildId, guild] of guilds) {
            console.log(`\x1b[36m[Backup Automático]\x1b[0m Executando backup para ${guild.name}`);
            
            try {
                await SincronizarDados(client);
                
                const backupInfo = BackupStorage.get(`BackupInfo_${guildId}`) || {
                    autoBackupEnabled: true,
                    intervalMinutes: 60
                };
                
                backupInfo.lastBackup = Date.now();
                backupInfo.nextBackup = Date.now() + (60 * 60 * 1000);
                backupInfo.autoBackupEnabled = true;
                
                BackupStorage.set(`BackupInfo_${guildId}`, backupInfo);
                
                console.log(`\x1b[36m[Backup Automático]\x1b[32m Backup concluído para ${guild.name}\x1b[0m`);
            } catch (error) {
                console.error(`\x1b[31m[Backup Automático]\x1b[0m Erro ao fazer backup de ${guild.name}:`, error);
            }
        }
    } catch (error) {
        console.error('\x1b[31m[Backup Automático]\x1b[0m Erro no sistema:', error);
    }
}