const { atendimentosAI } = require("../../DataBaseJson");

module.exports = {
    name: 'ready',
    once: true,
    run: async (client) => {
        console.log('[ANTI-ARQUIVAR] Sistema de anti-arquivamento de tickets iniciado');
        
        setInterval(async () => {
            try {
                const todosTickets = atendimentosAI.all();
                
                for (const ticket of todosTickets) {
                    if (!ticket.data || !ticket.ID) continue;
                    
                    const threadId = ticket.ID;
                    
                    for (const guild of client.guilds.cache.values()) {
                        try {
                            const thread = await guild.channels.fetch(threadId).catch(() => null);
                            
                            if (thread && thread.isThread()) {
                                if (thread.archived) {
                                    await thread.setArchived(false);
                                    console.log(`[ANTI-ARQUIVAR] Thread ${threadId} foi desarquivada automaticamente`);
                                }
                                
                                break;
                            }
                        } catch (error) {
                            continue;
                        }
                    }
                }
            } catch (error) {
                console.error('[ANTI-ARQUIVAR] Erro ao verificar tickets:', error);
            }
        }, 20 * 60 * 1000);
    }
};
