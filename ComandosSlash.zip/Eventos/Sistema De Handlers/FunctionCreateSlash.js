const client = require("../../index");
const Discord = require("discord.js")
const { configuracao, EmojisHelper } = require("../../DataBaseJson");
const { res } = require("../../res");

const Emojis = EmojisHelper;

module.exports = {
    name: 'interactionCreate',

    run: async (interaction, client) => {
        if (interaction.isChatInputCommand()) {

            const cmd = client.slashCommands.get(interaction.commandName);

            if (!cmd) return interaction.reply(`Ocorreu algum erro amigo.`);

            interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

            try {
                const logChannelId = configuracao.get(`ConfigChannels.logscomandos`);
                const logChannel = client.channels.cache.get(logChannelId);
                if (logChannel) {
                    const containerContent = res.main(
                        { type: 10, content: `**Nexus Pro - Logs Comandos Slash**` },
                        { type: 14 },
                        { type: 10, content: `${Emojis.get('_camp_emoji')} **Comando:** \`/${interaction.commandName}\`\n${Emojis.get('logsusers')} **Usuario:** \`${interaction.user.tag}\`\n${Emojis.get('textes')} **Canal:** ${interaction.channel}` },
                        { type: 14 },
                        { type: 10, content: `${Emojis.get('calendarlogs')} **Data:** <t:${Math.floor(Date.now() / 1000)}:R>` }
                    ).with({});

                    logChannel.send(containerContent);
                }
            } catch (error) {
                console.error('Erro ao enviar log de comando:', error);
            }

            cmd.run(client, interaction)

        }

        if (interaction.isMessageContextMenuCommand()) {
            const command = client.slashCommands.get(interaction.commandName);
            if (command) command.run(client, interaction);
        }

        if (interaction.isUserContextMenuCommand()) {
            const command = client.slashCommands.get(interaction.commandName);
            if (command) command.run(client, interaction);
        }
    }
}