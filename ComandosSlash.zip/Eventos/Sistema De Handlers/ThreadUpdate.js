const { atendimentosAI } = require("../../DataBaseJson");

module.exports = {
    name: 'threadUpdate',
    run: async (oldThread, newThread) => {
        try {
            const ticketData = atendimentosAI.get(newThread.id);
            
            if (!ticketData) return;
            
            if (!oldThread.archived && newThread.archived) {
                await newThread.setArchived(false);
                console.log(`[ANTI-ARQUIVAR] Ticket ${newThread.id} foi desarquivado automaticamente após tentativa de arquivamento`);
                
                await newThread.send({
                    content: `⚠️ Este ticket não pode ser arquivado automaticamente. Use o botão "Deletar e Salvar" para fechar o atendimento.`
                }).catch(() => {});
            }
        } catch (error) {
            console.error('[THREAD UPDATE] Erro:', error);
        }
    }
};
