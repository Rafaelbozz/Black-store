const { EmojisHelper } = require('../DataBaseJson');
const AllEmojis = require('./emojis.json');
const axios = require('axios');
const fs = require('fs');

async function fetchEmojis(client) {
    const response = await axios.get(`https://discord.com/api/v10/applications/${client.user.id}/emojis`, {
        headers: {
            Authorization: `Bot ${client.token}`
        }
    });
    return response.data.items;
}

async function createEmoji(client, name, image) {
    let response;

    try {
        response = await axios.post(`https://discord.com/api/v9/applications/${client.user.id}/emojis`, {
            name: name,
            image: image
        }, {
            headers: {
                Authorization: `Bot ${client.token}`
            }
        });

        const emojiId = response.data.id;
        const isAnimated = response.data.animated || image.endsWith('.gif');
        saveEmojiToDatabase(name, emojiId, isAnimated);
        
        return isAnimated ? `<a:${name}:${emojiId}>` : `<:${name}:${emojiId}>`;
    } catch (error) {
        if (error.response && error.response.data && error.response.data.message === 'You are being rate limited.') {
            const retryAfter = error.response.data.retry_after * 1000;
            await new Promise(resolve => setTimeout(resolve, retryAfter));
            return await createEmoji(client, name, image);
        }
        if (error.response.status === 500) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            return await createEmoji(client, name, image);
        }

        console.log(`\x1b[31m[Emojis]\x1b[0m Erro ao adicionar o emoji ${name}: ${error.message}`);
        return null;
    }
}

async function GetEmoji(client, emojiName) {
    const emojis = await fetchEmojis(client);

    const existingEmoji = emojis.find(e => e.name === emojiName);
    if (existingEmoji) {
        return existingEmoji.animated ? `<a:${emojiName}:${existingEmoji.id}>` : `<:${emojiName}:${existingEmoji.id}>`;
    }

    const emojiData = AllEmojis.find(e => e.name === emojiName);
    if (emojiData) {
        return await createEmoji(client, emojiData.name, emojiData.image);
    }
    return null;
}

async function saveEmojiToDatabase(emojiName, emojiId, isAnimated) {
    try {
        const emojiMention = isAnimated ? `<a:${emojiName}:${emojiId}>` : `<:${emojiName}:${emojiId}>`;

        let emojiData = {};
        if (fs.existsSync('./DataBaseJson/emojis.json')) {
            const fileData = fs.readFileSync('./DataBaseJson/emojis.json');
            emojiData = JSON.parse(fileData);
        }

        emojiData[emojiName] = emojiMention;
        fs.writeFileSync('./DataBaseJson/emojis.json', JSON.stringify(emojiData, null, 2));

        EmojisHelper.reload();

        console.log(`\x1b[32m[Emojis]\x1b[0m Emoji ${emojiName} salvo no arquivo.`);
    } catch (error) {
        console.log(`\x1b[31m[Emojis]\x1b[0m Erro ao salvar o emoji ${emojiName} no banco de dados: ${error.message}`);
    }
}

async function UploadEmojis(client) {
    const emojis = await fetchEmojis(client);
    const existingNames = new Set(emojis.map(e => e.name));

    let EmojisSalvos = {};
    if (fs.existsSync('./DataBaseJson/emojis.json')) {
        const fileData = fs.readFileSync('./DataBaseJson/emojis.json');
        EmojisSalvos = JSON.parse(fileData);
    }

    const EmojisSalvosSet = new Set(Object.keys(EmojisSalvos));
    const emojisToSave = emojis.filter(emoji => !EmojisSalvosSet.has(emoji.name));
    const emojisToUpload = AllEmojis.filter(emoji => !existingNames.has(emoji.name));

    const totalEmojis = emojisToSave.length + emojisToUpload.length;
    
    if (totalEmojis > 0) {
        console.log(`\x1b[36m[Emojis]\x1b[0m Iniciando download de ${totalEmojis} emojis...`);
    }
    
    await Promise.all(emojisToSave.map(emoji => 
        saveEmojiToDatabase(emoji.name, emoji.id, emoji.animated)
    ));

    const batchSize = 3;
    const results = [];
    
    for (let i = 0; i < emojisToUpload.length; i += batchSize) {
        const batch = emojisToUpload.slice(i, i + batchSize);
        const batchResults = await Promise.all(
            batch.map(emoji => createEmoji(client, emoji.name, emoji.image))
        );
        results.push(...batchResults);
        
        if (i + batchSize < emojisToUpload.length) {
            await new Promise(resolve => setTimeout(resolve, 300));
        }
    }
    
    EmojisHelper.reload();
    console.log('\x1b[36m[Emojis]\x1b[0m Cache de emojis atualizado.');

    if (totalEmojis > 0) {
        console.log(`\x1b[32m[Emojis]\x1b[0m Download concluído! ${totalEmojis} emojis processados.`);
    }
    
    return results;
}

module.exports = {
    GetEmoji,
    UploadEmojis
};
