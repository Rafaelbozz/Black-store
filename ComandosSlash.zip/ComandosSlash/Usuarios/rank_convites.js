const { ApplicationCommandType } = require("discord.js");
const { GuildsInvites } = require("../../DataBaseJson");
const { res } = require("../../res");

module.exports = {
    name: "rank_convites",
    description: "[🏆 | Invites] Ver o ranking de convites do servidor",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        const guildId = interaction.guild.id;

        const invitesData = GuildsInvites.get(guildId) || {};
        const invitesObj = invitesData.invites || {};

        const ranking = Object.entries(invitesObj)
            .map(([userId, count]) => ({ userId, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10);

        if (ranking.length === 0) {
            const containerContent = res.main(
                { type: 10, content: `## Ranking de Convites` },
                { type: 10, content: `> Nenhum convite registrado ainda neste servidor.` },
                { type: 14 }
            );

            return interaction.reply({ ...containerContent, ephemeral: true });
        }

        let rankingText = "";
        for (let i = 0; i < ranking.length; i++) {
            const { userId, count } = ranking[i];
            const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}º`;
            rankingText += `${medal} <@${userId}> - \`${count}\` convites\n`;
        }

        const containerContent = res.main(
            { type: 10, content: `## Ranking de Convites` },
            { type: 10, content: `> Top 10 membros com mais convites válidos no servidor.` },
            { type: 14 },
            { type: 10, content: rankingText },
            { type: 14 }
        );

        return interaction.reply({ ...containerContent, ephemeral: false });
    }
};
