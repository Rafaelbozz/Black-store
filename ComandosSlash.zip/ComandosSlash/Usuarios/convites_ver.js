const { ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const { GuildsInvites } = require("../../DataBaseJson");
const { res } = require("../../res");

module.exports = {
    name: "convites_ver",
    description: "[🎫 | Invites] Ver quantos convites válidos você ou outro usuário tem",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: "usuario",
            description: "Usuário para ver os convites (deixe vazio para ver os seus)",
            type: ApplicationCommandOptionType.User,
            required: false
        }
    ],

    run: async (client, interaction) => {
        const guildId = interaction.guild.id;
        const usuario = interaction.options.getUser("usuario") || interaction.user;
        const userId = usuario.id;

        const totalConvites = GuildsInvites.get(`${guildId}.invites.${userId}`) || 0;

        const containerContent = res.main(
            { type: 10, content: `## Convites de ${usuario.username}` },
            { type: 10, content: `> Informações sobre os convites válidos.` },
            { type: 14 },
            { type: 10, content: `**Total de Convites Válidos:** \`${totalConvites}\`` },
            { type: 14 }
        );

        return interaction.reply({ ...containerContent, ephemeral: true });
    }
};
