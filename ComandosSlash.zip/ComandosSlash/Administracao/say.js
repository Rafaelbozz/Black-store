const Discord = require("discord.js");
const { getPermissions } = require("../../Functions/PermissionsCache.js");
const { Emojis } = require("../../DataBaseJson");

module.exports = {
    name: "say",
    description: "[🛠️ | Administração] Enviar mensagem como bot",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'mensagem',
            description: 'Mensagem que o bot irá enviar',
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        },
        {
            name: 'canal',
            description: 'Canal onde a mensagem será enviada (opcional)',
            type: Discord.ApplicationCommandOptionType.Channel,
            required: false,
        }
    ],

    run: async (client, interaction) => {
        const perm = await getPermissions(client.user.id);
        if (perm === null || !perm.includes(interaction.user.id)) {
            return interaction.reply({ 
                content: `${Emojis.get('negative')} | Você não possui permissão para usar esse comando.`, 
                ephemeral: true 
            });
        }

        const mensagem = interaction.options.getString('mensagem');
        const canal = interaction.options.getChannel('canal') || interaction.channel;

        if (canal.type !== Discord.ChannelType.GuildText && 
            canal.type !== Discord.ChannelType.GuildAnnouncement) {
            return interaction.reply({ 
                content: `${Emojis.get('negative')} | O canal selecionado precisa ser um canal de texto!`, 
                ephemeral: true 
            });
        }

        try {
            await canal.send({ content: mensagem });

            await interaction.reply({ 
                content: `${Emojis.get('checker')} | Mensagem enviada com sucesso em ${canal}!`, 
                ephemeral: true 
            });

        } catch (error) {
            console.error('Erro ao enviar mensagem:', error);
            await interaction.reply({ 
                content: `${Emojis.get('negative')} | Ocorreu um erro ao enviar a mensagem. Verifique se tenho permissão para enviar mensagens nesse canal.`, 
                ephemeral: true 
            });
        }
    }
};
