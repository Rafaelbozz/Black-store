const { ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { perms } = require("../../DataBaseJson");
const { res } = require("../../res");
const emojis = require("../../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

module.exports = {
    name: "resetar_invites",
    description: "Resetar todos os convites dos usuários (Requer permissão)",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        const guildId = interaction.guild.id;

        const userPerms = perms.get(`${guildId}.users.${interaction.user.id}`) || [];
        const hasPermission = userPerms.includes('*') || userPerms.includes('convites.resetar');

        if (!hasPermission && !interaction.member.permissions.has('Administrator')) {
            const containerContent = res.main(
                { type: 10, content: `## Sem Permissão` },
            );

            return interaction.reply({ ...containerContent, ephemeral: true });
        }

        const rowConfirm = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirmar_resetar_convites')
                .setLabel('Confirmar')
                .setEmoji(Emojis.get('checker'))
                .setStyle(4),
            new ButtonBuilder()
                .setCustomId('cancelar_resetar_convites')
                .setLabel('Cancelar')
                .setEmoji(Emojis.get('negative'))
                .setStyle(2)
        );

        const containerContent = res.main(
            { type: 10, content: `## Confirmar Resetar Convites` },
            { type: 14 },
            { type: 10, content: `> **ATENÇÃO:** Esta ação irá resetar TODOS os convites de TODOS os usuários do servidor!` },
            { type: 14 },
            { type: 10, content: `**Esta ação é irreversível!**\n\nTem certeza que deseja continuar?` },
            { type: 14 }
        ).with({
            components: [rowConfirm]
        });

        return interaction.reply({ ...containerContent, ephemeral: true });
    }
};
