const { ApplicationCommandType } = require("discord.js");
const { Painel } = require("../../Functions/Painel");
const { getPermissions } = require("../../Functions/PermissionsCache.js");
const emojis = require("../../DataBaseJson/emojis.json");

const Emojis = {
    get: (name) => emojis[name] || ""
};

module.exports = {
  name: "panel",
  description: "[👑 | Owner] Use para configurar minhas funções",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const perm = await getPermissions(client.user.id)
    if (perm === null || !perm.includes(interaction.user.id)) {
      return interaction.reply({ content: `${Emojis.get("negative")} | Você não possui permissão para usar esse comando.`, ephemeral: true });
    }

    Painel(interaction, client)
  }
}
