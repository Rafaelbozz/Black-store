const fs = require('fs');
const path = require('path');

function removeLineComments(content) {
    const lines = content.split('\n');
    const result = [];
    
    for (let line of lines) {
        const commentIndex = line.indexOf('//');
        
        if (commentIndex === -1) {
            result.push(line);
        } else {
            let inString = false;
            let stringChar = null;
            let isComment = true;
            
            for (let i = 0; i < commentIndex; i++) {
                const char = line[i];
                
                if ((char === '"' || char === "'" || char === '`') && (i === 0 || line[i - 1] !== '\\')) {
                    if (!inString) {
                        inString = true;
                        stringChar = char;
                    } else if (char === stringChar) {
                        inString = false;
                        stringChar = null;
                    }
                }
            }
            
            if (inString) {
                isComment = false;
            }
            
            if (isComment) {
                const codePart = line.substring(0, commentIndex).trimEnd();
                if (codePart.length > 0) {
                    result.push(codePart);
                }
            } else {
                result.push(line);
            }
        }
    }
    
    return result.join('\n');
}

function processDirectory(dir, stats = { processed: 0, removed: 0 }) {
    const items = fs.readdirSync(dir);
    
    for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        
        if (stat.isDirectory()) {
            if (item === 'node_modules' || item === '.git' || item === 'Backups') {
                continue;
            }
            processDirectory(fullPath, stats);
        } else if (item.endsWith('.js')) {
            const content = fs.readFileSync(fullPath, 'utf8');
            const originalLines = content.split('\n').length;
            const newContent = removeLineComments(content);
            const newLines = newContent.split('\n').length;
            
            if (content !== newContent) {
                fs.writeFileSync(fullPath, newContent, 'utf8');
                const commentsRemoved = originalLines - newLines;
                stats.removed += commentsRemoved;
                console.log(`✓ ${fullPath} - ${commentsRemoved} comentários removidos`);
            }
            
            stats.processed++;
        }
    }
    
    return stats;
}

console.log('🧹 Removendo comentários de linha (//) dos arquivos JavaScript...\n');

const stats = processDirectory('.');

console.log(`\n✅ Concluído!`);
console.log(`📁 Arquivos processados: ${stats.processed}`);
console.log(`🗑️  Linhas de comentários removidas: ${stats.removed}`);
