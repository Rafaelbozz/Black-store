const {
  JsonDatabase,
} = require("wio.db");
const fs = require('fs');
const path = require('path');

(function verificarECriarArquivosJSON() {
  const dbPath = __dirname;
  
  console.log('\x1b[36m[Database]\x1b[35m Verificando arquivos JSON...');
  
  const arquivosNecessarios = {
    'produtos.json': {},
    'buttons.json': {},
    'gifts.json':{},
    'carrinhos.json': {},
    'pagamentos.json': {},
    'pedidos.json': {},
    'estatisticas.json': {},
    'configuracao.json': {},
    'tickets.json': {},
    'perms.json': {},
    'msgsauto.json': {},
    'entregaslog.json': {},
    'SystemMod.json': {},
    'Temporario.json': {},
    'Convites.json': {},
    'GuildsInvites.json': {},
    'emojis.json': {},
    'refounds.json': {},
    'Compras.json': {},
    'BackupStorage.json': {},
    'autolock.json': {},
    'configuracaorobux.json': {},
    'mensagemrobux.json': {},
    'carrinhosrobux.json': {},
    'sorteios.json': {},
    'sugestao.json': {},
    'transcript.json': {},
    'Systemrobux.json': {
      config: {
        status: false,
        precos: {
          com_taxa: 0,
          sem_taxa: 0
        },
        limites: {
          minimoGamepass: 0,
          gamepass: 1000000
        },
        canais: {
          logs: ""
        }
      },
      mensagem: {
        modo: "container",
        canal: "",
        messageId: ""
      }
    },
    'automaticos.json': {},
    'boasvindas.json': {},
    'clients.json': {},
    'configauth.json': {},
    'configauth02api.json': {},
    'configautos.json': {},
    'invitetracker.json': {
      ativo: false,
      canalId: null,
      mensagemEntradaNormal: "Seja bem-vindo(a) {membro}! Você foi convidado(a) por {convidador} que já agora possui {convites} convites válidos.",
      mensagemEntradaVanity: "Seja bem-vindo(a) {membro}! Você entrou através da Vanity URL do servidor.",
      mensagemSaida: "Que pena, {membro} nos deixou. Ele(a) foi convidado(a) por {convidador} que agora possui {convites} convites válidos."
    },
    'limpezaautomatica.json': {},
    'mensagem.json': {},
    'moderacao.json': {},
    'monitorfeedback.json': {},
    'msgauto.json': {},
    'nukeautomatico.json': {},
    'reacoes.json': {},
    'users.json': {},
    'configsticket.json': {
      ilusionAI: {
        prompt: "Você é uma assistente de suporte. Responda em português de forma clara e direta ao problema descrito pelo usuário. Se você não souber a resposta, peça para aguardar o suporte humano.",
        ativo: false
      },
      aparencia: {
        modoExibicao: "embed",
        titulo: "",
        descricao: "",
        banner: "",
        mensagem: ""
      },
      funcoes: {},
      horarioAtendimento: {
        ativo: false,
        inicio: "08:00",
        fim: "18:00",
        folgasAtivo: false,
        diasFolga: []
      },
      mensagemPostada: {
        guildId: "",
        channelId: "",
        messageId: ""
      }
    },
    'atendimentosAI.json': {}
  };

  let arquivosCriados = [];
  let arquivosExistentes = 0;
  
  for (const [nomeArquivo, estruturaPadrao] of Object.entries(arquivosNecessarios)) {
    const caminhoCompleto = path.join(dbPath, nomeArquivo);
    
    if (!fs.existsSync(caminhoCompleto)) {
      try {
        fs.writeFileSync(caminhoCompleto, JSON.stringify(estruturaPadrao, null, 2), 'utf8');
        arquivosCriados.push(nomeArquivo);
        console.log(`\x1b[32m[Database] ✅ Criado: ${nomeArquivo}\x1b[0m`);
      } catch (erro) {
        console.error(`\x1b[31m[Database] ❌ Erro ao criar ${nomeArquivo}:\x1b[0m`, erro.message);
      }
    } else {
      arquivosExistentes++;
    }
  }
  
  if (arquivosCriados.length > 0) {
    console.log(`\x1b[36m[Database]\x1b[32m 📦 ${arquivosCriados.length} arquivo(s) criado(s) com sucesso!\x1b[0m`);
  }
  
  console.log(`\x1b[36m[Database]\x1b[35m ✅ ${arquivosExistentes} arquivo(s) já existiam (não foram modificados)\x1b[0m`);
  console.log(`\x1b[36m[Database]\x1b[35m 📊 Total: ${Object.keys(arquivosNecessarios).length} arquivos verificados\x1b[0m`);
})();

const emojisPath = path.join(__dirname, 'emojis.json');
let emojisCache = null;
let lastEmojisLoad = 0;
const EMOJI_CACHE_TTL = 60000;

const getEmojis = () => {
  const now = Date.now();
  if (!emojisCache || (now - lastEmojisLoad) > EMOJI_CACHE_TTL) {
    try {
      delete require.cache[require.resolve('./emojis.json')];
      emojisCache = require('./emojis.json');
      lastEmojisLoad = now;
    } catch {
      emojisCache = {};
    }
  }
  return emojisCache;
};

const EmojisHelper = {
  get: (name) => {
    const emojis = getEmojis();
    return emojis[name] || "";
  },
  getAll: () => getEmojis(),
  reload: () => {
    emojisCache = null;
    lastEmojisLoad = 0;
    return getEmojis();
  }
};

const produtos = new JsonDatabase({
  databasePath: "./DataBaseJson/produtos.json"
});

const buttons = new JsonDatabase({
  databasePath: "./DataBaseJson/buttons.json"
});

const carrinhos = new JsonDatabase({
  databasePath: "./DataBaseJson/carrinhos.json"
});

const pagamentos = new JsonDatabase({
  databasePath: "./DataBaseJson/pagamentos.json"
});

const pedidos = new JsonDatabase({
  databasePath: "./DataBaseJson/pedidos.json"
});

const estatisticas = new JsonDatabase({
  databasePath: "./DataBaseJson/estatisticas.json"
});

const configuracao = new JsonDatabase({
  databasePath: "./DataBaseJson/configuracao.json"
});

const tickets = new JsonDatabase({
  databasePath: "./DataBaseJson/tickets.json"
});

const perms = new JsonDatabase({
  databasePath: "./DataBaseJson/perms.json"
});

const msgsauto = new JsonDatabase({
  databasePath: "./DataBaseJson/msgsauto.json"
});

const entregaslog = new JsonDatabase({
  databasePath: "./DataBaseJson/entregaslog.json"
});
const SystemMod = new JsonDatabase({
  databasePath: "./DataBaseJson/SystemMod.json"
});
const Temporario = new JsonDatabase({
  databasePath: "./DataBaseJson/Temporario.json"
});
const Convites = new JsonDatabase({
  databasePath: "./DataBaseJson/Convites.json"
});
const GuildsInvites = new JsonDatabase({
  databasePath: "./DataBaseJson/GuildsInvites.json"
});
const Emojis = new JsonDatabase({
  databasePath: "./DataBaseJson/emojis.json"
});
const refounds = new JsonDatabase({
  databasePath: "./DataBaseJson/refounds.json"
});
const Compras = new JsonDatabase({
  databasePath: "./DataBaseJson/Compras.json"
});
const BackupStorage = new JsonDatabase({
  databasePath: "./DataBaseJson/BackupStorage.json"
});

const autolock = new JsonDatabase({
  databasePath: "./DataBaseJson/autolock.json"
});

const configuracaorobux = new JsonDatabase({
  databasePath: "./DataBaseJson/configuracaorobux.json"
});

const mensagemrobux = new JsonDatabase({
  databasePath: "./DataBaseJson/mensagemrobux.json"
});

const carrinhosrobux = new JsonDatabase({
  databasePath: "./DataBaseJson/carrinhosrobux.json"
});

const sorteios = new JsonDatabase({
  databasePath: "./DataBaseJson/sorteios.json"
});

const sugestao = new JsonDatabase({
  databasePath: "./DataBaseJson/sugestao.json"
});

const transcript = new JsonDatabase({
  databasePath: "./DataBaseJson/transcript.json"
});

const Systemrobux = new JsonDatabase({
  databasePath: "./DataBaseJson/Systemrobux.json"
});

const configsticket = new JsonDatabase({
  databasePath: "./DataBaseJson/configsticket.json"
});

const atendimentosAI = new JsonDatabase({
  databasePath: "./DataBaseJson/atendimentosAI.json"
});

module.exports = {
  produtos,
  buttons,
  carrinhos,
  pagamentos,
  pedidos,
  configuracao,
  estatisticas,
  GuildsInvites,
  tickets,
  perms,
  msgsauto,
  entregaslog,
  SystemMod,
  Temporario,
  Convites,
  Emojis,
  EmojisHelper,
  refounds,
  Compras,
  BackupStorage,
  autolock,
  configuracaorobux,
  mensagemrobux,
  carrinhosrobux,
  sorteios,
  sugestao,
  transcript,
  Systemrobux,
  configsticket,
  atendimentosAI
}
